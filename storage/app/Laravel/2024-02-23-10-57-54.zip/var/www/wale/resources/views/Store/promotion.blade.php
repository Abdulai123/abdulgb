
<h1>Products Promotion</h1>
<div>
  <p style="color: red; text-align:center;">You do not have required permission to access this feature!  <br> You must have recoded sales, <br> You must be active for atlease 3 to 6 months.</p>
</div>
<table>
    <thead>
      <tr>
        <th>Promo ID</th>
        <th>Days</th>
        <th>Type</th>
        <th>Cost</th>
        <th>Status</th>
        <th>Created At</th>
    </tr>
    </thead>
    <tbody>
      <td colspan="6">You do not have any promotions...</td>
    </tbody>
</table>
