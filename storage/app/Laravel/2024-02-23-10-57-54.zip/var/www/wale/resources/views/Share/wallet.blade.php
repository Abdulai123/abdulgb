<div class="listing-type">
    <legend>{{ $store->store_name }} > Wallet</legend>
    <h3>?
        <hr>
    </h3>
    <a href="/{{ $store->store_name }}/wallet/deposite">Deposit</a>
    <a href="/{{ $store->store_name }}/wallet/withdraw">Withdraw</a>
</div>
