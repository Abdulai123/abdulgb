<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Whales Market | {{ $user->public_name }} > Market Canary</title>
    @if ($user->theme == 'dark')
        <link rel="stylesheet" href="{{ asset('dark.theme.css') }}">
    @else
        <link rel="stylesheet" href="{{ asset('white.theme.css') }}">
    @endif
    <link rel="stylesheet" href="{{ asset('market.white.css') }}">

    <meta http-equiv="refresh" content="{{ session('session_timer') }};url=/kick/{{ $user->public_name }}/out">
    <link rel="stylesheet" href="{{ asset('filter.css') }}">
    <link rel="shortcut icon" href="{{ asset('favicon.ico') }}" type="image/x-icon">
</head>

<body>
    @include('User.navebar')
    <div class="container">
        <div class="main-div">
            <div class="notific-container">
                <h1>Canary's</h1>
                <p class="notifications-p">Canary's will be updated every 30 days!</p>

                @forelse (\App\Models\MarketKey::all() as $canary)
                <div class="canary-div">
                    <p class="{{ $canary->user->role ?? 'pending' }}">{{ $canary->user->role ?? 'System' }}/{{ $canary->user->public_name ?? "Market" }} -> Canary ~ Sign message - <span style="font-style: italic;">Last Updated: {{ $canary->updated_at->DiffForHumans() }}</span></p><hr>
                    <p style="white-space: pre-wrap;">{{ $canary->message_sign }}</p><hr>
                </div>
                @empty
                    There are no canary yet.
                @endforelse
            </div>
        </div>
    </div>
    </div>
    <style>
        h1{
            text-align: center;
            color: var(--main-color);
        }


.canary-div {
  margin-bottom: 1.4em;
  border-radius: 8px;
  box-shadow: var(--shadow);
  color: var(--dark-color-text);
  border: 1px solid grey;
  border-radius: .5rem;
}

p{
  color: var(--dark-color-text);
  margin-left: 2em;
  margin-bottom: 1em;
  word-wrap: break-word;

}


    </style>
    @include('User.footer')
</body>

</html>
