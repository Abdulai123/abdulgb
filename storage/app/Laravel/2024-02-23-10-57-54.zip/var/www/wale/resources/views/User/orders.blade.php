<div class="main-div">
    <div class="notific-container">
        <h1 class="notifications-h1" style="text-transform: capitalize"> {{ $action }} >
            Orders({{ $action != 'all' ? $user->orders->where('status', $action)->count() : $user->orders->count() }})
        </h1>
        <p class="notifications-p"> All closed disputes, completed orders, cancelled orders after 15 days will be automatically deleted.</p>
        <table>
            <thead>
                <tr>
                    <th>Sort By</th>
                    <th>Number Of Rows</th>
                    <th>Status</th>
                    <th>Payment Type</th>
                    <th>Action Button</th>
                </tr>
            </thead>
            <tbody>
                <form action="/{{ $user->public_name }}/orders/search" method="get" style="text-align: center">
                    @csrf
                    <tr>
                        <td>
                            <select name="sort_by" id="sort_by">
                                <option value="newest" {{ old('sort_by') == 'newest' ? 'selected' : '' }}>Newest</option>
                                <option value="highest_quantity" {{ old('sort_by') == 'highest_quantity' ? 'selected' : '' }}>Highest Quantities</option>
                                <option value="lowest_quantity" {{ old('sort_by') == 'lowest_quantity' ? 'selected' : '' }}>Lowest Quantities</option>
                                <option value="oldest" {{ old('sort_by') == 'oldest' ? 'selected' : '' }}>Oldest</option>
                            </select>
                        </td>
                        <td>
                            <select name="number_of_rows" id="number_of_rows">
                                <option value="50" {{ old('number_of_rows') == '50' ? 'selected' : '' }}>50</option>
                                <option value="100" {{ old('number_of_rows') == '100' ? 'selected' : '' }}>100</option>
                                <option value="150" {{ old('number_of_rows') == '150' ? 'selected' : '' }}>150</option>
                                <option value="250" {{ old('number_of_rows') == '250' ? 'selected' : '' }}>250</option>
                            </select>
                        </td>
                        <td>
                            <select name="status" id="status">
                                <option value="all" {{ old('status') == 'all' ? 'selected' : '' }}>All</option>
                                <option value="pending" {{ old('status') == 'pending' ? 'selected' : '' }}>Pending</option>
                                <option value="processing" {{ old('status') == 'processing' ? 'selected' : '' }}>Processing</option>
                                <option value="shipped" {{ old('status') == 'shipped' ? 'selected' : '' }}>Shipped</option>
                                <option value="delivered" {{ old('status') == 'delivered' ? 'selected' : '' }}>Delivered</option>
                                <option value="dispute" {{ old('status') == 'dispute' ? 'selected' : '' }}>Dispute</option>
                                <option value="sent" {{ old('status') == 'sent' ? 'selected' : '' }}>Sent</option>
                                <option value="dispatched" {{ old('status') == 'dispatched' ? 'selected' : '' }}>Dispatched</option>
                                <option value="cancelled" {{ old('status') == 'cancelled' ? 'selected' : '' }}>Cancelled</option>
                                <option value="completed" {{ old('status') == 'completed' ? 'selected' : '' }}>Completed</option>
                            </select>
                        </td>                
                        <td>
                            <select name="payment_type" id="">
                                <option value="all" {{ old('payment_type') == 'all' ? 'selected' : '' }}>All</option>
                                <option value="Escrow" {{ old('payment_type') == 'Escrow' ? 'selected' : '' }}>Escrow</option>
                                <option value="FE" {{ old('payment_type') == 'FE' ? 'selected' : '' }}>FE</option>
                            </select>
                        </td>
                        <td style="text-align: center; margin:0px; padding:0px;">
                            <input type="submit" class="submit-nxt" style="width: max-content; margin:0px; padding:.5em;"
                                value="Search">
                        </td>
                    </tr>
                </form>
            </tbody>
        </table>
        <table>
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Cost Per Item</th>
                    <th>Quantity</th>
                    <th>Status</th>
                    <th>Created At</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @php
                
                    $orders = session('orders') ?? $user->orders->sortByDesc('updated_at');
                @endphp

                @forelse ($orders as $order)
                    <tr>
                        <td><a
                                href="/listing/{{ $order->product->created_at->timestamp }}/{{ $order->product_id }}">#WM{{ $order->product->created_at->timestamp }}</a>
                        </td>
                        <td>${{ $order->product->price }}</td>
                        <td>{{ $order->quantity }}</td>
                        <td class="{{ $order->status }}">{{ $order->status }}</td>
                        <td>{{ \Carbon\Carbon::parse($order->created_at)->diffForHumans() }}</td>
                        <td><a href="/order/{{ $order->created_at->timestamp }}/{{ $order->id }}">view</a></td>
                    </tr>
                @empty
                    <tr>
                        <td colspan='7'>No {{ session('orders') != null ? old('status') : $action }} order found.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
