<div>
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Listing</th>
          <th>Buyer</th>
          <th>Date</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        
      </tbody>
    </table>
    No reviews found.
  </div>