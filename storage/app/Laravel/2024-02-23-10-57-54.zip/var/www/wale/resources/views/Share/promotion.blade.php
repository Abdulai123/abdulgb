
<legend style="text-align: center;">{{ $store->store_name }} > Promotions  </legend>
<div style="text-align: center; margin: 1em;">
  There is no available spot yet... hop back again later.
</div>
<table>
    <thead>
      <tr>
        <th>Promo ID</th>
        <th>Days</th>
        <th>Type</th>
        <th>Cost</th>
        <th>Status</th>
        <th>Created At</th>
    </tr>
    </thead>
    <tbody>
      <td colspan="6">You do not have any promotions...</td>
    </tbody>
</table>
