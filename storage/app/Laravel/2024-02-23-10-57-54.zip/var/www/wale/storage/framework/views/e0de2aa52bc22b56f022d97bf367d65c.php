<?php if($paginator->hasPages()): ?>
    <div class="pagination">
        
        <?php if($paginator->currentPage() > 2): ?>
            <a href="<?php echo e($paginator->url(1)); ?>">1</a>
            <?php if($paginator->currentPage() > 3): ?>
                <span class="dots">...</span>
            <?php endif; ?>
        <?php endif; ?>

        
        <?php for($i = max(1, $paginator->currentPage() - 1); $i <= min($paginator->currentPage() + 1, $paginator->lastPage()); $i++): ?>
            
            <?php if($i == $paginator->currentPage()): ?>
                <span class="current"><?php echo e($i); ?></span>
            <?php else: ?>
                <a href="<?php echo e($paginator->url($i)); ?>"><?php echo e($i); ?></a>
            <?php endif; ?>
        <?php endfor; ?>

        
        <?php if($paginator->currentPage() < $paginator->lastPage() - 1): ?>
            <?php if($paginator->currentPage() < $paginator->lastPage() - 2): ?>
                <span class="dots">...</span>
            <?php endif; ?>
            <a href="<?php echo e($paginator->url($paginator->lastPage())); ?>"><?php echo e($paginator->lastPage()); ?></a>
        <?php endif; ?>
    </div>
    <?php if($paginator->total() > 0): ?>
        <div style="color: #4f4b4b; padding: 10px; margin-top: 10px; text-align:center; font-size:1rem;">
            Total Result Found: <?php echo e($paginator->total()); ?>

        </div>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH /var/www/wale/resources/views/vendor/pagination/custom_pagination.blade.php ENDPATH**/ ?>