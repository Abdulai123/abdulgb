<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Whales Market | <?php echo e($user->public_name); ?> > <?php echo e($name); ?> > <?php echo e($action); ?></title>

    <?php if($user->theme == 'dark'): ?>
        <link rel="stylesheet" href="<?php echo e(asset('dark.theme.css')); ?>">
    <?php else: ?>
        <link rel="stylesheet" href="<?php echo e(asset('white.theme.css')); ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('market.white.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('filter.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">
    <meta http-equiv="refresh" content="<?php echo e(session('session_timer')); ?>;url=/kick/<?php echo e($user->public_name); ?>/out">
</head>

<body>
    

        

    <?php if(session('let_welcome')): ?>
        <?php echo $__env->make('User.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php elseif(session('ask_pgp')): ?>
        <?php echo $__env->make('Auth.pgp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php else: ?>
        <?php echo $__env->make('User.navebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php if($name == 'store'): ?>
            <?php echo $__env->make('User.store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <?php echo $__env->make('User.action', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

        <?php echo $__env->make('User.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
</body>

</html>
<?php /**PATH /var/www/wale/resources/views/User/index.blade.php ENDPATH**/ ?>