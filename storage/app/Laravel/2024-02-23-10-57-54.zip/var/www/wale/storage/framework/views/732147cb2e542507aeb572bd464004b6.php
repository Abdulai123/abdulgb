<div class="main-div">
    <div class="notific-container">
        <h1 class="notifications-h1" style="text-transform: capitalize"> <?php echo e($action); ?> >
            Orders(<?php echo e($action != 'all' ? $user->orders->where('status', $action)->count() : $user->orders->count()); ?>)
        </h1>
        <p class="notifications-p"> All closed disputes, completed orders, cancelled orders after 15 days will be automatically deleted.</p>
        <table>
            <thead>
                <tr>
                    <th>Sort By</th>
                    <th>Number Of Rows</th>
                    <th>Status</th>
                    <th>Payment Type</th>
                    <th>Action Button</th>
                </tr>
            </thead>
            <tbody>
                <form action="/<?php echo e($user->public_name); ?>/orders/search" method="get" style="text-align: center">
                    <?php echo csrf_field(); ?>
                    <tr>
                        <td>
                            <select name="sort_by" id="sort_by">
                                <option value="newest" <?php echo e(old('sort_by') == 'newest' ? 'selected' : ''); ?>>Newest</option>
                                <option value="highest_quantity" <?php echo e(old('sort_by') == 'highest_quantity' ? 'selected' : ''); ?>>Highest Quantities</option>
                                <option value="lowest_quantity" <?php echo e(old('sort_by') == 'lowest_quantity' ? 'selected' : ''); ?>>Lowest Quantities</option>
                                <option value="oldest" <?php echo e(old('sort_by') == 'oldest' ? 'selected' : ''); ?>>Oldest</option>
                            </select>
                        </td>
                        <td>
                            <select name="number_of_rows" id="number_of_rows">
                                <option value="50" <?php echo e(old('number_of_rows') == '50' ? 'selected' : ''); ?>>50</option>
                                <option value="100" <?php echo e(old('number_of_rows') == '100' ? 'selected' : ''); ?>>100</option>
                                <option value="150" <?php echo e(old('number_of_rows') == '150' ? 'selected' : ''); ?>>150</option>
                                <option value="250" <?php echo e(old('number_of_rows') == '250' ? 'selected' : ''); ?>>250</option>
                            </select>
                        </td>
                        <td>
                            <select name="status" id="status">
                                <option value="all" <?php echo e(old('status') == 'all' ? 'selected' : ''); ?>>All</option>
                                <option value="pending" <?php echo e(old('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                <option value="processing" <?php echo e(old('status') == 'processing' ? 'selected' : ''); ?>>Processing</option>
                                <option value="shipped" <?php echo e(old('status') == 'shipped' ? 'selected' : ''); ?>>Shipped</option>
                                <option value="delivered" <?php echo e(old('status') == 'delivered' ? 'selected' : ''); ?>>Delivered</option>
                                <option value="dispute" <?php echo e(old('status') == 'dispute' ? 'selected' : ''); ?>>Dispute</option>
                                <option value="sent" <?php echo e(old('status') == 'sent' ? 'selected' : ''); ?>>Sent</option>
                                <option value="dispatched" <?php echo e(old('status') == 'dispatched' ? 'selected' : ''); ?>>Dispatched</option>
                                <option value="cancelled" <?php echo e(old('status') == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                                <option value="completed" <?php echo e(old('status') == 'completed' ? 'selected' : ''); ?>>Completed</option>
                            </select>
                        </td>                
                        <td>
                            <select name="payment_type" id="">
                                <option value="all" <?php echo e(old('payment_type') == 'all' ? 'selected' : ''); ?>>All</option>
                                <option value="Escrow" <?php echo e(old('payment_type') == 'Escrow' ? 'selected' : ''); ?>>Escrow</option>
                                <option value="FE" <?php echo e(old('payment_type') == 'FE' ? 'selected' : ''); ?>>FE</option>
                            </select>
                        </td>
                        <td style="text-align: center; margin:0px; padding:0px;">
                            <input type="submit" class="submit-nxt" style="width: max-content; margin:0px; padding:.5em;"
                                value="Search">
                        </td>
                    </tr>
                </form>
            </tbody>
        </table>
        <table>
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Cost Per Item</th>
                    <th>Quantity</th>
                    <th>Status</th>
                    <th>Created At</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                
                    $orders = session('orders') ?? $user->orders->sortByDesc('updated_at');
                ?>

                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><a
                                href="/listing/<?php echo e($order->product->created_at->timestamp); ?>/<?php echo e($order->product_id); ?>">#WM<?php echo e($order->product->created_at->timestamp); ?></a>
                        </td>
                        <td>$<?php echo e($order->product->price); ?></td>
                        <td><?php echo e($order->quantity); ?></td>
                        <td class="<?php echo e($order->status); ?>"><?php echo e($order->status); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($order->created_at)->diffForHumans()); ?></td>
                        <td><a href="/order/<?php echo e($order->created_at->timestamp); ?>/<?php echo e($order->id); ?>">view</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan='7'>No <?php echo e(session('orders') != null ? old('status') : $action); ?> order found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH /var/www/wale/resources/views/User/orders.blade.php ENDPATH**/ ?>