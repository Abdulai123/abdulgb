<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Whales Market | <?php echo e($user->public_name); ?> > Support Ticket</title>
    <?php if($user->theme == 'dark'): ?>
        <link rel="stylesheet" href="<?php echo e(asset('dark.theme.css')); ?>">
    <?php else: ?>
        <link rel="stylesheet" href="<?php echo e(asset('white.theme.css')); ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('market.white.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('market.white.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('filter.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">
    <meta http-equiv="refresh" content="<?php echo e(session('session_timer')); ?>;url=/kick/<?php echo e($user->public_name); ?>/out">

</head>

<body>
    <?php echo $__env->make('User.navebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="main-div">
            <div class="notific-container">
                <h1 class="notifications-h1" style="margin:0; padding:0px;;">_Support Ticket_</h1>
                <p class="notifications-p">Please only create new support ticket, if you do not have any (pending, open,
                    eacalated) ticket!</p>

                <p style="text-align: center; color: #007bff; margin:0px; padding:0px;">Number of support tickets
                    remaining for today:
                    <span style="color: #dc3545;">
                        (<?php echo e(3 -$user->supports()->whereDate('created_at', \Carbon\Carbon::today())->count()); ?>/3)
                    </span>
                </p>

                <?php if($errors->any): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p style="color: red; text-align:cenetr;"><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <?php if(session('success')): ?>
                    <p style="color: green; text-align:center;"><?php echo e(session('success')); ?></p>
                <?php endif; ?>
                <?php if(session('new_ticket')): ?>
                    <div>
                        <form action="" method="post" class="support-form">
                            <?php echo csrf_field(); ?>
                            <label for="receiver" class="subject-label" style="width: fit-content;">Subject: <input
                                    type="text" name="subject" class="subject" style="border: none; font-size: 1rem;"
                                    placeholder="Support Subject..." required> </label>
                            <input type="hidden" name="message_type" value="ticket">
                            <textarea name="contents" placeholder="Write your request message here... max 5K characters!" cols="30"
                                rows="10" required></textarea>
                                <div id="capatcha-code-img">
                                    <img src="/user/captcha" alt="Captcha Image">
                                    <input type="text" id="captcha" maxlength="8" minlength="8" name="captcha"
                                        placeholder="Captcha..." required>
                                </div>
                            <input type="submit" class="submit-nxt" value="Send">
                        </form>
                    </div>
                <?php else: ?>
                    <div style="text-align: center; margin-bottom: 1em;">
                        <form action="" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="submit" name="new_ticket" value="Create New Ticket" class="input-listing">
                        </form>
                    </div>
                <?php endif; ?>


                <table>
                    <thead>
                        <tr>
                            <th>Ticket ID</th>
                            <th>Staff</th>
                            <th>Status</th>
                            <th>Action</th>
                            <th>Created At</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $__empty_1 = true; $__currentLoopData = $user->supports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><a
                                        href="/messages/<?php echo e($ticket->conversation->created_at->timestamp); ?>/<?php echo e($ticket->conversation_id); ?>">#TWM_<?php echo e($ticket->created_at->timestamp); ?></a>
                                </td>
                                <td class="<?php echo e($ticket->staff_id != null ? $ticket->staff->role : ''); ?>">
                                    <?php echo e($ticket->staff != null ? $ticket->staff->public_name : 'No Staff Yet'); ?></td>
                                <td class="<?php echo e($ticket->status); ?>"><?php echo e($ticket->status); ?></td>
                                <td><a
                                        href="/messages/<?php echo e($ticket->conversation->created_at->timestamp); ?>/<?php echo e($ticket->conversation_id); ?>">View</a>
                                </td>
                                <td><?php echo e($ticket->created_at->diffForHumans()); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan='4'>No support ticket found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php echo $__env->make('User.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH /var/www/wale/resources/views/User/ticket.blade.php ENDPATH**/ ?>