<h1 style="text-align: center;">Escrows(<?php echo e($escrows->count()); ?>)</h1>
<?php if(session('success') != null): ?>
<p style="text-align: center; background: darkgreen; padding: 5px; border-radius: .5rem; color: #f1f1f1;">
    <?php echo e(session('success')); ?></p>
<?php endif; ?>
<?php if($errors->any): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p style="padding: 10px; margin: 10px; border-radius: .5rem; background-color: #dc3545">
        <?php echo e($error); ?>

    </p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<form action="" method="post" style="text-align: center; margin-bottom:1em;">
    <?php echo csrf_field(); ?>
    <?php if(session('pay')): ?>
    <input type="number" name="amount" placeholder="Amount.... $0.0" id="" class="form-input">
    <label for="sender" class="subject-label" style="width: fit-content;">Receiver:
        <select name="payee" id="">
            <?php $__currentLoopData = \App\Models\User::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($staff->id); ?>" class="<?php echo e($staff->role); ?>"><?php echo e($staff->public_name); ?>(<?php echo e($staff->role); ?>)</option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </label>
    <input type="submit" name="save" id="" class="submit-nxt" value="Pay">
        
    <?php else: ?>
    <input type="submit" name="pay" id="" class="input-listing" value="Pay Out">
        
    <?php endif; ?>
</form>
<table>
    <thead>
        <tr>
            <th>Sort By</th>
            <th>Number Of Rows</th>
            <th>Status</th>
            <th>D0</th>
        </tr>
    </thead>
    <tbody>
        <form action="/whales/admin/<?php echo e($user->public_name); ?>/show/escrows/search" method="get"
            style="text-align: center">
            <tr>
                <td>
                    <select name="sort_by" id="sort_by">
                        <option value="newest" <?php echo e(old('sort_by') == 'newest' ? 'selected' : ''); ?>>Newest</option>
                        <option value="amount_highest" <?php echo e(old('sort_by') == 'amount_highest' ? 'selected' : ''); ?>>Amount Highest</option>
                        <option value="oldest" <?php echo e(old('sort_by') == 'oldest' ? 'selected' : ''); ?>>Oldest</option>
                    </select>
                </td>
                <td>
                    <select name="number_of_rows" id="number_of_rows">
                        <option value="50" <?php echo e(old('number_of_rows') == '50' ? 'selected' : ''); ?>>50</option>
                        <option value="100" <?php echo e(old('number_of_rows') == '100' ? 'selected' : ''); ?>>100</option>
                        <option value="150" <?php echo e(old('number_of_rows') == '150' ? 'selected' : ''); ?>>150</option>
                        <option value="250" <?php echo e(old('number_of_rows') == '250' ? 'selected' : ''); ?>>250</option>
                    </select>
                </td>
                <td>
                    <select name="status" id="">
                        <option value="all" <?php echo e(old('status') == 'all' ? 'selected' : ''); ?>>All</option>
                        <option value="active" <?php echo e(old('status') == 'active' ? 'selected' : ''); ?>>Active</option>
                        <option value="released" <?php echo e(old('status') == 'released' ? 'selected' : ''); ?>>Released</option>
                        <option value="cancelled" <?php echo e(old('status') == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                    </select>
                </td>
                <td style="text-align: center; margin:0px; padding:0px;">
                    <input type="submit" class="submit-nxt" style="width: max-content; margin:0px; padding:.5em;"
                        value="Perform">
                </td>
            </tr>
        </form>
    </tbody>
</table>

<table>
    <thead>
        <tr>
            <th>#ID</th>
            <th>Amount</th>
            <th>Order</th>
            <th>Payment Type</th>
            <th>Status</th>
            <th>Created At</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $escrows = session('escrows') ?? $escrows;
        ?>
        <?php $__empty_1 = true; $__currentLoopData = $escrows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $escrow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="self-container">
                <td>#<?php echo e($escrow->id); ?></td>
                <td>$<?php echo e($escrow->fiat_amount); ?></td>
                <td>#<?php echo e($escrow->order_id); ?></td>
                <td class="<?php echo e($escrow->order->product->payment_type ?? 'pending'); ?>"><?php echo e($escrow->order->product->payment_type ?? 'N/A'); ?></td>
                <td class="<?php echo e($escrow->status); ?>"><?php echo e($escrow->status); ?></td>
                <td><?php echo e($escrow->created_at->DiffForHumans()); ?></td>
            </tr>
            </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <tr>
                <td colspan="5">
                    <span class="no-notification">
                        Cart is currently empty.
                    </span>
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php echo e($escrows->render('vendor.pagination.custom_pagination')); ?>


<?php /**PATH /var/www/wale/resources/views/Admin/escrows.blade.php ENDPATH**/ ?>