<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Whales Market | <?php echo e($user->public_name); ?> > Messages</title>
    <?php if($user->theme == 'dark'): ?>
        <link rel="stylesheet" href="<?php echo e(asset('dark.theme.css')); ?>">
    <?php else: ?>
        <link rel="stylesheet" href="<?php echo e(asset('white.theme.css')); ?>">
    <?php endif; ?>
    <meta http-equiv="refresh" content="<?php echo e(session('session_timer')); ?>;url=/kick/<?php echo e($user->public_name); ?>/out">

    <link rel="stylesheet" href="<?php echo e(asset('market.white.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('filter.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">
</head>

<body>
    <?php echo $__env->make('User.navebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="main-div">
        <div class="notific-container">
            <h1 class="notifications-h1" style="margin:0; padding:0px;;">_Messages_</h1>
            <p class="notifications-p">Messages older than 15 days will be automatically deleted. Please note that only
                individual messages within the conversation, not the entire conversation itself, mark conversations as
                archive to leave the conversation.</p>
            <?php if($errors->any): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p style="color: red; text-align:cenetr;"><?php echo e($error); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(session('success')): ?>
                <p style="color: green; text-align:center;"><?php echo e(session('success')); ?></p>
            <?php endif; ?>
            <table>
                <thead>
                    <tr>
                        <th>Sort By</th>
                        <th>Number Of Rows</th>
                        <th>Message Type</th>
                        <th>Action Button</th>
                    </tr>
                </thead>
                <tbody>
                    <form action="/<?php echo e($user->public_name); ?>/messages/search" method="get" style="text-align: center">
                        <?php echo csrf_field(); ?>
                        <tr>
                            <td>
                                <select name="sort_by" id="sort_by">
                                    <option value="newest" <?php echo e(old('sort_by') == 'newest' ? 'selected' : ''); ?>>Newest
                                    </option>
                                    <option value="oldest" <?php echo e(old('sort_by') == 'oldest' ? 'selected' : ''); ?>>Oldest
                                    </option>
                                </select>
                            </td>
                            <td>
                                <select name="number_of_rows" id="number_of_rows">
                                    <option value="50" <?php echo e(old('number_of_rows') == '50' ? 'selected' : ''); ?>>50
                                    </option>
                                    <option value="100" <?php echo e(old('number_of_rows') == '100' ? 'selected' : ''); ?>>100
                                    </option>
                                    <option value="150" <?php echo e(old('number_of_rows') == '150' ? 'selected' : ''); ?>>150
                                    </option>
                                    <option value="250" <?php echo e(old('number_of_rows') == '250' ? 'selected' : ''); ?>>250
                                    </option>
                                </select>
                            </td>
                            <td>
                                <select name="message_type" id="">
                                    <option value="all" <?php echo e(old('message_type') == 'all' ? 'selected' : ''); ?>>All
                                        Messages</option>
                                    <option value="message" <?php echo e(old('message_type') == 'message' ? 'selected' : ''); ?>>
                                        Messages</option>
                                    <option value="ticket" <?php echo e(old('message_type') == 'ticket' ? 'selected' : ''); ?>>
                                        Support Tickets</option>
                                    <option value="dispute" <?php echo e(old('message_type') == 'dispute' ? 'selected' : ''); ?>>
                                        Dispute Messages</option>
                                    <option value="mass" <?php echo e(old('message_type') == 'mass' ? 'selected' : ''); ?>>
                                        Favorite Stores News Letters</option>
                                </select>
                            </td>
                            <td style="text-align: center; margin:0px; padding:0px;">
                                <input type="submit" class="submit-nxt"
                                    style="width: max-content; margin:0px; padding:.5em;" value="Search">
                            </td>
                        </tr>
                    </form>
                </tbody>
            </table>
            <?php
                $AllConversations = session('conversations') ?? $conversations;
                $AllParticipants = session('participants') ?? $userConversations->sortByDesc('updated_at');
            ?>
            <?php $__empty_1 = true; $__currentLoopData = $AllParticipants->where('is_hidden', 0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userConversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php $__currentLoopData = $AllConversations->where('id', $userConversation->conversation_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $latestMessage = $conversation
                            ->messages()
                            ->latest()
                            ->first();
                    ?>

                    <?php
                        $isDispute = $latestMessage && $latestMessage->message_type == 'dispute';
                        $iconType = 'mail'; // Default icon type

                        if ($isDispute) {
                            $iconType = 'dispute';
                        } elseif ($latestMessage && $latestMessage->message_type == 'ticket') {
                            $iconType = 'plane-tickets';
                        } elseif ($latestMessage && $latestMessage->message_type == 'mass') {
                            $iconType = 'news_letter';
                        }
                    ?>

                    <a href="<?php echo e($isDispute ? '/order/' . $conversation->dispute->order->created_at->timestamp . '/' . $conversation->dispute->order->id : '/messages/' . $conversation->created_at->timestamp . '/' . $conversation->id); ?>"
                        class="notification-container">
                        <?php if($latestMessage): ?>
                            <img src="data:image/jpeg;base64,<?php echo e($icon[$iconType]); ?>" alt="" class="icon-filter"
                                width="40">
                        <?php else: ?>
                            <img src="data:image/jpeg;base64,<?php echo e($icon['mail']); ?>" alt="" class="icon-filter"
                                width="40">
                        <?php endif; ?>

                        <div class="notification-content">
                            <div style="display: flex;">
                                <span><?php echo e($conversation->topic); ?></span>
                                <span>Reference #WM<?php echo e($conversation->created_at->timestamp); ?></span>
                                <span class="notification-time"><?php echo e($conversation->created_at->diffForHumans()); ?></span>
                                <?php if($latestMessage->message_type == 'mass' || $latestMessage->message_type == 'message'): ?>
                                    <form
                                        action="/conversation/archive/<?php echo e($conversation->created_at->timestamp); ?>/<?php echo e($conversation->id); ?>"
                                        method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="submit" name="read" id="" class="pending"
                                            value="Mark as archive" style="cursor: pointer;">
                                    </form>
                                <?php elseif($latestMessage->message_type == 'dispute'): ?>
                                    <?php
                                        $dispute = \App\Models\Dispute::where('conversation_id', $conversation->id)->first();
                                    ?>
                                    <?php if($dispute->status == 'closed'): ?>
                                        <form
                                            action="/conversation/archive/<?php echo e($conversation->created_at->timestamp); ?>/<?php echo e($conversation->id); ?>"
                                            method="post">
                                            <?php echo csrf_field(); ?>
                                            <input type="submit" name="read" id="" class="pending"
                                                value="Mark as archive" style="cursor: pointer;">
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <p class="notification-message">
                                <?php if($latestMessage): ?>
                                    <?php echo e(Str::limit($latestMessage->content, 50, '...')); ?>

                                <?php else: ?>
                                    No message sent yet to this conversation...
                                <?php endif; ?>
                                <?php
                                    $unreadMessageCounter = 0;
                                ?>

                                <?php $__currentLoopData = $conversation->messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $unreadMessageCounter += $message->status
                                            ->where('user_id', $user->id)
                                            ->where('is_read', 0)
                                            ->count();
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php if($unreadMessageCounter > 0): ?>
                                    <span class="count-unread-messages"><?php echo e($unreadMessageCounter); ?></span>
                                <?php endif; ?>
                            </p>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                No conversation found, for the search, or you do not have any conversations...
            <?php endif; ?>

        </div>

    </div>
    <?php echo $__env->make('User.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH /var/www/wale/resources/views/User/message.blade.php ENDPATH**/ ?>