<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php if($user->theme == 'dark'): ?>
        <link rel="stylesheet" href="<?php echo e(asset('dark.theme.css')); ?>">
    <?php else: ?>
        <link rel="stylesheet" href="<?php echo e(asset('white.theme.css')); ?>">
    <?php endif; ?>
    
    <link rel="stylesheet" href="<?php echo e(asset('market.white.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(@asset('store.white.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(@asset('filter.css')); ?>">
    <meta http-equiv="refresh" content="<?php echo e(session('session_timer')); ?>;url=/whales/admin/kick/<?php echo e($user->public_name); ?>/out">
    <title>Whales Market | <?php echo e($action != null ? $action : $user->public_name . '  Admin'); ?></title>
</head>

<body>
    <?php echo $__env->make('Admin.naveBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="main-div">
            <div class="notific-container" style="padding: 5px; margin:0px">
                <div class="cls-top">
                </div>
                <div class="main">
                    <div class="cls-left">
                        <div class="wlc-info">
                            <div class="avater">
                                <div class="bg-img">
                                    <?php
                                        $avatarKey = $user->avater;
                                    ?>

                                    <img src="data:image/png;base64,<?php echo e(!empty($upload_image[$avatarKey]) ? $upload_image[$avatarKey] : $icon['default']); ?>"
                                        class="background-img">

                                </div>
                            </div>
                            <div class="name-status">
                                <p>Welcome, <?php echo e($user->public_name); ?></p>
                                <p><span>Last Updated: </span>
                                    <span><?php echo e($user->updated_at->diffForHumans()); ?></span>
                                </p>
                                <p><span>Member Since:
                                    </span><span><?php echo e($user->created_at->format('j F Y')); ?></span>
                                </p>
                                <p><span>Status: </span> <span class="<?php echo e($user->status); ?>"><?php echo e($user->status); ?></span>
                                </p>
                                <p><span>Role: </span> <span class="<?php echo e($user->role); ?>"><?php echo e($user->role); ?></span>
                                </p>
                                <p>}}---<span style="color: darkgreen; font-size:.8rem;">Your login phrase is
                                        `<?php echo e($user->login_passphrase); ?>`</span></p>
                                <p style="border-bottom: 3px dotted green">Last Seen:
                                    <?php echo e(\Carbon\Carbon::parse($user->last_seen)->diffForHumans()); ?></p>
                                    <div class="prices-div">
                                        <span>BTC/USD: <span class="usd"> $<?php echo e(session('btc')); ?></span></span>
                                        <span>XMR/USD: <span class="usd">$<?php echo e(session('xmr')); ?></span></span>
                                    </div>
                            </div>

                        </div>
                        <div class="menus">
                            <div class="dashboard">
                                <img src="data:image/png;base64,<?php echo e($icon['dashboard']); ?>" class="icon-filter"
                                    width="25">
                                <a href="/whales/admin/<?php echo e($user->public_name); ?>/show/dashboard">Dashboard</a>
                            </div>

                            <div class="listings">
                                <img src="data:image/png;base64,<?php echo e($icon['group']); ?>" class="icon-filter"
                                    width="25">
                                <a
                                    href="/whales/admin/<?php echo e($user->public_name); ?>/show/users">Users(<?php echo e(\App\Models\User::whereDate('created_at', Carbon\Carbon::today())->count()); ?>)</a>
                            </div>
                            <div class="all-products">
                                <img src="data:image/png;base64,<?php echo e($icon['new_store']); ?>" class="icon-filter"
                                    width="25">
                                <a href="/whales/admin/<?php echo e($user->public_name); ?>/show/new stores">New
                                    Stores(<?php echo e(\App\Models\NewStore::whereDate('created_at', Carbon\Carbon::today())->count()); ?>)</a>
                            </div>
                            <div class="support">
                                <img src="data:image/png;base64,<?php echo e($icon['add-store']); ?>" class="icon-filter"
                                    width="25">
                                <a
                                    href="/whales/admin/<?php echo e($user->public_name); ?>/show/stores">Stores(<?php echo e(\App\Models\Store::whereDate('created_at', Carbon\Carbon::today())->count()); ?>)</a>
                            </div>
                            <div class="wallet">
                                <img src="data:image/png;base64,<?php echo e($icon['partnership']); ?>" class="icon-filter"
                                    width="25">
                                <a href="/whales/admin/<?php echo e($user->public_name); ?>/show/waivers">Stores
                                    Waivers(<?php echo e(\App\Models\Waiver::whereDate('created_at', Carbon\Carbon::today())->count()); ?>)</a>
                            </div>

                            <div class="listings">
                                <img src="data:image/png;base64,<?php echo e($icon['category']); ?>" class="icon-filter"
                                    width="25">
                                <a href="/whales/admin/<?php echo e($user->public_name); ?>/show/categories">Categories</a>
                            </div>

                            <div class="all-products">
                                <img src="data:image/png;base64,<?php echo e($icon['dispute']); ?>" class="icon-filter"
                                    width="25">
                                <a
                                    href="/whales/admin/<?php echo e($user->public_name); ?>/show/disputes">Disputes(<?php echo e(\App\Models\Dispute::whereDate('created_at', Carbon\Carbon::today())->count()); ?>)</a>
                            </div>
                            <div class="wallet">
                                <img src="data:image/png;base64,<?php echo e($icon['inventory']); ?>" class="icon-filter"
                                    width="25">
                                <a
                                    href="/whales/admin/<?php echo e($user->public_name); ?>/show/products">Products(<?php echo e(\App\Models\Product::where('status', 'Pending')->count()); ?>)</a>
                            </div>
                            <div class="wallet">
                                <img src="data:image/png;base64,<?php echo e($icon['orders']); ?>" class="icon-filter"
                                    width="25">
                                <a
                                    href="/whales/admin/<?php echo e($user->public_name); ?>/show/orders">Orders(<?php echo e(\App\Models\Order::whereDate('created_at', Carbon\Carbon::today())->count()); ?>)</a>
                            </div>
                            <div class="settings">
                                <img src="data:image/png;base64,<?php echo e($icon['shopping-cart']); ?>" class="icon-filter"
                                    width="25">
                                <a
                                    href="/whales/admin/<?php echo e($user->public_name); ?>/show/carts">Carts(<?php echo e(\App\Models\Cart::whereDate('created_at', Carbon\Carbon::today())->count()); ?>)</a>
                            </div>
                            <div class="wallet">
                                <img src="data:image/png;base64,<?php echo e($icon['wallet']); ?>" class="icon-filter"
                                    width="25">
                                <a
                                    href="/whales/admin/<?php echo e($user->public_name); ?>/show/conversations">Conversations(<?php echo e(\App\Models\Conversation::whereDate('created_at', Carbon\Carbon::today())->count()); ?>)</a>
                            </div>
                            <div class="settings">
                                <img src="data:image/png;base64,<?php echo e($icon['escrow']); ?>" class="icon-filter"
                                    width="25">
                                <a
                                    href="/whales/admin/<?php echo e($user->public_name); ?>/show/escrows">Escrows(<?php echo e(\App\Models\Escrow::whereDate('created_at', Carbon\Carbon::today())->count()); ?>)</a>
                            </div>


                            <div class="settings" style="border-top: 2px solid gray;">
                                <img src="data:image/png;base64,<?php echo e($icon['coupon']); ?>" class="icon-filter"
                                    width="25">
                                <a href="/whales/admin/<?php echo e($user->public_name); ?>/show/coupons">Coupons
                                    Codes(<?php echo e(\App\Models\Promocode::whereDate('created_at', Carbon\Carbon::today())->count()); ?>)</a>
                            </div>
                            <div class="settings">
                                <img src="data:image/png;base64,<?php echo e($icon['reviews']); ?>" class="icon-filter"
                                    width="25">
                                <a
                                    href="/whales/admin/<?php echo e($user->public_name); ?>/show/reviews">Reviews(<?php echo e(\App\Models\Review::whereDate('created_at', Carbon\Carbon::today())->count()); ?>)</a>
                            </div>
                            <div class="wallet">
                                <img src="data:image/png;base64,<?php echo e($icon['partnership']); ?>" class="icon-filter"
                                    width="25">
                                <a href="/whales/admin/<?php echo e($user->public_name); ?>/show/share_accesses">Share
                                    Accesses(<?php echo e(\App\Models\ShareAccess::whereDate('created_at', Carbon\Carbon::today())->count()); ?>)</a>
                            </div>
                            <div class="wallet">
                                <img src="data:image/png;base64,<?php echo e($icon['feature']); ?>" class="icon-filter"
                                    width="25">
                                <a href="/whales/admin/<?php echo e($user->public_name); ?>/show/featureds">Featureds
                                    Listings(<?php echo e(\App\Models\Featured::whereDate('created_at', Carbon\Carbon::today())->count()); ?>)</a>
                            </div>

                            <hr>
                            Infos
                            <hr>



                            <div class="wallet">
                                <img src="data:image/png;base64,<?php echo e($icon['plane-tickets']); ?>" class="icon-filter"
                                    width="25">
                                <a
                                    href="/whales/admin/<?php echo e($user->public_name); ?>/show/support">Supports(<?php echo e(\App\Models\Support::whereDate('created_at', Carbon\Carbon::today())->count()); ?>)</a>
                            </div>
                            <div class="settings">
                                <img src="data:image/png;base64,<?php echo e($icon['faq']); ?>" class="icon-filter"
                                    width="25">
                                <a
                                    href="/whales/admin/<?php echo e($user->public_name); ?>/show/faqs">FAQs(<?php echo e(\App\Models\FAQ::whereDate('created_at', Carbon\Carbon::today())->count()); ?>)</a>
                            </div>
                            <div class="settings">
                                <img src="data:image/png;base64,<?php echo e($icon['news']); ?>" class="icon-filter"
                                    width="25">
                                <a
                                    href="/whales/admin/<?php echo e($user->public_name); ?>/show/news">News(<?php echo e(\App\Models\News::whereDate('created_at', Carbon\Carbon::today())->count()); ?>)</a>
                            </div>
                            <div class="support">
                                <img src="data:image/png;base64,<?php echo e($icon['warn']); ?>" class="icon-filter"
                                    width="25">
                                <a
                                    href="/whales/admin/<?php echo e($user->public_name); ?>/show/reports">Reports(<?php echo e(\App\Models\Report::whereDate('created_at', Carbon\Carbon::today())->count()); ?>)</a>
                            </div>
                            <div class="wallet">
                                <img src="data:image/png;base64,<?php echo e($icon['unauthorized']); ?>" class="icon-filter"
                                    width="25">
                                <a
                                    href="/whales/admin/<?php echo e($user->public_name); ?>/show/unauthorize">Unauthorize(<?php echo e(\App\Models\Unauthorize::whereDate('created_at', Carbon\Carbon::today())->count()); ?>)</a>
                            </div>

                            <div class="wallet">
                                <img src="data:image/png;base64,<?php echo e($icon['web-coding']); ?>" class="icon-filter"
                                    width="25">
                                <a
                                    href="/whales/admin/<?php echo e($user->public_name); ?>/show/bugs">Bugs(<?php echo e(\App\Models\Bug::whereDate('created_at', Carbon\Carbon::today())->count()); ?>)</a>
                            </div>

                            <hr>
                            market actions
                            <hr>
                            <div class="all-products">
                                <img src="data:image/png;base64,<?php echo e($icon['server']); ?>" class="icon-filter"
                                    width="25">
                                <a href="/whales/admin/<?php echo e($user->public_name); ?>/show/servers">Servers</a>
                            </div>
                            <div class="wallet">
                                <img src="data:image/png;base64,<?php echo e($icon['shield']); ?>" class="icon-filter"
                                    width="25">
                                <a href="/whales/admin/<?php echo e($user->public_name); ?>/show/pgp">2FA PGP KEY</a>
                            </div>

                            <div class="settings">
                                <img alt="🖇️" style="font-size:1.5em; margin-right: .5em;" class="icon-filter"
                                    width="25">
                                <a href="/whales/admin/<?php echo e($user->public_name); ?>/show/mirrors">Mirrors</a>
                            </div>

                            <div class="settings">
                                <?php if($user->theme == 'white'): ?>
                                    <img src="data:image/png;base64,<?php echo e($icon['night-mode']); ?>" class="icon-filter"
                                        width="25">
                                    <a href="/whales/admin/<?php echo e($user->public_name); ?>/show/theme">Dark Mode</a>
                                <?php else: ?>
                                    <img src="data:image/png;base64,<?php echo e($icon['brightness']); ?>" class="icon-filter"
                                        width="25">
                                    <a href="/whales/admin/<?php echo e($user->public_name); ?>/show/theme">Light Mode</a>
                                <?php endif; ?>

                            </div>
                            <div class="wallet">
                                <img src="data:image/png;base64,<?php echo e($icon['notifications_type']); ?>"
                                    class="icon-filter" width="25">
                                <a href="/whales/admin/<?php echo e($user->public_name); ?>/show/notifications_types">Notification
                                    Types</a>
                            </div>

                            <div class="wallet">
                                <img src="data:image/png;base64,<?php echo e($icon['document']); ?>" class="icon-filter"
                                    width="25">
                                <a href="/whales/admin/<?php echo e($user->public_name); ?>/show/canary">Canary</a>
                            </div>

                            <div class="settings">
                                <img src="data:image/png;base64,<?php echo e($icon['functions']); ?>" class="icon-filter"
                                    width="25">
                                <a href="/whales/admin/<?php echo e($user->public_name); ?>/show/functions">Market Functions</a>
                            </div>

                            <div class="wallet">
                                <img src="data:image/png;base64,<?php echo e($icon['wallet']); ?>" class="icon-filter"
                                    width="25">
                                <a href="/whales/admin/<?php echo e($user->public_name); ?>/show/wallets">Wallets</a>
                            </div>
                            <div class="settings">
                                <img src="data:image/png;base64,<?php echo e($icon['rules']); ?>" class="icon-filter"
                                    width="25">
                                <a href="/whales/admin/<?php echo e($user->public_name); ?>/show/rules">Rules</a>
                            </div>
                            <div class="wallet">
                                <img src="data:image/png;base64,<?php echo e($icon['logs']); ?>" class="icon-filter"
                                    width="25">
                                <a href="/whales/admin/<?php echo e($user->public_name); ?>/show/payout">PayOut Logs</a>
                            </div>
                        </div>
                    </div>
                    <div class="cls-main">
                        <?php if($action === 'settings'): ?>
                            <?php echo $__env->make('Admin.settings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'users'): ?>
                            <?php echo $__env->make('Admin.users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'stores'): ?>
                            <?php echo $__env->make('Admin.stores', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'new stores'): ?>
                            <?php echo $__env->make('Admin.new_stores', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'categories'): ?>
                            <?php echo $__env->make('Admin.categories', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'disputes'): ?>
                            <?php echo $__env->make('Admin.disputes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'orders'): ?>
                            <?php echo $__env->make('Admin.orders', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'wallets'): ?>
                            <?php echo $__env->make('Admin.wallets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'carts'): ?>
                            <?php echo $__env->make('Admin.carts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'conversations'): ?>
                            <?php echo $__env->make('Admin.conversations', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'escrows'): ?>
                            <?php echo $__env->make('Admin.escrows', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'coupons'): ?>
                            <?php echo $__env->make('Admin.coupons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'share_accesses'): ?>
                            <?php echo $__env->make('Admin.share_accesses', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'reviews'): ?>
                            <?php echo $__env->make('Admin.reviews', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'products'): ?>
                            <?php echo $__env->make('Admin.products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'settings'): ?>
                            <?php echo $__env->make('Admin.settings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'view'): ?>
                            <?php echo $__env->make('Admin.productView', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'notifications'): ?>
                            <?php echo $__env->make('Admin.notifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action == 'messages'): ?>
                            <?php echo $__env->make('Admin.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'news'): ?>
                            <?php echo $__env->make('Admin.news', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'rules'): ?>
                            <?php echo $__env->make('Admin.rules', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'support'): ?>
                            <?php echo $__env->make('Admin.support', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'reports'): ?>
                            <?php echo $__env->make('Admin.reports', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'waivers'): ?>
                            <?php echo $__env->make('Admin.waivers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'servers'): ?>
                            <?php echo $__env->make('Admin.servers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'faqs'): ?>
                            <?php echo $__env->make('Admin.faq', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'notifications_types'): ?>
                            <?php echo $__env->make('Admin.notificationTypes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'functions'): ?>
                            <?php echo $__env->make('Admin.functions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'bugs'): ?>
                            <?php echo $__env->make('Admin.bugs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'canary'): ?>
                            <?php echo $__env->make('Admin.canary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php elseif($action === 'payout'): ?>
                            <?php echo $__env->make('Admin.payout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php elseif($action === 'pgp'): ?>
                            <?php echo $__env->make('Admin.pgp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php elseif($action === 'deposit'): ?>
                            <?php echo $__env->make('Admin.deposit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php elseif($action === 'withdraw'): ?>
                            <?php echo $__env->make('Admin.withdraw', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                            
                        <?php elseif($action === 'Show User'): ?>
                            <?php echo $__env->make('Admin.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'New Store'): ?>
                            <?php echo $__env->make('Admin.new_store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'Store'): ?>
                            <?php echo $__env->make('Admin.store', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'Waiver'): ?>
                            <?php echo $__env->make('Admin.waiver', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'product'): ?>
                            <?php echo $__env->make('Admin.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'Order'): ?>
                            <?php echo $__env->make('Admin.order', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'message'): ?>
                            <?php echo $__env->make('Admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'ticket'): ?>
                            <?php echo $__env->make('Admin.ticket', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'unauthorize'): ?>
                            <?php echo $__env->make('Admin.unauthorizeReview', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($action === 'modmail'): ?>
                            <?php echo $__env->make('Admin.modsMessage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php elseif($action === 'mirrors'): ?>
                            <?php echo $__env->make('Admin.mirrors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php else: ?>
                            <?php echo $__env->make('Admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('Admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH /var/www/wale/resources/views/Admin/index.blade.php ENDPATH**/ ?>