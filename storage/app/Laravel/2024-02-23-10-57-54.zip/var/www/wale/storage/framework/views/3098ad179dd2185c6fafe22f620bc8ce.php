<h1>Servers(<?php echo e(\App\Models\Server::all()->count()); ?>)</h1>

<form action="" method="post" style="text-align: center; margin-bottom:1em;">
    <?php echo csrf_field(); ?>

    <?php if(session('new_server')): ?>
        <input type="text" name="ip" class="form-input"
            style="background-color: var(--white-background-color); color: var(--dark-color-text)"
            placeholder="Ip addr..."><br>

        <input type="text" name="port" class="form-input"
            style="background-color: var(--white-background-color); color: var(--dark-color-text)"
            placeholder="Port..."><br>

        <input type="text" name="user_name" class="form-input"
            style="background-color: var(--white-background-color); color: var(--dark-color-text)"
            placeholder="User Name...."><br>

        <input type="text" name="password" class="form-input"
            style="background-color: var(--white-background-color); color: var(--dark-color-text)"
            placeholder="Password..."><br>

        <input type="text" name="type" class="form-input"
            style="background-color: var(--white-background-color); color: var(--dark-color-text)"
            placeholder="Type....[wallet, daemon, api]"><br>

        <input type="text" name="extra_user" class="form-input"
            style="background-color: var(--white-background-color); color: var(--dark-color-text)"
            placeholder="Extra user..."><br>

        <input type="text" name="extra_pass" class="form-input"
            style="background-color: var(--white-background-color); color: var(--dark-color-text)"
            placeholder="Extra pass...."><br>

        <button type="submit" class="submit-nxt" name="save">Save</button>
    <?php elseif(session('edit_server')): ?>
        <?php
            $server = session('server');
        ?>
        <input type="text" name="ip" class="form-input"
            style="background-color: var(--white-background-color); color: var(--dark-color-text)"
            placeholder="Ip addr..." value="<?php echo e($server->ip); ?>"><br>

        <input type="text" name="port" class="form-input"
            style="background-color: var(--white-background-color); color: var(--dark-color-text)"
            placeholder="Port..." value="<?php echo e($server->port); ?>"><br>

        <input type="text" name="user_name" class="form-input"
            style="background-color: var(--white-background-color); color: var(--dark-color-text)"
            placeholder="User Name...." value="<?php echo e($server->username); ?>"><br>

        <input type="text" name="password" class="form-input"
            style="background-color: var(--white-background-color); color: var(--dark-color-text)"
            placeholder="Password..." value="<?php echo e($server->password); ?>"><br>

        <input type="text" name="type" class="form-input"
            style="background-color: var(--white-background-color); color: var(--dark-color-text)"
            placeholder="Type....[wallet, daemon, api]" value="<?php echo e($server->type); ?>"><br>

        <input type="text" name="extra_user" class="form-input"
            style="background-color: var(--white-background-color); color: var(--dark-color-text)"
            placeholder="Extra user..." value="<?php echo e($server->extra_user); ?>"><br>

        <input type="text" name="extra_pass" class="form-input"
            style="background-color: var(--white-background-color); color: var(--dark-color-text)"
            placeholder="Extra pass...." value="<?php echo e($server->extra_pass); ?>"><br>

        <input type="hidden" name="id" value="<?php echo e($server->id); ?>">
        <button type="submit" class="submit-nxt" name="save_edit">Save Edit</button>
    <?php else: ?>
        <input type="submit" name="new_server" value="Add New Server" class="input-listing">
    <?php endif; ?>
</form>

<table>
    <thead>
        <tr>
            <th>IP</th>
            <th>Port</th>
            <th>User Name</th>
            <th>Password </th>
            <th>is_tor</th>
            <th>Type</th>
            <th>Extra User</th>
            <th>Extra Pass</th>
            <th>Last Updated</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $servers = session('servers') ?? \App\Models\Server::all();
        ?>
        <?php $__empty_1 = true; $__currentLoopData = $servers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $server): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($server->ip); ?></td>
                <td><?php echo e($server->port); ?></td>
                <td><?php echo e($server->username); ?></td>
                <td>No pass</td>
                <td><?php echo e($server->is_tor); ?></td>
                <td><?php echo e($server->type); ?></td>
                <td><?php echo e($server->extra_user); ?></td>
                <td>No pass</td>
                <td><?php echo e($server->updated_at->DiffForHumans()); ?></td>
                <td>
                    <form action="" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" id="" value="<?php echo e($server->id); ?>">
                        <input type="submit" name="delete" id="" value="Delete"
                            style="color:red; cursor:pointer">
                        <input type="submit" style="color: darkgreen; cursor:pointer;" name="edit" value="Edit">
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="8">No server found...</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php /**PATH /var/www/wale/resources/views/Admin/servers.blade.php ENDPATH**/ ?>