<div class="container">
    <div class="main-div">
        <div class="dir">
            <div class="dir-div">
                <a href="<?php echo e(url()->current()); ?>" style="font-size:.8rem;">/</a> }}---
                <span style="color: darkgreen; font-size:.8rem;">Your login phrase is
                    `<?php echo e($user->login_passphrase); ?>`</span>
                    <span style="color: darkorange; font-size:.8rem;">~=~ Your Wallet Balance Is:
                        `$<?php echo e($user->wallet->balance); ?>`</span>
            </div>
    
            <div class="prices-div">
                <span>BTC/USD: <span class="usd"> $<?php echo e(session('btc')); ?></span></span>
                <span>XMR/USD: <span class="usd">$<?php echo e(session('xmr')); ?></span></span>
            </div>
        </div>
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p style="color: red; text-align:center;"><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <?php if(session('success')): ?>
            <p style="color: green; text-align: center;"><?php echo e(session('success')); ?></p>
        <?php endif; ?>

        <div class="top-div">
            <?php echo $__env->make('User.categories', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




            <div>
                <div class="categories search-div">
                    <?php if(session('advance_search')): ?>
                        <h3>Advance Search Listings/Stores ℹ️<br>

                        </h3>
                    <?php else: ?>
                        <h3>Quick Search Listings
                            <form action="/search" method="get" class="search-form" style="padding: .5em;">
                                <?php echo csrf_field(); ?>
                                <button type="submit" name="advance-search" style="margin:0px;"
                                    class="search-button">Go Advance
                                    Search</button>
                            </form>
                        </h3>
                    <?php endif; ?>

                    <form action="/search" method="get" class="search-form">
                        <?php echo csrf_field(); ?>
                        <input type="text" class="search_name" name="pn"
                            placeholder="Quick search with product name...">

                        <?php if(session('advance_search')): ?>
                            
                                <div style="display: flex; gap:1em; margin:.5em; text-align:center">
                                <label for="">Stores:</label> <select name="str_n" id="">
                                    <?php $__empty_1 = true; $__currentLoopData = \App\Models\Store::where('status', 'active')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($store->store_name); ?>"><?php echo e($store->store_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option value="">No store found.... :)</option>
                                    <?php endif; ?>
                                </select>
                                </div>
                        <?php endif; ?>

                        <div class="price-range">
                            Price:
                            <input type="number" name="pf" min="0" placeholder="min $0.0" id="price-input"
                                value="">
                            <input type="number" name="pt" min="0" placeholder="max $0.0" id="price-input"
                                value="">
                        </div>
                        <?php if(session('advance_search')): ?>
                            

                            <div>
                                AutoShop:
                                <input type="checkbox" name="auto_shop" id="price-input">
                                <label>Search include descriptions: <input type="checkbox" name="desc"></label>
                            </div>
                            <div style="display: flex; gap:1em; margin:.5em;">
                                <label for="">Ship From:</label>
                                <select name="sf" id="">
                                    <option value="">Any Country</option>
                                    <?php echo $__env->make('User.countries', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </select>
                            </div>
                            <div style="display: flex; gap:1em; margin:.5em;">
                                <label for="">Ship To:</label>
                                <select name="st" id="">
                                    <option value="World Wide">World Wide</option>
                                    <?php echo $__env->make('User.countries', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </select>
                            </div>
                            <div style="display: flex; gap:1em; margin:.5em;">
                                <select name="filter-product" id="">
                                    <option value="">---Sort By---</option>
                                    <option value="best-match">Best Match</option>
                                    <option value="newest">Newest listed</option>
                                    <option value="oldest">Oldest listed</option>
                                    <option value="Cheapest">price + Shipping: lowest first</option>
                                    <option value="highest">Price + Shipping: highest first</option>
                                </select>
                            </div>
                            <div style="display: flex; gap:1em; margin:.5em;">
                                <select name="parent_category" id="">
                                    <option value="">---Select Parent Category---</option>
                                    <?php $__currentLoopData = $categories->where('parent_category_id', null); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <select name="sub_category" id="">
                                    <option value="">---Select Sub Category---</option>
                                    <?php $__currentLoopData = $categories->where('parent_category_id', '!=', null); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div style="display: flex; gap:1em; margin:.5em;">
                                <select name="payment_type">
                                    <option value="">---Payment System---</option>
                                    <option value="Escrow">Escrow</option>
                                    <option value="FE">Finalize Early</option>
                                </select>
                            </div>
                        <?php else: ?>
                            <input type="hidden" name="search_type" value="product">
                            <select name="filter-product" id="">
                                <option value="">---Sort By---</option>
                                <option value="best-match">Best Match</option>
                                <option value="newest">Newest listed</option>
                                <option value="oldest">Oldest listed</option>
                                <option value="Cheapest">price + Shipping: lowest first</option>
                                <option value="highest">Price + Shipping: highest first</option>
                            </select>
                        <?php endif; ?>
                        <div style="display: flex; gap:1em; margin:.5em;">
                            <div class="product-type">
                                Product type:
                                <label><input type="radio" name="pt2" value="all" checked>All</label>
                                <label><input type="radio" name="pt2" value="digital">Digital</label>
                                <label><input type="radio" name="pt2" value="physical">Physical</label>
                            </div>
                            <button type="submit" class="search-button">Search</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php if($user->twofa_enable === 'no'): ?>
            <div>
                <p
                    style="background-color: rgb(255, 239, 238); padding: 8px; border: 1px solid rgb(90, 8, 1); margin-bottom: 16px; box-sizing: border-box; border-radius: 5px; color: rgb(90, 8, 1); font-family:Verdana, Geneva, Tahoma, sans-serif;">
                    Two-Factor Authentication is Disabled, add your public pgp key that match your public name and
                    check
                    the
                    `enable 2FA box` to enable 2FA!</p>
            </div>
        <?php endif; ?>

        <?php
           $cashback = \App\Models\MarketFunction::where('name','cashback')->first();
        ?>
        <?php if($cashback->enable): ?>
        <div class="auto-release-message" style="margin-top: 1em;">
            <strong style="color: #0c9300;">🚀 Dive into Whales Market's 5% Escrow Profit Bonanza!</strong>
            <span> Grab your share of the excitement! Enjoy a fantastic 2.5% cashback on all your Whales Market purchases. And here's the inside scoop: that 2.5% cashback is a sweet slice of our 5% escrow profit. So, if you do the math, it's like snagging 2.5% of the 5% escrow profit. But, hold on, there's more fun to be had! Bring your crew to Whales Market use your referral code which is your public name `<?php echo e($user->public_name); ?>`, and we'll spice things up with an extra 2.5%, totaling a whopping 5%, which is 100% of the escrow profit we make! <br> Thanks for being part of the Whales Market adventure!
            </span>
        </div>
        <?php endif; ?>
        


        <div class="listing-name">
            <h3 style="color: #3498db;">
                <?php if($is_parent_category): ?>
                    <?php echo e('Category > ' . $categoryName); ?>

                <?php elseif($is_sub_category): ?>
                    <?php echo e('Category > ' . $categoryName); ?>

                <?php else: ?>
                    Random > Listings
                <?php endif; ?>
            </h3>
        </div>

        <div class="products-grid">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php echo $__env->make('User.products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                No product found.
            <?php endif; ?>
        </div>

        <?php echo e($products->links('vendor.pagination.custom_pagination')); ?>




    </div>
</div>
<?php /**PATH /var/www/wale/resources/views/User/main.blade.php ENDPATH**/ ?>