<div class="main-div">
    <div class="notific-container">
        <h1>Wallet > Withdraw</h1>
<div style="text-align: center">
    <?php if($errors->any): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p style="color: red; text-align:cenetr;"><?php echo e($error); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php if(session('success')): ?>
    <p style="color: green; text-align:center;"><?php echo e(session('success')); ?></p>
<?php endif; ?>
</div>
    
        <div class="wallet-section">
            <fieldset>
                <legend>Withdrawing Money</legend>
                <form action="" method="post" class="wallet-form">
                    <?php echo csrf_field(); ?>
                    <div class="balance-item">
                        <p style="color:green;"><span>Wallet Balance</span><br><span style="font-weight: 800;">$<?php echo e($user->wallet->balance); ?> / <?php echo e(session('xmr') == null ? "xmr api problem open a support ticket." : round($user->wallet->balance/session('xmr'),3)); ?> XMR</span></p>
                    </div>
                    

                    <input type="text" id="withdraw-xmr-address" class="input-field" name="address"
                    placeholder="XMR address" required>
                <input type="text" id="withdraw-amount" class="input-field" name="amount"
                    placeholder="Amount USD $0.00" required>
                    <input type="number" id="withdraw-amount" class="input-field" name="pin"
                    placeholder="Secret pin code" required>
                    <div id="capatcha-code-img">
                        <img src="/user/captcha" alt="Captcha Image">
                        <input type="text" id="captcha" maxlength="8" minlength="8" name="captcha"
                            placeholder="Captcha..." required>
                    </div>
                    <input type="submit" class="submit-nxt" value="Submit">
                </form>
            </fieldset>
        </div>
        

        <h3>Withdraw History</h3>
            <table>
                <thead>
                    <tr>
                        <th>Infos</th>
                        <th>Status</th>
                        <th>Amount</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $user->wallet->withdraw->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                Address: <input type="text" name="" id="" value="<?php echo e($withdraw->address); ?>"> <br>
                                Txid: <input type="text" name="" id="" value="<?php echo e($withdraw->txid); ?>">
                            </td>
                            <td><?php echo e($withdraw->is_confirm == 0 ? "Pending" : "Completed"); ?></td>
                            <td><?php echo e($withdraw->amount); ?> XMR</td>
                            <td><?php echo e($withdraw->created_at->DiffForHumans()); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan='4'>No withdraw history found.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
    </div>
</div>

<style>
/* Reset some default styles for better consistency */
 p, fieldset, legend, form {
    margin: 0;
    padding: 0;
}


/* Style for the fieldset */
fieldset {
    border: 1px solid #ccc;
    border-radius: 8px;
    padding: 20px;
    margin: 20px auto;
    width: 50vw;
    background-color: var(--white-background-color);
}

/* Style for the legend */
legend {
    font-size: 1.2em;
    font-weight: bold;
    color: var(--main-color);
    margin-bottom: 10px;
}

/* Style for the form */
.wallet-form {
    display: flex;
    flex-direction: column;
}

/* Style for each balance item */
.balance-item {
    background-color: var(--secondary-white-bg);
    border-radius: 5px;
    margin-bottom: 10px;
    padding: 10px;
}

/* Style for the balance item text */
.balance-item p {
    margin: 0;
}

/* Style for the input fields */
.input-field {
    width: 100%;
    padding: 8px;
    margin: 8px 0;
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 5px;
}

/* Add some style to the XMR address input for better visibility */
#withdraw-xmr-address {
    background-color: var(--secondary-white-bg);
}

/* Add some style to the Amount input for better visibility */
#withdraw-amount {
    background-color: var(--secondary-white-bg);
}

/* Add hover effect on input fields */
.input-field:hover {
    border-color: #555;
}

</style>
<?php /**PATH /var/www/wale/resources/views/User/withdraw.blade.php ENDPATH**/ ?>