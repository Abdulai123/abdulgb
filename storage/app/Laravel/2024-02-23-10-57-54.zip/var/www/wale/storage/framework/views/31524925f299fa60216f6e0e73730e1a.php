<div class="latest-orders">
    <?php if(session('success')): ?>
        <p style="color: green; text-align:center; margin:0px;"><?php echo e(session('success')); ?></p>
    <?php endif; ?>
    <div class="title-latest">
        <h4>NEWEST STORE REQUEST (<?php echo e($new_stores->count()); ?>)</h4>
        <div class="view-latest">
            <a href="/whales/admin/<?php echo e($user->public_name); ?>/show/new stores">VIEW ALL</a>
        </div>
    </div>
    <div>
        <table>
            <thead>
                <tr>
                    <th>#ID</th>
                    <th>Store Name</th>
                    <th>Owner Name</th>
                    <th>Created At</th>
                    <th>Owner Last Seen</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $dashboard_new_stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new_store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>#<?php echo e($new_store->id); ?></td>
                        <td><?php echo e($new_store->store_name); ?></td>
                        <td><?php echo e($new_store->user->public_name); ?></td>
                        <td><?php echo e($new_store->created_at->DiffForHumans()); ?></td>
                        <td><?php echo e($new_store->user->last_seen); ?></td>
                        <td class="<?php echo e($new_store->user->store_status); ?>"><?php echo e($new_store->user->store_status); ?></td>
                        <td>
                            <form action="" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="new_store_id" value="<?php echo e(Crypt::encrypt($new_store->id)); ?>">

                                <a href="/whales/admin/show/new store/<?php echo e($new_store->created_at->timestamp); ?>/<?php echo e($new_store->id); ?>"
                                    style="font-size: .7rem; background-color: rgb(0, 75, 128); color: #f1f1f1; cursor:pointer; padding: 5px; border: none; border-radius: .5rem;">Review</a>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>
</div>
<div class="top-products">
    <div class="title-latest">
        <h4>NEWEST PRODUCTS (<?php echo e($products->count()); ?>)</h4>
        <div class="view-latest">
            <a href="/whales/admin/<?php echo e($user->public_name); ?>/show/products">VIEW ALL</a>
        </div>
    </div>
    <div>
        <table>
            <thead>
                <tr>
                    <th>#ID</th>
                    <th>Name</th>
                    <th>Store</th>
                    <th>Created At</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $dashboard_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>#<?php echo e($product->id); ?></td>
                        <td><?php echo e(Str::limit($product->product_name, 20, '...')); ?></td>
                        <td><?php echo e($product->store->store_name); ?></td>
                        <td><?php echo e($product->created_at->DiffForHumans()); ?></td>
                        <td class="<?php echo e($product->status); ?>"><?php echo e($product->status); ?></td>
                        <td>
                            <form action="" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="product_id" value="<?php echo e(Crypt::encrypt($product->id)); ?>">


                                <a href="/whales/admin/show/product/<?php echo e($product->created_at->timestamp); ?>/<?php echo e($product->id); ?>"
                                    style="font-size: .7rem; background-color: rgb(0, 75, 128); color: #f1f1f1; cursor:pointer; padding: 5px; border: none; border-radius: .5rem;">Review</a>

                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>


    </div>
</div>
<?php /**PATH /var/www/wale/resources/views/Admin/dashboard.blade.php ENDPATH**/ ?>