<div class="nav-bar">
    <div class="start-menus">
        <div class="logo">
            <a href="/whales/admin/<?php echo e($user->public_name); ?>/show">
                <img src="data:image/png;base64,<?php echo e($icon['whale']); ?>" alt="">
            </a>
        </div>
        <div class="name">
            <a href="/whales/admin/<?php echo e($user->public_name); ?>/show"><span class="w">WHALES</span> <span
                    class="m">/Admin</span></a>
        </div>
    </div>
    <div class="end-menus">
        <div class="notification">
            <a href="/whales/admin/<?php echo e($user->public_name); ?>/show/messages" target="" rel="noopener noreferrer"> <img
                    src="data:image/png;base64,<?php echo e($icon['mail']); ?>" class="icon-filter" alt="Messages" width="25">
                <?php
                    $unread_messages = App\Models\MessageStatus::where('user_id', auth()->user()->id)
                        ->where('is_read', 0)
                        ->count();
                ?>
                <?php if($unread_messages > 0): ?>
                    <span class="new-notification"><?php echo e($unread_messages); ?></span>
                <?php endif; ?>
            </a>
        </div>
        <div class="notification">
            <a href="/whales/admin/<?php echo e($user->public_name); ?>/show/notifications" target="" rel="noopener noreferrer"> <img
                    src="data:image/png;base64,<?php echo e($icon['notification']); ?>" class="icon-filter" alt="Notification"
                    width="25">
                <?php if($user->notifications->where('is_read', 0)->count() > 0): ?>
                    <span class="new-notification"><?php echo e($user->notifications->where('is_read', 0)->count()); ?></span>
                <?php endif; ?>
                </span>
            </a>
        </div>
        <div class="notification">
            <a href="/whales/admin/<?php echo e($user->public_name); ?>/show/settings" target="" rel="noopener noreferrer"> <img
                    src="data:image/png;base64,<?php echo e($icon['settings']); ?>" class="icon-filter" alt="Setting"
                    width="25"></a>
        </div class="notification">
        <div>
            <a href="/logout"> <img src="data:image/png;base64,<?php echo e($icon['logout']); ?>"
                    class="icon-filter" alt="LogOut" width="25"></a>
        </div>
    </div>
</div>
<?php /**PATH /var/www/wale/resources/views/Admin/naveBar.blade.php ENDPATH**/ ?>