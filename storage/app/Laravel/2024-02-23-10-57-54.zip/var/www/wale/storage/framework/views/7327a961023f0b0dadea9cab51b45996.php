<div class="main-div">
    <div class="notific-container">
        <h1 class="notifications-h1" style="margin:0; padding:0px;;">_Blocked Stores_</h1>
        <p class="notifications-p">If you block a store you will not be able to see any of the store listings until you
            remove it from you blocked stores!!</p>
        <?php if(session('success')): ?>
            <p style="text-align: center; color: green;"><?php echo e(session('success')); ?></p>
        <?php endif; ?>
        <table>
            <thead>
                <tr>
                    <th>Store Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $user->blockedStores()->paginate(50); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blockedStore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><a
                                href="/store/<?php echo e($blockedStore->store->store_name); ?>/<?php echo e($blockedStore->store_id); ?>/"><?php echo e($blockedStore->store->store_name); ?></a>
                        </td>
                        <td>
                            <form action="/blocked/b_store/<?php echo e($blockedStore->id); ?>" method="post">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <input type="submit" name="submit" style="color: red; border: none; cursor: pointer;"
                                    value="remove">
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan='3'>No blocked store found</td>
                    </tr>
                <?php endif; ?>

            </tbody>
        </table>
        <?php echo e($user->blockedStores()->paginate(50)->render('vendor.pagination.custom_pagination')); ?>


    </div>
</div>
<?php /**PATH /var/www/wale/resources/views/User/blockedStore.blade.php ENDPATH**/ ?>