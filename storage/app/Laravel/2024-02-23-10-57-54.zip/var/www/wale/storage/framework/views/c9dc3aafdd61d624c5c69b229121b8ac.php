<h1>
    Market Functions</h1>

<div>
    <?php if(session('success') != null): ?>
        <p style="text-align: center; background: darkgreen; padding: 5px; border-radius: .5rem; color: #f1f1f1;">
            <?php echo e(session('success')); ?></p>
    <?php endif; ?>
    <?php if($errors->any): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p style="padding: 10px; margin: 10px; border-radius: .5rem; background-color: #dc3545">
                <?php echo e($error); ?>

            </p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Enable</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = \App\Models\MarketFunction::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $function): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>#<?php echo e($function->id); ?></td>
                <td><?php echo e($function->name); ?></td>
                <td>
                    <?php if($function->enable == 1): ?>
                        <span style="color:green; font-weight:900;">True</span>
                    <?php else: ?>
                        <span style="color:red; font-weight:900;">False</span>
                    <?php endif; ?>
                </td>
                <td>
                    <form action="" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" id="" value="<?php echo e($function->id); ?>">
                        <?php if($function->enable == 1): ?>
                            <input type="submit" name="disbale"
                                style="background-color:darkred; color:#f1f1f1; cursor:pointer;" id=""
                                value="Disable">
                        <?php else: ?>
                            <input type="submit" name="enabale"
                                style="background-color:darkgreen; color:#f1f1f1; cursor:pointer;" id=""
                                value="Enable">
                        <?php endif; ?>
                    </form>
                </td>

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH /var/www/wale/resources/views/Admin/functions.blade.php ENDPATH**/ ?>