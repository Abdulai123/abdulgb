<div class="nav-bar">
    <div class="start-menus">
        <div class="logo">
            <a href="/"><img src="data:image/png;base64,<?php echo e($icon['whale']); ?>"></a>
        </div>
        <div class="name">
            <a href="/"><span class="w">WHALES</span> <span class="m">MARKET</span></a>
        </div>
    </div>
    <div class="end-menus">
        <div class="notification" title="shopping cart">
            <a href="/cart" target="" rel="noopener noreferrer"> <img
                    src="data:image/png;base64,<?php echo e($icon['shopping-cart']); ?>" class="icon-filter" width="25">
                <span
                    class="<?php echo e($user->carts->count() > 0 ? 'cart-n-tr' : ''); ?>"><?php echo e($user->carts->count() > 0 ? $user->carts->count() : ''); ?></span>
            </a>
        </div>
        <div class="logout" title="open a store here">
            <a href="/open-store"> <img src="data:image/png;base64,<?php echo e($icon['add-store']); ?>" class="icon-filter"
                    width="25"></a>
        </div>
        <div class="my-hideout" title="user settings and control panel">
            <a href="#">Settings<img src="data:image/png;base64,<?php echo e($icon['down-arrow']); ?>" class="icon-filter"
                    width="25"></a>
            <ul class="hideout-menus">
                <li>
                    <h3>ACCOUNT</h3>
                    <ul>
                        <li><a href="/account/pgp"><img src="data:image/png;base64,<?php echo e($icon['shield']); ?>"
                                    class="icon-filter" width="25"> PGP KEY [2FA]</a></li>
                        <li><a href="/account/storeKey"><img src="data:image/png;base64,<?php echo e($icon['partnership']); ?>"
                                    class="icon-filter" width="25">Store key</a></li>
                        <li><a href="/account/changePassword"><img
                                    src="data:image/png;base64,<?php echo e($icon['change-management']); ?>" class="icon-filter"
                                    width="25"> Change
                                password</a></li>
                        <li><a href="/account/referral"><img src="data:image/png;base64,<?php echo e($icon['bonus']); ?>"
                                    class="icon-filter" width="25"> Referral Program</a></li>
                        <li><a href="/account/mirror">
                                <img src="" alt="🖇️" style="font-size:2em; margin-right:0px;"
                                    class="icon-filter"> Private URL Link</a></li>
                        <li><a href="/account/stats">
                                <img src="data:image/png;base64,<?php echo e($icon['monitoring']); ?>" alt=""
                                    style="font-size:2em; margin-right:0px;" class="icon-filter"> Your Stats</a></li>
                        <li>
                            <a href="/account/theme">
                                <?php if($user->theme == 'white'): ?>
                                    <img src="data:image/png;base64,<?php echo e($icon['night-mode']); ?>" class="icon-filter"
                                        width="25">

                                    Dark Mode
                                <?php else: ?>
                                    <img src="data:image/png;base64,<?php echo e($icon['brightness']); ?>" class="icon-filter"
                                        width="25">

                                    Light Mode
                                <?php endif; ?>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <h3>FAVORITES</h3>
                    <ul>
                        <li><a href="/favorite/f_store"><img src="data:image/png;base64,<?php echo e($icon['thumbs-up-fav']); ?>"
                                    class="icon-filter" width="25">Favorite stores</a>
                        </li>
                        <li><a href="/blocked/b_store"><img src="data:image/png;base64,<?php echo e($icon['thumbs-down-']); ?>"
                                    class="icon-filter" width="25">Blocked stores</a></li>
                        <li><a href="/favorite/f_listing"><img src="data:image/png;base64,<?php echo e($icon['love']); ?>"
                                    class="icon-filter" width="25">Favorite listings</a></li>
                    </ul>
                </li>
                <li>
                    <h3>WALLET</h3>
                    <ul>
                        <li><a href="/wallet/deposit"><img src="data:image/png;base64,<?php echo e($icon['deposit']); ?>"
                                    class="icon-filter" width="25"> Deposit</a></li>
                        <li><a href="/wallet/withdraw"><img src="data:image/png;base64,<?php echo e($icon['withdraw']); ?>"
                                    class="icon-filter" width="25"> Withdraw</a></li>
                    </ul>
                </li>
                <li>
                    <h3>SUPPORT</h3>
                    <ul>
                        <li><a href="/ticket"><img src="data:image/png;base64,<?php echo e($icon['plane-tickets']); ?>"
                                    class="icon-filter" width="25">Tickets</a>
                        </li>
                        <li><a href="/bugs"><img src="data:image/png;base64,<?php echo e($icon['web-coding']); ?>"
                                    class="icon-filter" width="25"> Report bugs</a></li>
                    </ul>
                </li>
                <li>
                    <h3>ORDERS</h3>
                    <ul>
                        <li><a href="/orders/all"><img src="data:image/png;base64,<?php echo e($icon['orders']); ?>"
                                    class="icon-filter" width="25"> All(<span
                                    style="color:blue"><?php echo e($user->orders->count()); ?></span>) </a></li>
                        <li><a href="/orders/pending"><img src="data:image/png;base64,<?php echo e($icon['wall-clock']); ?>"
                                    class="icon-filter" width="25"> Pending(<span
                                    style="color:blue"><?php echo e($user->orders->where('status', 'pending')->count()); ?></span>)</a>
                        </li>
                        <li><a href="/orders/dispatched"><img
                                    src="data:image/png;base64,<?php echo e($icon['fast-delivery']); ?>" class="icon-filter"
                                    width="25"> Dispatched(<span
                                    style="color:blue"><?php echo e($user->orders->where('status', 'dispatched')->count()); ?></span>)
                            </a></li>
                        <li><a href="/orders/completed"><img src="data:image/png;base64,<?php echo e($icon['success']); ?>"
                                    class="icon-filter" width="25"> Completed(<span
                                    style="color:blue"><?php echo e($user->orders->where('status', 'completed')->count()); ?></span>)
                            </a></li>
                        <li><a href="/orders/dispute"><img src="data:image/png;base64,<?php echo e($icon['dispute']); ?>"
                                    class="icon-filter" width="25">Disputed(<span
                                    style="color:blue"><?php echo e($user->orders->where('status', 'dispute')->count()); ?></span>)
                            </a></li>
                        <li><a href="/orders/cancelled"><img src="data:image/png;base64,<?php echo e($icon['close']); ?>"
                                    class="icon-filter" width="25">Cancelled(<span
                                    style="color:blue"><?php echo e($user->orders->where('status', 'cancelled')->count()); ?></span>)
                            </a></li>
                    </ul>
                </li>
                <li>
                    <h3>OTHERS</h3>
                    <ul>
                        <li><a href="/open-store"><img src="data:image/png;base64,<?php echo e($icon['add-store']); ?>"
                                    class="icon-filter" width="25"> Open store</a></li>
                        <li><a href="/canary"> <img src="data:image/png;base64,<?php echo e($icon['document']); ?>"
                                    class="icon-filter" width="25"> Canary & PGP</a></li>
                        <li><a href="/faq"><img src="data:image/png;base64,<?php echo e($icon['faq']); ?>"
                                    class="icon-filter" width="25"> F.A.Q</a></li>
                        <?php
                            $unreadNews = 0;
                            $allNews = \App\Models\News::all();

                            foreach ($allNews as $news) {
                                $isUnread = true;

                                foreach ($user->newsStatuses as $status) {
                                    if ($status != null && $news->id == $status->news_id) {
                                        $isUnread = false;
                                        break;
                                    }
                                }

                                if ($isUnread) {
                                    $unreadNews += 1;
                                }
                            }
                        ?>

                        <li><a href="/news"><img src="data:image/png;base64,<?php echo e($icon['news']); ?>"
                                    class="icon-filter" width="25"> News( <span
                                    style="color: <?php echo e($unreadNews > 0 ? 'red' : ''); ?>; font-weight: <?php echo e($unreadNews > 0 ? 'bold' : 'normal'); ?>"
                                    class="<?php echo e($unreadNews > 0 ? 'blink' : ''); ?>"><?php echo e($unreadNews); ?></span> )</a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
        <div class="notification" title="messages">
            <a href="/messages" target="" rel="noopener noreferrer">
                <img src="data:image/png;base64,<?php echo e($icon['mail']); ?>" class="icon-filter" width="25">
                <?php
                    $unread_messages = App\Models\MessageStatus::where('user_id', $user->id)
                        ->where('is_read', 0)
                        ->count();
                ?>
                <?php if($unread_messages > 0): ?>
                    <span class="new-notification"><?php echo e($unread_messages); ?></span>
                <?php endif; ?>
            </a>
        </div>
        <div class="notification" title="notifications">
            <a href="/notification" target="" rel="noopener noreferrer">
                <img src="data:image/png;base64,<?php echo e($icon['notification']); ?>" class="icon-filter" width="25">
                <?php if($user->notifications->where('is_read', 0)->count() > 0): ?>
                    <span class="new-notification"><?php echo e($user->notifications->where('is_read', 0)->count()); ?></span>
                <?php endif; ?>
            </a>
        </div>
        <div class="logout" title="logout">
            <a href="/logout"> <img src="data:image/png;base64,<?php echo e($icon['logout']); ?>" class="icon-filter"
                    width="25"></a>
        </div>
    </div>
</div>
<?php /**PATH /var/www/wale/resources/views/User/navebar.blade.php ENDPATH**/ ?>