<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Whales Market | <?php echo e($name); ?> > <?php echo e($action); ?></title>
    <?php if($user->theme == 'dark'): ?>
    <link rel="stylesheet" href="<?php echo e(asset('dark.theme.css')); ?>">
<?php else: ?>
    <link rel="stylesheet" href="<?php echo e(asset('white.theme.css')); ?>">
<?php endif; ?>
<link rel="stylesheet" href="<?php echo e(asset('market.white.css')); ?>">
<meta http-equiv="refresh" content="<?php echo e(session('session_timer')); ?>;url=/kick/<?php echo e($user->public_name); ?>/out">

    <link rel="stylesheet" href="<?php echo e(asset('filter.css')); ?>">
</head>

<body>
    <?php echo $__env->make('User.navebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <div class="main-div">
            <div class="notific-container">
                <p class="message-heading"> Reference:
                    <?php echo e('#MWM_' . $conversation->created_at->timestamp); ?>

                </p>
                <p style="font-size: .8rem; color: #acacac; text-align:center; margin: .3em 0px;"> <span>Subject:
                    </span>
                    <?php echo e($conversation->topic); ?></p>
                    <p style="text-align: center">People who has leave this chat: 
                        <?php $__empty_1 = true; $__currentLoopData = \App\Models\Participant::where('conversation_id', $conversation->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php if($participant->is_hidden == 1): ?>
                                <span style="color:red;">[<?php echo e($participant->user->role == 'store' ? '/store/'.$participant->user->store->store_name : '/'.$participant->user->role.'/'.$participant->user->public_name); ?>], </span>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
                <?php $__currentLoopData = $conversation->messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($message->message_type == 'ticket'): ?>
                        <p style="text-transform:capitalize; text-align:center; margin: .3em 0px;"
                            class="<?php echo e($conversation->support->status); ?>">Status:
                            <?php echo e($conversation->support->status); ?></p>
                    <?php break; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($errors->any): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p style="color: red; text-align:cenetr;"><?php echo e($error); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(session('ticket_closed')): ?>
                <p style="color: red; text-align:center;">The ticket you are replying to has been closed!!!</p>
            <?php endif; ?>
            <?php if(session('new_message')): ?>
                <div>
                    <form action="" method="post" class="message-reply-form">
                        <?php echo csrf_field(); ?>
                        <textarea name="contents" class="support-msg" placeholder="Write your reply here... max 5K characters!" cols="30"
                            rows="10" required></textarea>
                        <input type="hidden" name="message_type"
                            <?php $latestMessage = $conversation->messages()->latest()->first(); ?>
                            value="<?php echo e($latestMessage->message_type); ?>">

                        <input type="submit" class="submit-nxt" value="Send">
                    </form>
                </div>
            <?php else: ?>
                <div style="text-align: center; margin-bottom: 1em;">
                    <form action="" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="submit" name="new_message" value="New Reply" class="input-listing">
                    </form>
                </div>
            <?php endif; ?>

            <div class="message-div">
                <?php $__currentLoopData = $conversation->messages->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($message->user_id != null): ?>
                        <div
                            class="chat-message <?php if($message->user->id === $user->id): ?> <?php echo e('message-right'); ?> <?php else: ?> <?php echo e('message-left'); ?> <?php endif; ?>">
                            <p><?php echo e($message->content); ?></p>
                            <p class="owner "> <span
                                    class="<?php echo e($message->user->role == 'store' ? 'storem' : $message->user->role); ?>"
                                    style="margin-right:1em">
                                    /<?php if($message->user->role == 'junior' || $message->user->role == 'senior'): ?>
                                        <?php echo e($message->user->role . ' mod'); ?>

                                    <?php else: ?>
                                        <?php echo e($message->user->role); ?>

                                    <?php endif; ?>/<?php echo e($message->user->public_name); ?> </span>

                                <?php $__currentLoopData = $message->status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($status->user_id != $user->id && $status->user_id != $message->user->id): ?>
                                        <span
                                            class="<?php echo e($status->is_read == 1 ? 'message-read' : 'message-unread'); ?>">[<?php echo e($status->user->role == 'store' ? $status->user->store->store_name : $status->user->public_name); ?>

                                            <?php echo e($status->is_read == 1 ? 'read' : 'unread'); ?>], </span>
                                    <?php elseif($status->user_id == $user->id && $status->user_id != $message->user->id): ?>
                                        <span
                                            class="<?php echo e($status->is_read == 1 ? 'message-read' : 'message-unread'); ?>">[<?php echo e($status->user->role == 'store' ? $status->user->store->store_name : $status->user->public_name); ?>

                                            <?php echo e($status->is_read == 1 ? 'read' : 'unread'); ?>], </span>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                sent <?php echo e($message->created_at->diffForHumans()); ?>

                            </p>
                        </div>
                    <?php else: ?>
                        <div class="chat-message message-left">
                            <p><?php echo e($message->content); ?></p>
                            <p class="owner"> <span class="senior" style="margin-right:1em">/mod/System Mod</span>
                                <?php $__currentLoopData = $message->status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span
                                        class="<?php echo e($status->is_read == 1 ? 'message-read' : 'message-unread'); ?>">[<?php echo e($status->user->role == 'store' ? $status->user->store->store_name : $status->user->public_name); ?>

                                        <?php echo e($status->is_read == 1 ? 'read' : 'unread'); ?>], </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                sent <?php echo e($message->created_at->diffForHumans()); ?>

                            </p>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <?php echo $__env->make('User.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH /var/www/wale/resources/views/User/displayMessages.blade.php ENDPATH**/ ?>