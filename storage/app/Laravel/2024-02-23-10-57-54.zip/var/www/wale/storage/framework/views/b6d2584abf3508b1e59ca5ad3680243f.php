<div class="categories search-div">
    <h2><img src="data:image/png;base64,<?php echo e($icon['category']); ?>" class="icon-filter" width="25"> CATEGORIES</h2>
    <ul>


        <?php $__currentLoopData = $parentCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="/parent/category/<?php echo e($parent_category->created_at->timestamp); ?>/<?php echo e($parent_category->id); ?>">
                    <img src="data:image/png;base64,<?php echo e($icon['right']); ?>" class="icon-filter" width="25">
                    <?php echo e($parent_category->name); ?>

                </a>
                <span class="count"><?php echo e($parent_category->parentProducts()->where('status', 'Active')->count()); ?></span>
                <ul class="sub-cat-ul">
                    <?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($parent_category->id === $sub_category->parent_category_id): ?>
                            <li class="sub-cat-li"><a href="/sub/category/<?php echo e($sub_category->created_at->timestamp); ?>/<?php echo e($sub_category->id); ?>">
                                    <img src="data:image/png;base64,<?php echo e($icon['right']); ?>" class="icon-filter"
                                        width="25">
                                    <?php echo e($sub_category->name); ?></a>
                                <span class="count"><?php echo e($sub_category->subProducts()->where('status', 'Active')->count()); ?></span>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php /**PATH /var/www/wale/resources/views/User/categories.blade.php ENDPATH**/ ?>