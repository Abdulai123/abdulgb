<h1 style="text-align: center;">Conversations(<?php echo e($conversations->count()); ?>)</h1>

<table>
    <thead>
        <tr>
            <th>Sort By</th>
            <th>Number Of Rows</th>
            <th>D0</th>
        </tr>
    </thead>
    <tbody>
        <form action="/whales/admin/<?php echo e($user->public_name); ?>/show/conversations/search" method="get" style="text-align: center">
            <tr>
                <td>
                    <select name="sort_by" id="sort_by">
                        <option value="newest" <?php echo e(old('sort_by') == 'newest' ? 'selected' : ''); ?>>Newest</option>
                        <option value="archive" <?php echo e(old('sort_by') == 'archive' ? 'selected' : ''); ?>>All Archived</option>
                        <option value="highest_messages" <?php echo e(old('sort_by') == 'highest_messages' ? 'selected' : ''); ?>>Highest Messages</option>
                        <option value="oldest" <?php echo e(old('sort_by') == 'oldest' ? 'selected' : ''); ?>>Oldest</option>
                    </select>
                </td>
                <td>
                    <select name="number_of_rows" id="number_of_rows">
                        <option value="50" <?php echo e(old('number_of_rows') == '50' ? 'selected' : ''); ?>>50</option>
                        <option value="100" <?php echo e(old('number_of_rows') == '100' ? 'selected' : ''); ?>>100</option>
                        <option value="150" <?php echo e(old('number_of_rows') == '150' ? 'selected' : ''); ?>>150</option>
                        <option value="250" <?php echo e(old('number_of_rows') == '250' ? 'selected' : ''); ?>>250</option>
                    </select>
                </td>
                <td style="text-align: center; margin:0px; padding:0px;">
                    <input type="submit" class="submit-nxt" style="width: max-content; margin:0px; padding:.5em;"
                    value="Perform">
                </td>
            </tr>
        </form>
    </tbody>
</table>

<table>
    <thead>
        <tr>
            <th>#ID</th>
            <th>Topic</th>
            <th>Total Messages</th>
            <th>Participants Count</th>
            <th>Participants</th>
            <th>Archived By</th>
            <th>Created At</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $conversations = session('conversations') ?? $conversations;
        ?>
        <?php $__empty_1 = true; $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="self-container">
                <td>#<?php echo e($conversation->id); ?></td>
                <td><?php echo e($conversation->topic); ?></td>
                <td><?php echo e($conversation->messages->count()); ?></td>
               <td><?php echo e($conversation->participants->count()); ?></td>
               <td>
                <?php $__currentLoopData = $conversation->participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span>/<?php echo e($key->user->role); ?>/<?php echo e($key->user->public_name); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            
               <td><?php echo e($conversation->participants->where('is_hidden', 1)->count()); ?></td>
               <td><?php echo e($conversation->created_at->DiffForHumans()); ?></td>
               <td><form action="" method="post"> <?php echo csrf_field(); ?> <input type="hidden" name="id" value="<?php echo e($conversation->id); ?>"><input type="submit" value="Delete" name="detele" style="color:red; cursor:pointer;"></form></td>
            </tr>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <tr>
            <td colspan="10">
                <span class="no-notification">
                    Conversations is currently empty.
                </span>
            </td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>
<?php echo e($conversations->render('vendor.pagination.custom_pagination')); ?>

<?php /**PATH /var/www/wale/resources/views/Admin/conversations.blade.php ENDPATH**/ ?>