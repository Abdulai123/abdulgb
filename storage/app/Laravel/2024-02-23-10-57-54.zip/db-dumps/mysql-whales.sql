
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `wallet_id` bigint unsigned NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `expired` tinyint(1) NOT NULL DEFAULT '0',
  `is_confirm` tinyint(1) NOT NULL DEFAULT '0',
  `is_detected` tinyint(1) NOT NULL DEFAULT '0',
  `is_failed` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `addresses_wallet_id_foreign` (`wallet_id`),
  CONSTRAINT `addresses_wallet_id_foreign` FOREIGN KEY (`wallet_id`) REFERENCES `wallets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
INSERT INTO `addresses` VALUES (1,2,'84FpcMdPSFZB5MCGRUNCM5MvrMyBSWoqv46aUakLUWnHF8FwYLAG6osNj6xRmbkY5ogbGnd96w9U84XZigF74w3PHoP3Ggf',1,1,1,0,'2024-02-15 03:30:41','2024-02-15 04:03:51');
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `block_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `block_stores` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `store_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `block_stores_user_id_foreign` (`user_id`),
  KEY `block_stores_store_id_foreign` (`store_id`),
  CONSTRAINT `block_stores_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `block_stores_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `block_stores` WRITE;
/*!40000 ALTER TABLE `block_stores` DISABLE KEYS */;
/*!40000 ALTER TABLE `block_stores` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bugs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','valid','invalid','paid') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bugs_user_id_foreign` (`user_id`),
  CONSTRAINT `bugs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bugs` WRITE;
/*!40000 ALTER TABLE `bugs` DISABLE KEYS */;
/*!40000 ALTER TABLE `bugs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `carts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `carts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `quantity` int unsigned NOT NULL DEFAULT '1',
  `note` longtext COLLATE utf8mb4_unicode_ci,
  `extra_option_id` int unsigned DEFAULT NULL,
  `discount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `carts_user_id_foreign` (`user_id`),
  KEY `carts_product_id_foreign` (`product_id`),
  CONSTRAINT `carts_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `carts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `carts` WRITE;
/*!40000 ALTER TABLE `carts` DISABLE KEYS */;
/*!40000 ALTER TABLE `carts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_category_id` bigint unsigned DEFAULT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'CyberSecurity',NULL,NULL,'active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(2,'Educational Resources',NULL,NULL,'active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(3,'Web Development & Design',NULL,NULL,'active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(4,'Precious Commodities',NULL,NULL,'active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(5,'Drugs & Chemicals',NULL,NULL,'active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(6,'Goods & Services',NULL,NULL,'active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(7,'Other Listings',NULL,NULL,'active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(8,'Hacking & Spam',1,'CyberSecurity','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(9,'Fraud',1,'CyberSecurity','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(10,'Malware',1,'CyberSecurity','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(11,'Carded Items',1,'CyberSecurity','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(12,'Counterfeit Items',1,'CyberSecurity','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(13,'Security',1,'CyberSecurity','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(14,'Others',1,'CyberSecurity','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(15,'Guides & Tutorials',2,'Educational Resources','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(16,'Software',2,'Educational Resources','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(17,'Others',2,'Educational Resources','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(18,'Hosting',3,'Web Development & Design','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(19,'Websites',3,'Web Development & Design','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(20,'Graphics Design',3,'Web Development & Design','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(21,'Others',3,'Web Development & Design','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(22,'Jewels',4,'Precious Commodities','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(23,'Gold & Precious Metals',4,'Precious Commodities','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(24,'Others',4,'Precious Commodities','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(25,'Cannabis',5,'Drugs & Chemicals','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(26,'Opiates',5,'Drugs & Chemicals','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(27,'Stimulants',5,'Drugs & Chemicals','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(28,'Psychedelics',5,'Drugs & Chemicals','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(29,'Ecstasy',5,'Drugs & Chemicals','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(30,'Benzodiazepines',5,'Drugs & Chemicals','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(31,'Psychedelics',5,'Drugs & Chemicals','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(32,'Prescriptions',5,'Drugs & Chemicals','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(33,'Steroids',5,'Drugs & Chemicals','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(34,'Dissociatives',5,'Drugs & Chemicals','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(35,'Designer drugs',5,'Drugs & Chemicals','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(36,'Chemicals',5,'Drugs & Chemicals','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(37,'Tobacco',5,'Drugs & Chemicals','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(38,'Alcohols',5,'Drugs & Chemicals','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(39,'Others',5,'Drugs & Chemicals','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(40,'Legitimate Items',6,'Goods & Services','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(41,'Automotive Items',6,'Goods & Services','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(42,'Digital Products',6,'Goods & Services','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(43,'Services',6,'Goods & Services','active','2024-02-15 00:31:33','2024-02-15 00:31:33'),(44,'Others',6,'Goods & Services','active','2024-02-15 00:31:33','2024-02-15 00:31:33');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conversations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `topic` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `conversations` WRITE;
/*!40000 ALTER TABLE `conversations` DISABLE KEYS */;
/*!40000 ALTER TABLE `conversations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `deposits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deposits` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `wallet_id` bigint unsigned NOT NULL,
  `amount` decimal(12,4) NOT NULL,
  `txid` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `deposits_wallet_id_foreign` (`wallet_id`),
  CONSTRAINT `deposits_wallet_id_foreign` FOREIGN KEY (`wallet_id`) REFERENCES `wallets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `deposits` WRITE;
/*!40000 ALTER TABLE `deposits` DISABLE KEYS */;
INSERT INTO `deposits` VALUES (1,2,0.0000,'57f51445090dcf675f2d356e8d7f2bc1c787ac6e613133b11733a7c3669b7b07','2024-02-15 04:03:51','2024-02-15 04:03:51');
/*!40000 ALTER TABLE `deposits` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `disputes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `disputes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `escrow_id` bigint unsigned DEFAULT NULL,
  `order_id` bigint unsigned NOT NULL,
  `mediator_id` bigint unsigned DEFAULT NULL,
  `conversation_id` bigint unsigned NOT NULL,
  `user_partial_percent` int DEFAULT NULL,
  `store_partial_percent` int DEFAULT NULL,
  `mediator_request` tinyint(1) NOT NULL DEFAULT '0',
  `status` enum('open','Full Refund','Partial Refund','closed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `winner` enum('none','store','user','both') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `user_refund_accept` tinyint(1) NOT NULL DEFAULT '0',
  `store_refund_accept` tinyint(1) NOT NULL DEFAULT '0',
  `user_refund_reject` tinyint(1) NOT NULL DEFAULT '0',
  `store_refund_reject` tinyint(1) NOT NULL DEFAULT '0',
  `refund_initiated` enum('User','Store','staff','none') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `disputes_escrow_id_foreign` (`escrow_id`),
  KEY `disputes_order_id_foreign` (`order_id`),
  KEY `disputes_mediator_id_foreign` (`mediator_id`),
  KEY `disputes_conversation_id_foreign` (`conversation_id`),
  CONSTRAINT `disputes_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `disputes_escrow_id_foreign` FOREIGN KEY (`escrow_id`) REFERENCES `escrows` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `disputes_mediator_id_foreign` FOREIGN KEY (`mediator_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `disputes_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `disputes` WRITE;
/*!40000 ALTER TABLE `disputes` DISABLE KEYS */;
/*!40000 ALTER TABLE `disputes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `escrows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `escrows` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `fiat_amount` decimal(32,2) NOT NULL,
  `status` enum('active','released','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `escrows_order_id_index` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `escrows` WRITE;
/*!40000 ALTER TABLE `escrows` DISABLE KEYS */;
/*!40000 ALTER TABLE `escrows` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `extra_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `extra_options` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `extra_options_product_id_foreign` (`product_id`),
  CONSTRAINT `extra_options_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `extra_options` WRITE;
/*!40000 ALTER TABLE `extra_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `extra_options` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `f_a_q_s`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `f_a_q_s` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `question` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_publish` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `f_a_q_s_user_id_foreign` (`user_id`),
  CONSTRAINT `f_a_q_s_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `f_a_q_s` WRITE;
/*!40000 ALTER TABLE `f_a_q_s` DISABLE KEYS */;
INSERT INTO `f_a_q_s` VALUES (1,1,'What is Whales Market?','Whales Market is an online marketplace that allows users to buy and sell products, both digital and physical. It provides a platform for sellers to list their products after verification by admins or mods.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(2,1,'How can I sell (open a store) on Whales Market?','To open a store on Whales Market, you need a store key (64-128 characters) to encrypt your information. Click on the store icon, provide your information and store key, and ensure your 2FA is enabled and matches your public name. You can purchase or ask for waiver a store key in the \"Setting > store key\" and receive a notification with your store key after payment or waiver accepted.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(3,1,'Can I list both digital and physical products in my store?','Yes, Whales Market allows stores to list both digital and physical products. Whether you are offering digital content or tangible items, you can showcase your products within your verified store on the platform.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(4,1,'What are the guidelines for listing products on Whales Market?','Stores are required to adhere to specific guidelines when listing products on Whales Market. These guidelines may include providing accurate product descriptions, using high-quality images, removing meta data from images and ensuring that the products align with the theme of the marketplace rules.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(5,1,'How does the moderation process work for product listings?','The moderation process involves a review of product listings to ensure they meet the platform\'s standards. This includes verifying the accuracy of product information, images, and adherence to content policies. Stores are notified of any necessary adjustments or approvals.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(6,1,'Are there any restrictions on the types of products that can be sold on Whales Market?','While Whales Market encourages a diverse range of products, there are many restrictions on certain items. Stores should review the platforms policies(rules) to understand any limitations on product categories or content.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(7,1,'Can I update my store information after it has been active?','Yes, sellers can update their store information, including product listings, even after the initial verification process. It is essential to keep your store details accurate and up-to-date to provide a positive experience for buyers.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(8,1,'How can buyers trust the authenticity of products on Whales Market?','Whales Markets verification process for sellers and product listings is designed to build trust. Buyers can look for store rating and reviews and ratings contribute to the overall transparency and reliability of the marketplace,.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(9,1,'What is the difference between a store and a regular user account on Whales Market?','A store on Whales Market is an advanced account type designed for sellers. It comes with a dedicated dashboard that provides powerful tools for managing products and sales. When your store is active, you have exclusive access to your personalized dashboard, limiting your interaction with the general marketplace features.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(10,1,'Can I still access the main market while my store is active?','No, when your store is active, your access is limited to the stores dashboard. This exclusive environment allows you to focus on managing your products, sales, and other essential tasks without being distracted by unrelated marketplace activities. If you wish to browse or participate in the main market, you can create another account specifically for that purpose.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(11,1,'What tools are available in the stores dashboard for sellers?','The stores dashboard on Whales Market is equipped with powerful tools tailored for sellers. These may include inventory management, order processing, sales analytics, and promotional features, store share access, coupons system and more. Sellers can efficiently handle their store operations and monitor their performance through a centralized and user-friendly interface.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(12,1,'What happens if my store is inactive or suspended?','If your store is inactive or suspended due to violations or other reasons, your access to the stores dashboard will be restricted. You may receive notifications and instructions on how to address the issues causing the inactivity. Resolving these issues will enable you to reactivate your store and regain access to the seller dashboard.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(13,1,'What is Vacation Mode on Whales Market?','Vacation Mode is a feature on Whales Market that allows sellers to temporarily deactivate their store. This is useful for sellers who anticipate being inactive for a specific period, such as vacations or temporary breaks.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(14,1,'How do I activate Vacation Mode for my store?','To activate Vacation Mode, log in to your store\'s dashboard, navigate to settings, and look for the Vacation Mode option, and set it.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(15,1,'Can I still access my store\'s dashboard while it\'s in Vacation Mode?','Yes, sellers can still access their store\'s dashboard while in Vacation Mode. However, the store will not be visible to buyers, and transactions will be temporarily disabled.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(16,1,'What happens to my existing listings and products during Vacation Mode?','While your store is in Vacation Mode, your existing listings and products will remain on the platform but will be temporarily hidden from buyers. This ensures that your store retains its presence, and buyers are aware of your temporary absence.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(17,1,'Are there any restrictions on how often I can use Vacation Mode?','Whales Market does not impose strict restrictions on the frequency of using Vacation Mode. Sellers can use this feature as needed, but it\'s recommended to use it judiciously to ensure a positive experience for both sellers and buyers.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(18,1,' What is the Dispute System on Whales Market?','The Dispute System on Whales Market is a comprehensive feature designed to facilitate quick and fair resolutions in case of conflicts between buyers and sellers. It acts as a mechanism to address issues related to transactions without the immediate involvement of a moderator.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(19,1,'How does the Dispute System work on Whales Market?','In the event of a dispute, either the buyer or the seller can initiate the resolution process through the Dispute System. The platform provides a user-friendly interface where users can submit details about the issue, including evidence such as messages, it also has a messaging system, with sleek functions.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(20,1,'What tools are available in the Dispute System for both buyers and sellers?','The Dispute System comes with a full set of features for both buyers and sellers. Users can present their case, provide evidence, and engage in communication directly through the system. This includes the ability to message, accept refunds, start partial refund, percentage system, decline partial, release funds, request mods, and more.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(21,1,'Can I request the assistance of a moderator in a dispute?','Yes, while the Dispute System is designed to allow users to resolve issues independently, there is an option to request moderator intervention. This button serves as a safety net, ensuring that if the dispute cannot be resolved directly between the parties, a moderator can step in to provide assistance and make a final decision.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(22,1,'What is the Whales Market Auto-Delete System?','The Whales Market Auto-Delete System is a feature designed to automatically remove specific types of messages after a designated period. This helps keep top security, conversations and transactions organized by removing outdated or completed information.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(23,1,'Which are subject to auto-deletion on Whales Market?','The Auto-Delete System targets read messages, completed transactions, closed disputes, and canceled orders. These are automatically removed from the platform after 15 days, streamlining the communication channels, reducing clutter and improving higher security.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(24,1,'What is the Auto-Cancellation System on Whales Market?','The Auto-Cancellation System on Whales Market is designed to automatically cancel orders that have been pending for 72 hours. In the event of non-action within this timeframe, the system initiates the cancellation process and refunds the money to the buyer.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(25,1,'Can users extend the 72-hour auto-cancellation timeframe?','Yes, users have the option to extend the auto-cancellation timeframe by an additional 72 hours if the order has not been canceled. This flexibility allows for adjustments in case there are valid reasons to delay the cancellation process.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(26,1,'How does the Auto-Release System work on Whales Market?','The Auto-Release System on Whales Market automatically releases funds for orders that have been marked by the store as delivered, sent, or dispatched. If there is no further action within 72 hours, the system completes the release, transferring the funds to the store.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(27,1,'What is the Auto-Cancellation System on Whales Market?','The Auto-Cancellation System on Whales Market automatically cancels orders pending for 72 hours. Users can extend the period for an additional 72 hours if necessary. It ensures a smooth cancellation process and refunds the money to the buyer.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(28,1,'Is there an option to extend the 72-hour auto-release timeframe?','Yes, similar to the auto-cancellation feature, users can extend the 72-hour auto-release timeframe if necessary. This gives both buyers and sellers the flexibility to accommodate specific situations that may cause delays in the order completion process.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(29,1,'How many support tickets can I create per day for regular user-related issues?','Regular users are limited to creating a maximum of three support tickets per day for their inquiries or issues.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(30,1,'Is there a support ticket limit for stores on Whales Market?','Yes, stores on Whales Market can create up to five support tickets per day to address their specific concerns or inquiries.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(31,1,'What should I do if I find a bug on Whales Market?','If you encounter a bug on Whales Market, navigate to the settings menu and look for the \"Bug Report\" option. Use this feature to report the bug by providing detailed information, including steps to reproduce the issue. Whales Market encourages users to share comprehensive details for a more effective resolution.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(32,1,'Are there any incentives for reporting bugs on Whales Market?','Yes, Whales Market values the contribution of users in identifying and reporting bugs. Users who report bugs and provide helpful information may be eligible for rewards or prizes. This encourages active participation in enhancing the platform\'s functionality.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(33,1,'Why doesn\'t Whales Market integrate third-party apps for notifications?','Whales Market has a powerful and integrated notifications system that covers almost all changes made within the platform. To ensure security, efficiency, and a seamless user experience, the platform does not incorporate third-party apps for notifications.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(34,1,'How do I deposit funds into my Whales Market account?','To deposit funds, go to the settings menu and look for the \"Deposit\" option on Whales Market. Follow the provided steps, and you can make a deposit without incurring any fees or having a minimum deposit requirement. Ensure you use the provided deposit address only once for security reasons.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(35,1,'Can I use the deposit address multiple times?','For security reasons, Whales Market recommends using the deposit address provided only once. Generating a new deposit address for each transaction enhances the security of your funds.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(36,1,'How do I withdraw funds from my Whales Market account?','To withdraw funds, navigate to the settings menu and look for the \"Withdraw\" option on Whales Market. Follow the provided steps to initiate a withdrawal. Note that Whales Market does not charge any fees for withdrawals, and there is no minimum withdrawal requirement.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(37,1,'How long does it take for a withdrawal to be processed on Whales Market?','The withdrawal time frame on Whales Market can vary depending on network conditions. Once initiated, withdrawals are typically processed promptly. Users are encouraged to check their transaction history for updates on the withdrawal status.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(38,1,'Are there any restrictions on the number of withdrawals I can make per day?','Whales Market typically does not impose restrictions on the number of withdrawals a user can make per day. Users can withdraw funds based on their preferences and needs.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(39,1,'Why is 2FA (Two-Factor Authentication) required for opening a store on Whales Market?','2FA is required to enhance the security of your store on Whales Market. It ensures that only authorized users with the correct authentication method can access and manage the store. Make sure your 2FA is enabled and matches your public name.',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(40,1,'What should I do if I encounter issues while opening my store on Whales Market?','If you encounter issues while opening your store, you can reach out to Whales Market support for assistance. They can provide guidance, address concerns, and ensure a smooth process for setting up your store',0,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(41,1,'What should I know','Stay safe, find Harm Reduction on dread, find DarkNet user bible on dread, stay conneceted on dread and pitch forums!',0,'2024-02-15 00:31:36','2024-02-15 00:31:36');
/*!40000 ALTER TABLE `f_a_q_s` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `favorite_listings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `favorite_listings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `favorite_listings_user_id_foreign` (`user_id`),
  KEY `favorite_listings_product_id_foreign` (`product_id`),
  CONSTRAINT `favorite_listings_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `favorite_listings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `favorite_listings` WRITE;
/*!40000 ALTER TABLE `favorite_listings` DISABLE KEYS */;
/*!40000 ALTER TABLE `favorite_listings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `favorite_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `favorite_stores` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `store_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `favorite_stores_user_id_foreign` (`user_id`),
  KEY `favorite_stores_store_id_foreign` (`store_id`),
  CONSTRAINT `favorite_stores_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `favorite_stores_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `favorite_stores` WRITE;
/*!40000 ALTER TABLE `favorite_stores` DISABLE KEYS */;
/*!40000 ALTER TABLE `favorite_stores` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `featureds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `featureds` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `featureds_product_id_foreign` (`product_id`),
  CONSTRAINT `featureds_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `featureds` WRITE;
/*!40000 ALTER TABLE `featureds` DISABLE KEYS */;
/*!40000 ALTER TABLE `featureds` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `feed_backs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feed_backs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `store_id` bigint unsigned NOT NULL,
  `communications` int NOT NULL DEFAULT '0',
  `review` int NOT NULL DEFAULT '0',
  `rating` int NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `feed_backs_user_id_foreign` (`user_id`),
  KEY `feed_backs_product_id_foreign` (`product_id`),
  KEY `feed_backs_store_id_foreign` (`store_id`),
  CONSTRAINT `feed_backs_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `feed_backs_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `feed_backs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `feed_backs` WRITE;
/*!40000 ALTER TABLE `feed_backs` DISABLE KEYS */;
/*!40000 ALTER TABLE `feed_backs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `links` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descriptions` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `links` WRITE;
/*!40000 ALTER TABLE `links` DISABLE KEYS */;
/*!40000 ALTER TABLE `links` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `market_functions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `market_functions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enable` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `market_functions` WRITE;
/*!40000 ALTER TABLE `market_functions` DISABLE KEYS */;
INSERT INTO `market_functions` VALUES (1,'login',1,'2024-02-15 00:31:34','2024-02-15 00:31:34'),(2,'signup',1,'2024-02-15 00:31:34','2024-02-15 00:31:34'),(3,'waiver',1,'2024-02-15 00:31:34','2024-02-15 00:31:34'),(4,'cashback',1,'2024-02-15 00:31:34','2024-02-15 00:31:34'),(5,'wallet',0,'2024-02-15 00:31:34','2024-02-16 09:57:34'),(6,'withdraw',0,'2024-02-15 00:31:34','2024-02-16 09:57:42'),(7,'deposit',0,'2024-02-15 00:31:34','2024-02-16 09:57:48'),(8,'storekey',1,'2024-02-15 00:31:34','2024-02-15 00:31:34'),(9,'api',0,'2024-02-15 00:31:34','2024-02-16 09:57:38');
/*!40000 ALTER TABLE `market_functions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `market_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `market_keys` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `message_sign` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `public_key` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `market_keys_user_id_foreign` (`user_id`),
  CONSTRAINT `market_keys_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `market_keys` WRITE;
/*!40000 ALTER TABLE `market_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `market_keys` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `message_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_statuses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `message_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `is_read` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `message_statuses_message_id_foreign` (`message_id`),
  KEY `message_statuses_user_id_foreign` (`user_id`),
  CONSTRAINT `message_statuses_message_id_foreign` FOREIGN KEY (`message_id`) REFERENCES `messages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `message_statuses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `message_statuses` WRITE;
/*!40000 ALTER TABLE `message_statuses` DISABLE KEYS */;
/*!40000 ALTER TABLE `message_statuses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `conversation_id` bigint unsigned NOT NULL,
  `message_type` enum('message','ticket','dispute','mass','staff') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'message',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `messages_user_id_foreign` (`user_id`),
  KEY `messages_conversation_id_foreign` (`conversation_id`),
  CONSTRAINT `messages_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `messages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=445 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (384,'2024_01_08_080259_create_deposits_table',1),(385,'2024_01_08_080313_create_withdraws_table',1),(392,'2024_01_31_114525_create_withdrawals_table',2),(394,'2014_10_12_100000_create_password_reset_tokens_table',3),(395,'2019_08_19_000000_create_failed_jobs_table',3),(396,'2019_12_14_000001_create_personal_access_tokens_table',3),(397,'2023_11_07_091552_create_users_table',3),(398,'2023_11_07_091625_create_stores_table',3),(399,'2023_11_07_091719_create_categories_table',3),(400,'2023_11_07_091720_create_products_table',3),(401,'2023_11_07_091802_create_conversations_table',3),(402,'2023_11_07_091804_create_supports_table',3),(403,'2023_11_07_091839_create_new_stores_table',3),(404,'2023_11_07_091908_create_reviews_table',3),(405,'2023_11_07_091917_create_feed_backs_table',3),(406,'2023_11_07_102802_create_replies_table',3),(407,'2023_11_07_103121_create_extra_options_table',3),(408,'2023_11_07_103132_create_orders_table',3),(409,'2023_11_07_103145_create_escrows_table',3),(410,'2023_11_07_103301_create_messages_table',3),(411,'2023_11_07_103323_create_notification_types_table',3),(412,'2023_11_07_103327_create_notifications_table',3),(413,'2023_11_07_103416_create_order_keys_table',3),(414,'2023_11_07_103541_create_referrals_table',3),(415,'2023_11_07_103559_create_reports_table',3),(416,'2023_11_07_103707_create_market_keys_table',3),(417,'2023_11_07_103719_create_f_a_q_s_table',3),(418,'2023_11_07_103735_create_bugs_table',3),(419,'2023_11_07_103847_create_carts_table',3),(420,'2023_11_07_103903_create_block_stores_table',3),(421,'2023_11_07_103911_create_favorite_stores_table',3),(422,'2023_11_07_103921_create_favorite_listings_table',3),(423,'2023_11_07_104003_create_message_statuses_table',3),(424,'2023_11_07_104036_create_promocodes_table',3),(425,'2023_11_07_104126_create_featureds_table',3),(426,'2023_11_07_115341_create_news_table',3),(427,'2023_11_07_120033_create_disputes_table',3),(428,'2023_11_09_121541_create_share_accesses_table',3),(429,'2023_11_09_131542_create_share_permissions_table',3),(430,'2023_11_13_140711_create_user_promos_table',3),(431,'2023_11_20_005006_create_wallets_table',3),(432,'2023_11_21_200527_create_participants_table',3),(433,'2023_11_26_192751_create_servers_table',3),(434,'2023_12_01_124200_create_waivers_table',3),(435,'2023_12_03_210558_create_unauthorizes_table',3),(436,'2023_12_26_101710_create_market_functions_table',3),(437,'2024_01_03_094229_create_news_statuses_table',3),(438,'2024_01_12_191147_create_store_rules_table',3),(439,'2024_01_13_211822_create_addresses_table',3),(440,'2024_01_29_141252_create_links_table',3),(441,'2024_01_30_221808_create_mirrors_table',3),(442,'2024_01_30_221858_create_pays_table',3),(443,'2024_01_31_114511_create_deposits_table',3),(444,'2024_01_31_132227_create_withdraws_table',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `mirrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mirrors` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `link` text COLLATE utf8mb4_unicode_ci,
  `type` enum('user','store','junior','senior','admin') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `mirrors` WRITE;
/*!40000 ALTER TABLE `mirrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `mirrors` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `new_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `new_stores` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `store_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `selling` text COLLATE utf8mb4_unicode_ci,
  `ship_to` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Worldwide',
  `ship_from` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Unknown',
  `store_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sell_on` text COLLATE utf8mb4_unicode_ci,
  `proof1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `proof2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proof3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `store_type` enum('paid','waiver') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'waiver',
  `avater` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `new_stores_user_id_foreign` (`user_id`),
  CONSTRAINT `new_stores_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `new_stores` WRITE;
/*!40000 ALTER TABLE `new_stores` DISABLE KEYS */;
/*!40000 ALTER TABLE `new_stores` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `news` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `author_id` bigint unsigned NOT NULL,
  `priority` enum('low','medium','high') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'medium',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `news_author_id_foreign` (`author_id`),
  CONSTRAINT `news_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `news_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `news_statuses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `news_id` bigint unsigned NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `news_statuses_user_id_foreign` (`user_id`),
  KEY `news_statuses_news_id_foreign` (`news_id`),
  CONSTRAINT `news_statuses_news_id_foreign` FOREIGN KEY (`news_id`) REFERENCES `news` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_statuses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `news_statuses` WRITE;
/*!40000 ALTER TABLE `news_statuses` DISABLE KEYS */;
/*!40000 ALTER TABLE `news_statuses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notification_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_types` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notification_types` WRITE;
/*!40000 ALTER TABLE `notification_types` DISABLE KEYS */;
INSERT INTO `notification_types` VALUES (1,'New News Article Published','A new news article has been published.','created','news','2024-02-15 00:31:34','2024-02-15 00:31:34'),(2,'News Article Updated','An existing news article has been updated.','updated','news','2024-02-15 00:31:34','2024-02-15 00:31:34'),(3,'New System Announcement','An important announcement from the system administrator.','announcement','news','2024-02-15 00:31:34','2024-02-15 00:31:34'),(4,'New Order Created','A new order has been created.','created','order','2024-02-15 00:31:34','2024-02-15 00:31:34'),(5,'Order Disputed','A dispute has been initiated for your order.','dispute','dispute','2024-02-15 00:31:34','2024-02-15 00:31:34'),(6,'Order Dispatched','Your order has been dispatched.','dispatched','order','2024-02-15 00:31:34','2024-02-15 00:31:34'),(7,'Order Completed','Your order has been successfully completed.','completed','order','2024-02-15 00:31:34','2024-02-15 00:31:34'),(8,'Order Cancelled','Your order has been cancelled.','cancelled','order','2024-02-15 00:31:34','2024-02-15 00:31:34'),(9,'Order Shipped','Your order has been shipped.','shipped','order','2024-02-15 00:31:34','2024-02-15 00:31:34'),(10,'Order Delivered','Your order has been delivered.','delivered','order','2024-02-15 00:31:34','2024-02-15 00:31:34'),(11,'Order Sent','Your order has been sent.','sent','order','2024-02-15 00:31:34','2024-02-15 00:31:34'),(12,'Order Accepted','Your order has been accepted by the store.','accepted','order','2024-02-15 00:31:34','2024-02-15 00:31:34'),(13,'Order Dispute Closed','Order dispute has been closed.','closed','dispute','2024-02-15 00:31:34','2024-02-15 00:31:34'),(14,'Store Encryption Key Generated','A new encryption key has been generated for your store.','key','store','2024-02-15 00:31:34','2024-02-15 00:31:34'),(15,'Store Pending Approval','Your store is pending approval for activation.','pending','store','2024-02-15 00:31:34','2024-02-15 00:31:34'),(16,'Store Approved','Your store has been approved and is now active.','approved','store','2024-02-15 00:31:34','2024-02-15 00:31:34'),(17,'Store Rejected','Your store activation request has been rejected, check your details and try again.','rejected','store','2024-02-15 00:31:34','2024-02-15 00:31:34'),(18,'Store Waiver Rejected','Your store waiver activation request has been rejected, check your details and try again.','waiver_rejected','store','2024-02-15 00:31:34','2024-02-15 00:31:34'),(19,'Store Waiver Approved','Your store waiver activation request has been approved, check your look for your encryption key and open a store.','waiver_approved','store','2024-02-15 00:31:34','2024-02-15 00:31:34'),(20,'PGP Encryption Key Added','A PGP encryption key has been added to your account.','pgp','account','2024-02-15 00:31:34','2024-02-15 00:31:34'),(21,'Store Verified','Your store has been verified, keep up the good work!.','verified','account','2024-02-15 00:31:34','2024-02-15 00:31:34'),(22,'Account on Vacation','Your account is on vacation mode.','vacation','account','2024-02-15 00:31:34','2024-02-15 00:31:34'),(23,'Account Warned','A warning has been issued for your account.','warning','account','2024-02-15 00:31:34','2024-02-15 00:31:34'),(24,'Account Password Changed','Your account password has been changed.','changed','account','2024-02-15 00:31:34','2024-02-15 00:31:34'),(25,'Private Mirror Added to Account','A private mirror has been added to your account.','added','account','2024-02-15 00:31:34','2024-02-15 00:31:34'),(26,'Your Referral Link Used','Your referral link has been used by a new user, thank you!.','used','referral','2024-02-15 00:31:34','2024-02-15 00:31:34'),(27,'Referral Payment Received','You have received payment for a referral.','received','referral','2024-02-15 00:31:34','2024-02-15 00:31:34'),(28,'Favorited Product Updated','One of your favorite product has been updated, check it out.','update','product','2024-02-15 00:31:34','2024-02-15 00:31:34'),(29,'Listing Restocked','Your listing has been restocked.','restocked','listing','2024-02-15 00:31:34','2024-02-15 00:31:34'),(30,'New Listings Added by Store','Your favorite store added new listings. Check them out!','added','listing','2024-02-15 00:31:34','2024-02-15 00:31:34'),(31,'New Incoming Deposit Received','A new deposit has been detected in your account wallet.','received','deposit','2024-02-15 00:31:34','2024-02-15 00:31:34'),(32,'Deposit Confirmed and Added to Balance','A deposit has been confirmed and added to your balance.','confirmed','deposit','2024-02-15 00:31:34','2024-02-15 00:31:34'),(33,'Deposit Request Cancelled','A deposit request has been cancelled.','cancelled','deposit','2024-02-15 00:31:34','2024-02-15 00:31:34'),(34,'Deposit Request Rejected','A deposit request has been rejected.','rejected','deposit','2024-02-15 00:31:34','2024-02-15 00:31:34'),(35,'New Withdrawal Request Submitted','A new withdrawal request has been submitted.','submitted','withdraw','2024-02-15 00:31:34','2024-02-15 00:31:34'),(36,'Withdrawal Request In Progress','A withdrawal request is in progress.','in_progress','withdraw','2024-02-15 00:31:34','2024-02-15 00:31:34'),(37,'Withdrawal Request Completed','A withdrawal request has been completed.','completed','withdraw','2024-02-15 00:31:34','2024-02-15 00:31:34'),(38,'New Shared Access Given','Shared access has been given to your account.','given','shared','2024-02-15 00:31:34','2024-02-15 00:31:34'),(39,'Shared Access Taken Away','Shared access has been removed from your account.','taken','shared','2024-02-15 00:31:34','2024-02-15 00:31:34'),(40,'Escrow Time Increased','The escrow time for your order has been increased.','increased','escrow','2024-02-15 00:31:35','2024-02-15 00:31:35'),(41,'Percentage Refund Processed','A percentage of your order has been refunded.','partial_refund','escrow','2024-02-15 00:31:35','2024-02-15 00:31:35'),(42,'Full Order Refund Processed','Your order has been fully refunded.','full_refund','escrow','2024-02-15 00:31:35','2024-02-15 00:31:35'),(43,'Product Reported','A product has been reported by a user for a violation of market rules.','reported','listing','2024-02-15 00:31:35','2024-02-15 00:31:35'),(44,'Store Reported','Your store has been reported by a user for a violation of market rules.','reported','store','2024-02-15 00:31:35','2024-02-15 00:31:35'),(45,'Bug Report Confirmed','Your bug report has been confirmed and we are working hard to fix it, admin will message you.','confirmed','bug','2024-02-15 00:31:35','2024-02-15 00:31:35'),(46,'Bug Report Rejected','Your bug report has been reviewed and rejected, thank you for your efforts.','rejected','bug','2024-02-15 00:31:35','2024-02-15 00:31:35'),(47,'New Bug Report Submitted','A new bug report has been submitted.','submitted','bug','2024-02-15 00:31:35','2024-02-15 00:31:35'),(48,'💰👈 Cashback For You','Your order has been completed we have return 50% of our escrow profit to your account wallet, Thank you for using Whales Market! Want more money? invite friends.','received','cashback','2024-02-15 00:31:35','2024-02-15 00:31:35');
/*!40000 ALTER TABLE `notification_types` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `actor_id` bigint unsigned DEFAULT NULL,
  `notification_type_id` bigint unsigned NOT NULL,
  `option_id` bigint unsigned DEFAULT NULL,
  `is_read` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_user_id_foreign` (`user_id`),
  KEY `notifications_actor_id_foreign` (`actor_id`),
  KEY `notifications_notification_type_id_foreign` (`notification_type_id`),
  CONSTRAINT `notifications_actor_id_foreign` FOREIGN KEY (`actor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `notifications_notification_type_id_foreign` FOREIGN KEY (`notification_type_id`) REFERENCES `notification_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `order_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_keys` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `private_key` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `public_key` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `message_sign` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_keys_order_id_foreign` (`order_id`),
  CONSTRAINT `order_keys_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `order_keys` WRITE;
/*!40000 ALTER TABLE `order_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_keys` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `store_id` bigint unsigned NOT NULL,
  `extra_option_id` bigint unsigned NOT NULL,
  `quantity` int NOT NULL,
  `shipping_address` text COLLATE utf8mb4_unicode_ci,
  `store_notes` text COLLATE utf8mb4_unicode_ci,
  `extra_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cost_per_item` decimal(10,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `status` enum('pending','processing','shipped','delivered','dispute','sent','dispatched','cancelled','completed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_store_id_foreign` (`store_id`),
  KEY `orders_extra_option_id_foreign` (`extra_option_id`),
  KEY `orders_user_id_foreign` (`user_id`),
  KEY `orders_product_id_foreign` (`product_id`),
  CONSTRAINT `orders_extra_option_id_foreign` FOREIGN KEY (`extra_option_id`) REFERENCES `extra_options` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `orders_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `orders_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `participants` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `conversation_id` bigint unsigned NOT NULL,
  `is_hidden` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `participants_user_id_foreign` (`user_id`),
  KEY `participants_conversation_id_foreign` (`conversation_id`),
  CONSTRAINT `participants_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `participants_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `participants` WRITE;
/*!40000 ALTER TABLE `participants` DISABLE KEYS */;
/*!40000 ALTER TABLE `participants` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pays` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pays_user_id_foreign` (`user_id`),
  CONSTRAINT `pays_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pays` WRITE;
/*!40000 ALTER TABLE `pays` DISABLE KEYS */;
/*!40000 ALTER TABLE `pays` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `store_id` bigint unsigned NOT NULL,
  `quantity` int NOT NULL,
  `sold` int NOT NULL DEFAULT '0',
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_description` text COLLATE utf8mb4_unicode_ci,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `product_type` enum('digital','physical') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'physical',
  `ship_from` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Unknown',
  `payment_type` enum('Escrow','FE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Escrow',
  `ship_to` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'World Wide',
  `parent_category_id` bigint unsigned NOT NULL,
  `sub_category_id` bigint unsigned NOT NULL,
  `return_policy` text COLLATE utf8mb4_unicode_ci,
  `auto_delivery_content` text COLLATE utf8mb4_unicode_ci,
  `disputes_lost` int NOT NULL DEFAULT '0',
  `disputes_won` int NOT NULL DEFAULT '0',
  `category_promote` enum('yes','no') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no',
  `search_promote` enum('yes','no') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no',
  `status` enum('Active','Pending','Rejected','Paused') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `image_path1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_path2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_path3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `products_store_id_foreign` (`store_id`),
  KEY `products_parent_category_id_foreign` (`parent_category_id`),
  KEY `products_sub_category_id_foreign` (`sub_category_id`),
  CONSTRAINT `products_parent_category_id_foreign` FOREIGN KEY (`parent_category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `products_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `products_sub_category_id_foreign` FOREIGN KEY (`sub_category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `promocodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `promocodes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `store_id` bigint unsigned NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount` int NOT NULL,
  `type` enum('fixed','percentage') COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration_date` timestamp NULL DEFAULT NULL,
  `usage_limit` int NOT NULL,
  `times_used` int NOT NULL DEFAULT '0',
  `status` enum('active','paused','expired') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `promocodes_product_id_foreign` (`product_id`),
  KEY `promocodes_store_id_foreign` (`store_id`),
  CONSTRAINT `promocodes_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `promocodes_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `promocodes` WRITE;
/*!40000 ALTER TABLE `promocodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `promocodes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `referrals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `referrals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `referred_user_id` bigint unsigned NOT NULL,
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `status` enum('pending','confirmed','paid') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `referrals_user_id_foreign` (`user_id`),
  KEY `referrals_referred_user_id_foreign` (`referred_user_id`),
  CONSTRAINT `referrals_referred_user_id_foreign` FOREIGN KEY (`referred_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `referrals_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `referrals` WRITE;
/*!40000 ALTER TABLE `referrals` DISABLE KEYS */;
/*!40000 ALTER TABLE `referrals` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `replies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `review_id` bigint unsigned NOT NULL,
  `reply` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `replies_review_id_foreign` (`review_id`),
  CONSTRAINT `replies_review_id_foreign` FOREIGN KEY (`review_id`) REFERENCES `reviews` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `replies` WRITE;
/*!40000 ALTER TABLE `replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `replies` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reports` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `reported_id` int NOT NULL,
  `subject` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','verified','fake') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `report` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_store` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reports_user_id_foreign` (`user_id`),
  CONSTRAINT `reports_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `store_id` bigint unsigned NOT NULL,
  `communication_rating` int NOT NULL,
  `product_rating` int NOT NULL,
  `shipping_speed_rating` int NOT NULL,
  `price_rating` int NOT NULL,
  `feedback` enum('positive','neutral','negative') COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_id` int DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reviews_user_id_foreign` (`user_id`),
  KEY `reviews_product_id_foreign` (`product_id`),
  KEY `reviews_store_id_foreign` (`store_id`),
  CONSTRAINT `reviews_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reviews_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `servers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ip` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `port` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_tor` tinyint(1) NOT NULL DEFAULT '0',
  `type` enum('wallet','daemon','api') COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_user` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extra_pass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `servers` WRITE;
/*!40000 ALTER TABLE `servers` DISABLE KEYS */;
INSERT INTO `servers` VALUES (1,'198.58.115.118','18090','monero','Oqui1sDRFUUmYpWHE9PMuA==',0,'wallet','wale','whales@362002W','2024-02-15 02:16:05','2024-02-15 15:07:20'),(2,'https://min-api.cryptocompare.com/data/price?fsym=BTC&tsyms=USD','51950.81','BTC',NULL,0,'api',NULL,NULL,'2024-02-15 03:23:44','2024-02-16 09:55:48'),(3,'https://min-api.cryptocompare.com/data/price?fsym=XMR&tsyms=USD','126.17','XMR',NULL,0,'api',NULL,NULL,'2024-02-15 03:24:46','2024-02-16 09:55:49');
/*!40000 ALTER TABLE `servers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `share_accesses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `share_accesses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `store_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `status` enum('active','revoked') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `share_accesses_store_id_foreign` (`store_id`),
  KEY `share_accesses_user_id_foreign` (`user_id`),
  CONSTRAINT `share_accesses_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `share_accesses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `share_accesses` WRITE;
/*!40000 ALTER TABLE `share_accesses` DISABLE KEYS */;
/*!40000 ALTER TABLE `share_accesses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `share_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `share_permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `share_access_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `share_permissions_share_access_id_foreign` (`share_access_id`),
  CONSTRAINT `share_permissions_share_access_id_foreign` FOREIGN KEY (`share_access_id`) REFERENCES `share_accesses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `share_permissions` WRITE;
/*!40000 ALTER TABLE `share_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `share_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `store_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store_rules` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_xmr` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `store_rules` WRITE;
/*!40000 ALTER TABLE `store_rules` DISABLE KEYS */;
INSERT INTO `store_rules` VALUES (1,'1',1,'2024-02-15 00:31:35','2024-02-15 00:31:35'),(2,'Wales Market imposes a 5% commission fee on successful sales.',0,'2024-02-15 00:31:35','2024-02-15 00:31:35'),(3,'Store fees are non-refundable to uphold market integrity.',0,'2024-02-15 00:31:35','2024-02-15 00:31:35'),(4,'Prohibited listings include guns, CP (Child pornography), Covid-19 vaccines, assassination services, explosives, fentanyl, poisons, acids, and any items intended for harm.',0,'2024-02-15 00:31:35','2024-02-15 00:31:35'),(5,'Stores focused on selling harmful products will be penalized.',0,'2024-02-15 00:31:35','2024-02-15 00:31:35'),(6,'Prohibited services include hitmans, murders, and snuffs.',0,'2024-02-15 00:31:35','2024-02-15 00:31:35'),(7,'Selling products that lead to harm or death is strictly forbidden.',0,'2024-02-15 00:31:35','2024-02-15 00:31:35'),(8,'Attempting to purchase your own product will result in automatic banning.',0,'2024-02-15 00:31:35','2024-02-15 00:31:35'),(9,'Store products must have clear descriptions and unique characteristics.',0,'2024-02-15 00:31:35','2024-02-15 00:31:35'),(10,'Displaying contact information in listings is not allowed.',0,'2024-02-15 00:31:35','2024-02-15 00:31:35'),(11,'Off-market transactions are prohibited, and violators will face store bans.',0,'2024-02-15 00:31:35','2024-02-15 00:31:35'),(12,'Excessive bad reviews can lead to store escalation, returning escrow funds to various owners.',0,'2024-02-15 00:31:35','2024-02-15 00:31:35'),(13,'Escalated stores will have their products hidden, rendering the store inaccessible.',0,'2024-02-15 00:31:35','2024-02-15 00:31:35'),(14,'Orders auto conclude after 72 hours for \"sent\", \"dispatched\" or \"delivered\" statuses.',0,'2024-02-15 00:31:35','2024-02-15 00:31:35'),(15,'Verified stores with over 4.5 ratings and thousands of sales enjoy early finalization privileges.',0,'2024-02-15 00:31:35','2024-02-15 00:31:35'),(16,'The verification badge is granted to the top 10% of stores with over 6 months of operation and ratings above 4.0, symbolizing excellence.',0,'2024-02-15 00:31:35','2024-02-15 00:31:35'),(17,'Engaging in scams or manipulation may result in store banning based on valid user reports.',0,'2024-02-15 00:31:35','2024-02-15 00:31:35'),(18,'Market spam prevention: Limit your listings to 10 per day.',0,'2024-02-15 00:31:35','2024-02-15 00:31:35'),(19,'Stores with a rating below 2.5 face potential banning.',0,'2024-02-15 00:31:35','2024-02-15 00:31:35'),(20,'New vendors without established reputations must provide a picture of their product with their store name and \"Whales Market\" written on paper.',0,'2024-02-15 00:31:35','2024-02-15 00:31:35'),(21,'Promote love and respect; inactive stores for 2 week will be placed on vacation mode.',0,'2024-02-15 00:31:35','2024-02-15 00:31:35'),(22,'Rules are subject to change; any modifications will be communicated to all stores and users.',0,'2024-02-15 00:31:35','2024-02-15 00:31:35'),(23,'Thank you for reading, and stay safe.',0,'2024-02-15 00:31:35','2024-02-15 00:31:35');
/*!40000 ALTER TABLE `store_rules` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stores` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `store_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `store_description` longtext COLLATE utf8mb4_unicode_ci,
  `store_pgp` text COLLATE utf8mb4_unicode_ci,
  `store_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `width_sales` int NOT NULL DEFAULT '0',
  `disputes_lost` int NOT NULL DEFAULT '0',
  `disputes_won` int NOT NULL DEFAULT '0',
  `products_count` int NOT NULL DEFAULT '0',
  `status` enum('active','vacation','banned','escalated') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `selling` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ship_from` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ship_to` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referral_link` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_updated` date NOT NULL,
  `is_verified` tinyint NOT NULL DEFAULT '0',
  `is_fe_enable` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stores_user_id_foreign` (`user_id`),
  CONSTRAINT `stores_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `stores` WRITE;
/*!40000 ALTER TABLE `stores` DISABLE KEYS */;
/*!40000 ALTER TABLE `stores` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `supports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supports` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `conversation_id` bigint unsigned NOT NULL,
  `status` enum('pending','open','closed','escalated','de-escalated') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `staff_id` bigint unsigned DEFAULT NULL,
  `priority` enum('low','medium','high') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'medium',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `supports_user_id_foreign` (`user_id`),
  KEY `supports_conversation_id_foreign` (`conversation_id`),
  KEY `supports_staff_id_foreign` (`staff_id`),
  CONSTRAINT `supports_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `supports_staff_id_foreign` FOREIGN KEY (`staff_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `supports_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `supports` WRITE;
/*!40000 ALTER TABLE `supports` DISABLE KEYS */;
/*!40000 ALTER TABLE `supports` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `unauthorizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unauthorizes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unauthorizes_user_id_foreign` (`user_id`),
  CONSTRAINT `unauthorizes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `unauthorizes` WRITE;
/*!40000 ALTER TABLE `unauthorizes` DISABLE KEYS */;
/*!40000 ALTER TABLE `unauthorizes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_promos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_promos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `promocode_id` bigint unsigned NOT NULL,
  `cart_id` int unsigned NOT NULL,
  `discount` int unsigned NOT NULL,
  `cart_state` enum('not_checked_out','checked_out') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'not_checked_out',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_promos_user_id_foreign` (`user_id`),
  KEY `user_promos_promocode_id_foreign` (`promocode_id`),
  CONSTRAINT `user_promos_promocode_id_foreign` FOREIGN KEY (`promocode_id`) REFERENCES `promocodes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_promos_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_promos` WRITE;
/*!40000 ALTER TABLE `user_promos` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_promos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `public_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `private_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pin_code` int NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `store_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `spent` double(16,2) NOT NULL DEFAULT '0.00',
  `login_passphrase` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `disputes_lost` int NOT NULL DEFAULT '0',
  `disputes_won` int NOT NULL DEFAULT '0',
  `twofa_enable` enum('yes','no') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no',
  `role` enum('user','store','junior','senior','admin') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `status` enum('active','banned','vacation') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `store_status` enum('active','in_active','pending','suspended','banned') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'in_active',
  `pgp_key` longtext COLLATE utf8mb4_unicode_ci,
  `show_key` tinyint(1) NOT NULL DEFAULT '0',
  `private_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_orders` int NOT NULL DEFAULT '0',
  `theme` enum('white','dark') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'white',
  `referral_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_seen` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `avater` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'onlygodknows','escrow',190841,'$2y$12$bOTLNl5sFim7mk7YGYxgjOtHn5KnOYn2QPuIUC4Z59bU5kV2ocQnO','FcjV6UNrIUCLd1I8xdunlOEvut5D9heQsvtg4hSfi7vWEErEPzCETrrPZntqeFY9',0.00,'mOnbE',0,0,'yes','senior','active','in_active',NULL,0,NULL,0,'dark',NULL,'2024-02-15 00:31:36',NULL,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(2,'ghost','ghost',123456,'$2y$12$wxyE8JmxOP/ZZyk/BfrJReGsPyG.Rah32vEiHtfNFlT5LesgSgLDu','CoPnaTAWn1VvH7uJk7gJymYqc2dRKwakz3sXLlgtYup3Z8MvOX02OXtQgvunq3hPW3sznvaumUckeDQNFRc1pf12ojN9TMkWDQ8gzonwgpmBe665ZEgbGWOE3PQizCvk',0.00,'ghost',0,0,'no','admin','active','in_active',NULL,0,NULL,0,'white','ghost','2024-02-19 18:18:00',NULL,'2024-02-15 02:12:17','2024-02-19 18:18:00'),(3,'sorie','sorie',123456,'$2y$12$ELFPi/Lky/oQecV8ydli/e7M9yys0w6wDdijPGFr8WdemL6MlC0oK','YZYzuHj1NIUMY1roUoyu0Or7ZwopqQC8mjHFieAi9sf1fxAj0txbWx49ewAVFxTgx7S6pHQHy6ocVAlUiPZIOg6jzbkhjDNL6DuafixAPTtw4PZxP8rgtHrCJRYo6fpd',0.00,'sore',0,0,'no','user','active','in_active',NULL,0,NULL,0,'white','sorie','2024-02-16 10:20:46',NULL,'2024-02-16 09:59:14','2024-02-16 10:20:46'),(4,'mamoud','mamoud',123456,'$2y$12$J/QirKhB5ZiOuV3jGf2.1.vKMDMkdG7IA88TfMvy4COpwnKE8wmbi','Ed6gzpwzI2FpRPicmhuuFiSRY4bmc8bZvXQ41MnpyaH0zhXy1WlC7zXwytUu7UJMG5qPn0QPXhAXSutlUnqzskNwp6JcDBXwRUOnIeGNkp14BHEKTGFOrOdwmDjtIPhK',0.00,'mamd',0,0,'no','user','active','in_active',NULL,0,NULL,0,'white','mamoud','2024-02-18 23:51:28',NULL,'2024-02-18 22:26:55','2024-02-18 23:51:28');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `waivers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `waivers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `reason` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `proof1` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proof2` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proof3` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `waivers_user_id_foreign` (`user_id`),
  CONSTRAINT `waivers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `waivers` WRITE;
/*!40000 ALTER TABLE `waivers` DISABLE KEYS */;
/*!40000 ALTER TABLE `waivers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `wallets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wallets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `balance` decimal(32,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wallets_user_id_index` (`user_id`),
  CONSTRAINT `wallets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `wallets` WRITE;
/*!40000 ALTER TABLE `wallets` DISABLE KEYS */;
INSERT INTO `wallets` VALUES (1,1,0.00,'2024-02-15 00:31:36','2024-02-15 00:31:36'),(2,2,0.00,'2024-02-15 02:12:17','2024-02-15 04:03:51'),(3,3,0.00,'2024-02-16 09:59:14','2024-02-16 09:59:14'),(4,4,0.00,'2024-02-18 22:26:55','2024-02-18 22:26:55');
/*!40000 ALTER TABLE `wallets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `withdraws`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `withdraws` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `wallet_id` bigint unsigned NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(12,4) NOT NULL,
  `txid` text COLLATE utf8mb4_unicode_ci,
  `is_confirm` tinyint(1) NOT NULL DEFAULT '0',
  `is_detected` tinyint(1) NOT NULL DEFAULT '0',
  `is_failed` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `withdraws_wallet_id_foreign` (`wallet_id`),
  CONSTRAINT `withdraws_wallet_id_foreign` FOREIGN KEY (`wallet_id`) REFERENCES `wallets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `withdraws` WRITE;
/*!40000 ALTER TABLE `withdraws` DISABLE KEYS */;
/*!40000 ALTER TABLE `withdraws` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

