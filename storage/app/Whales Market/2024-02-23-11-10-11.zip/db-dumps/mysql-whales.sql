
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `wallet_id` bigint unsigned NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `expired` tinyint(1) NOT NULL DEFAULT '0',
  `is_confirm` tinyint(1) NOT NULL DEFAULT '0',
  `is_detected` tinyint(1) NOT NULL DEFAULT '0',
  `is_failed` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `addresses_wallet_id_foreign` (`wallet_id`),
  CONSTRAINT `addresses_wallet_id_foreign` FOREIGN KEY (`wallet_id`) REFERENCES `wallets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
INSERT INTO `addresses` VALUES (1,2,'86EEqxAKiFm97TRrt5dtdhBVPBcbHYEuP6tBarYoRV9mRVgc1pkKwYNAXVwGhJiXYZZEK8yQeSL2rc8FTheoQUBHFmrYY3v',1,1,1,0,'2024-02-19 10:49:07','2024-02-19 11:29:31'),(2,13,'88QEwJ22j1dEJqdyEuJdiRU68hpjbHXXTJLvUnDG7D6NGinMuYt3ZPcaHMFhYtAtDaSQb8kD9fEukXyuKM3hw7pf45z3iCN',1,0,0,0,'2024-02-19 15:41:48','2024-02-19 15:41:48'),(3,22,'89LUJimuNYkTz5dvedrgHUYdYzVomxbkxFNJK4xNUL6KNsY829jbqoUfZYiZeBJfeoJ4n8ufaiBcJXyX1umh5z6SJY4eyxS',1,1,1,0,'2024-02-19 22:32:29','2024-02-19 22:58:18'),(4,32,'88u4TmyBh4uCADYGZcRWPH9qPfkhUcAPJLs93QFiQ9HP5KgSiQRc95LcupekGtkwKLPwBEU7ZF5uMRbEJGbwVHuvDnEhBty',1,0,0,0,'2024-02-22 15:01:43','2024-02-22 15:01:43'),(5,36,'8Ai5zp88dyuUVgW98NvfnN1TDC8M9P2QeZ1tW5ooTm2E6Jkohczdac6DLwJFHQciw6hHGj1auERafAY851YRjPhFNJ8TMfa',1,0,0,0,'2024-02-22 22:30:03','2024-02-22 22:30:03');
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `block_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `block_stores` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `store_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `block_stores_user_id_foreign` (`user_id`),
  KEY `block_stores_store_id_foreign` (`store_id`),
  CONSTRAINT `block_stores_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `block_stores_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `block_stores` WRITE;
/*!40000 ALTER TABLE `block_stores` DISABLE KEYS */;
/*!40000 ALTER TABLE `block_stores` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bugs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','valid','invalid','paid') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bugs_user_id_foreign` (`user_id`),
  CONSTRAINT `bugs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bugs` WRITE;
/*!40000 ALTER TABLE `bugs` DISABLE KEYS */;
/*!40000 ALTER TABLE `bugs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `carts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `carts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `quantity` int unsigned NOT NULL DEFAULT '1',
  `note` longtext COLLATE utf8mb4_unicode_ci,
  `extra_option_id` int unsigned DEFAULT NULL,
  `discount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `carts_user_id_foreign` (`user_id`),
  KEY `carts_product_id_foreign` (`product_id`),
  CONSTRAINT `carts_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `carts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `carts` WRITE;
/*!40000 ALTER TABLE `carts` DISABLE KEYS */;
INSERT INTO `carts` VALUES (1,28,10,1,'<script>nigger</script>',21,0.00,'2024-02-20 01:45:30','2024-02-20 01:46:24');
/*!40000 ALTER TABLE `carts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_category_id` bigint unsigned DEFAULT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'CyberSecurity',NULL,NULL,'active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(2,'Educational Resources',NULL,NULL,'active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(3,'Web Development & Design',NULL,NULL,'active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(4,'Precious Commodities',NULL,NULL,'active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(5,'Drugs & Chemicals',NULL,NULL,'active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(6,'Goods & Services',NULL,NULL,'active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(7,'Other Listings',NULL,NULL,'active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(8,'Hacking & Spam',1,'CyberSecurity','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(9,'Fraud',1,'CyberSecurity','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(10,'Malware',1,'CyberSecurity','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(11,'Carded Items',1,'CyberSecurity','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(12,'Counterfeit Items',1,'CyberSecurity','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(13,'Security',1,'CyberSecurity','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(14,'Others',1,'CyberSecurity','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(15,'Guides & Tutorials',2,'Educational Resources','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(16,'Software',2,'Educational Resources','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(17,'Others',2,'Educational Resources','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(18,'Hosting',3,'Web Development & Design','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(19,'Websites',3,'Web Development & Design','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(20,'Graphics Design',3,'Web Development & Design','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(21,'Others',3,'Web Development & Design','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(22,'Jewels',4,'Precious Commodities','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(23,'Gold & Precious Metals',4,'Precious Commodities','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(24,'Others',4,'Precious Commodities','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(25,'Cannabis',5,'Drugs & Chemicals','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(26,'Opiates',5,'Drugs & Chemicals','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(27,'Stimulants',5,'Drugs & Chemicals','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(28,'Psychedelics',5,'Drugs & Chemicals','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(29,'Ecstasy',5,'Drugs & Chemicals','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(30,'Benzodiazepines',5,'Drugs & Chemicals','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(31,'Psychedelics',5,'Drugs & Chemicals','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(32,'Prescriptions',5,'Drugs & Chemicals','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(33,'Steroids',5,'Drugs & Chemicals','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(34,'Dissociatives',5,'Drugs & Chemicals','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(35,'Designer drugs',5,'Drugs & Chemicals','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(36,'Chemicals',5,'Drugs & Chemicals','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(37,'Tobacco',5,'Drugs & Chemicals','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(38,'Alcohols',5,'Drugs & Chemicals','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(39,'Others',5,'Drugs & Chemicals','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(40,'Legitimate Items',6,'Goods & Services','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(41,'Automotive Items',6,'Goods & Services','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(42,'Digital Products',6,'Goods & Services','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(43,'Services',6,'Goods & Services','active','2024-02-19 07:42:50','2024-02-19 07:42:50'),(44,'Others',6,'Goods & Services','active','2024-02-19 07:42:50','2024-02-19 07:42:50');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `conversations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conversations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `topic` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `conversations` WRITE;
/*!40000 ALTER TABLE `conversations` DISABLE KEYS */;
INSERT INTO `conversations` VALUES (1,'Waiver','2024-02-19 12:32:25','2024-02-19 12:32:25'),(2,'Vendor Bond Waiver','2024-02-19 15:18:24','2024-02-19 15:18:24'),(3,'Need help?','2024-02-19 20:27:57','2024-02-19 20:27:57'),(4,'store','2024-02-19 21:34:27','2024-02-19 21:34:27'),(5,'Fyodor','2024-02-19 21:50:04','2024-02-19 21:50:04'),(6,'waiver','2024-02-19 23:57:18','2024-02-19 23:57:18'),(7,'Dear Admin','2024-02-22 12:01:45','2024-02-22 12:01:45'),(8,'Little fixes','2024-02-22 14:21:48','2024-02-22 14:21:48'),(9,'Dispute Started.','2024-02-22 15:18:28','2024-02-22 15:18:28'),(10,'Hello whales team','2024-02-22 15:21:43','2024-02-22 15:21:43');
/*!40000 ALTER TABLE `conversations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `deposits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deposits` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `wallet_id` bigint unsigned NOT NULL,
  `amount` decimal(12,4) NOT NULL,
  `txid` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `deposits_wallet_id_foreign` (`wallet_id`),
  CONSTRAINT `deposits_wallet_id_foreign` FOREIGN KEY (`wallet_id`) REFERENCES `wallets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `deposits` WRITE;
/*!40000 ALTER TABLE `deposits` DISABLE KEYS */;
INSERT INTO `deposits` VALUES (1,2,0.0039,'f90a32c08ebf7a59a0be9c9a6296e34ec366a5044e948d2fec4d8ad2f4d7ed09','2024-02-19 11:29:31','2024-02-19 11:29:31'),(2,22,0.0088,'b381e430726db4b12906638f4a859761f5848659104a2eac472fada2af29619f','2024-02-19 22:58:18','2024-02-19 22:58:18');
/*!40000 ALTER TABLE `deposits` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `disputes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `disputes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `escrow_id` bigint unsigned DEFAULT NULL,
  `order_id` bigint unsigned NOT NULL,
  `mediator_id` bigint unsigned DEFAULT NULL,
  `conversation_id` bigint unsigned NOT NULL,
  `user_partial_percent` int DEFAULT NULL,
  `store_partial_percent` int DEFAULT NULL,
  `mediator_request` tinyint(1) NOT NULL DEFAULT '0',
  `status` enum('open','Full Refund','Partial Refund','closed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `winner` enum('none','store','user','both') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `user_refund_accept` tinyint(1) NOT NULL DEFAULT '0',
  `store_refund_accept` tinyint(1) NOT NULL DEFAULT '0',
  `user_refund_reject` tinyint(1) NOT NULL DEFAULT '0',
  `store_refund_reject` tinyint(1) NOT NULL DEFAULT '0',
  `refund_initiated` enum('User','Store','staff','none') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `disputes_escrow_id_foreign` (`escrow_id`),
  KEY `disputes_order_id_foreign` (`order_id`),
  KEY `disputes_mediator_id_foreign` (`mediator_id`),
  KEY `disputes_conversation_id_foreign` (`conversation_id`),
  CONSTRAINT `disputes_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `disputes_escrow_id_foreign` FOREIGN KEY (`escrow_id`) REFERENCES `escrows` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `disputes_mediator_id_foreign` FOREIGN KEY (`mediator_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `disputes_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `disputes` WRITE;
/*!40000 ALTER TABLE `disputes` DISABLE KEYS */;
INSERT INTO `disputes` VALUES (1,NULL,1,NULL,9,NULL,NULL,0,'open','none',0,0,0,0,'none','2024-02-22 15:18:28','2024-02-22 15:18:28');
/*!40000 ALTER TABLE `disputes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `escrows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `escrows` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `fiat_amount` decimal(32,2) NOT NULL,
  `status` enum('active','released','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `escrows_order_id_index` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `escrows` WRITE;
/*!40000 ALTER TABLE `escrows` DISABLE KEYS */;
INSERT INTO `escrows` VALUES (1,1,1.00,'active','2024-02-19 22:59:28','2024-02-19 22:59:28');
/*!40000 ALTER TABLE `escrows` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `extra_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `extra_options` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `extra_options_product_id_foreign` (`product_id`),
  CONSTRAINT `extra_options_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `extra_options` WRITE;
/*!40000 ALTER TABLE `extra_options` DISABLE KEYS */;
INSERT INTO `extra_options` VALUES (1,1,'Default','0.00','2024-02-19 11:12:47','2024-02-19 11:12:47'),(2,2,'USPS First Class (3-7 days)','5','2024-02-19 17:00:55','2024-02-19 18:10:42'),(3,2,'USPS Priority Mail (3-5 days)','20','2024-02-19 17:00:55','2024-02-19 18:16:00'),(4,2,'USPS Priority Express (1-3 days)','70','2024-02-19 17:00:55','2024-02-19 18:16:00'),(5,2,'USPS Priority Express (1-3 days)','70','2024-02-19 17:00:55','2024-02-19 17:00:55'),(6,2,'International First Class (5-21 days)','10','2024-02-19 17:00:55','2024-02-19 17:00:55'),(7,3,'USPS Ground (3-7 days)','5.00','2024-02-19 17:09:40','2024-02-19 17:09:40'),(8,3,'USPS Priority Mail','25','2024-02-19 17:09:40','2024-02-19 17:09:40'),(9,4,'USPS First Class (3-7 days)','5','2024-02-19 17:19:06','2024-02-19 17:19:06'),(10,4,'USPS Priority Mail (3-5 days)','20','2024-02-19 17:19:06','2024-02-19 17:19:06'),(11,4,'USPS Priority Mail Express (1-3 days)','50','2024-02-19 17:19:06','2024-02-19 17:19:06'),(12,5,'USPS First Class (3-7 days)','5.00','2024-02-19 17:25:18','2024-02-19 17:25:18'),(13,5,'USPS Priority Mail (3-5 days)','20','2024-02-19 17:25:18','2024-02-19 17:25:18'),(14,5,'USPS Priority Express (1-3 days)','50','2024-02-19 17:25:18','2024-02-19 17:25:18'),(15,6,'USPS First Class (3-7 days)','5','2024-02-19 17:32:38','2024-02-19 17:32:38'),(16,6,'USPS Priority Mail (3-5 days)','20','2024-02-19 17:32:38','2024-02-19 17:32:38'),(17,6,'Priority Mail Express (1-3 days)','50','2024-02-19 17:32:38','2024-02-19 17:32:38'),(18,7,'International First Class','6','2024-02-19 17:50:38','2024-02-19 17:50:38'),(19,8,'International First Class','6','2024-02-19 17:53:28','2024-02-19 17:53:28'),(20,9,'International First Class','6','2024-02-19 18:00:08','2024-02-19 18:00:08'),(21,10,'International','6','2024-02-19 18:03:44','2024-02-19 18:03:44'),(22,11,'International','6','2024-02-19 18:06:53','2024-02-19 18:06:53'),(23,11,'International Tracked','75','2024-02-19 18:06:53','2024-02-19 18:06:53');
/*!40000 ALTER TABLE `extra_options` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `f_a_q_s`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `f_a_q_s` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `question` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_publish` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `f_a_q_s_user_id_foreign` (`user_id`),
  CONSTRAINT `f_a_q_s_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `f_a_q_s` WRITE;
/*!40000 ALTER TABLE `f_a_q_s` DISABLE KEYS */;
INSERT INTO `f_a_q_s` VALUES (1,1,'What is Whales Market?','Whales Market is an online marketplace that allows users to buy and sell products, both digital and physical. It provides a platform for sellers to list their products after verification by admins or mods.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(2,1,'How can I sell (open a store) on Whales Market?','To open a store on Whales Market, you need a store key (64-128 characters) to encrypt your information. Click on the store icon, provide your information and store key, and ensure your 2FA is enabled and matches your public name. You can purchase or ask for waiver a store key in the \"Setting > store key\" and receive a notification with your store key after payment or waiver accepted.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(3,1,'Can I list both digital and physical products in my store?','Yes, Whales Market allows stores to list both digital and physical products. Whether you are offering digital content or tangible items, you can showcase your products within your verified store on the platform.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(4,1,'What are the guidelines for listing products on Whales Market?','Stores are required to adhere to specific guidelines when listing products on Whales Market. These guidelines may include providing accurate product descriptions, using high-quality images, removing meta data from images and ensuring that the products align with the theme of the marketplace rules.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(5,1,'How does the moderation process work for product listings?','The moderation process involves a review of product listings to ensure they meet the platform\'s standards. This includes verifying the accuracy of product information, images, and adherence to content policies. Stores are notified of any necessary adjustments or approvals.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(6,1,'Are there any restrictions on the types of products that can be sold on Whales Market?','While Whales Market encourages a diverse range of products, there are many restrictions on certain items. Stores should review the platforms policies(rules) to understand any limitations on product categories or content.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(7,1,'Can I update my store information after it has been active?','Yes, sellers can update their store information, including product listings, even after the initial verification process. It is essential to keep your store details accurate and up-to-date to provide a positive experience for buyers.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(8,1,'How can buyers trust the authenticity of products on Whales Market?','Whales Markets verification process for sellers and product listings is designed to build trust. Buyers can look for store rating and reviews and ratings contribute to the overall transparency and reliability of the marketplace,.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(9,1,'What is the difference between a store and a regular user account on Whales Market?','A store on Whales Market is an advanced account type designed for sellers. It comes with a dedicated dashboard that provides powerful tools for managing products and sales. When your store is active, you have exclusive access to your personalized dashboard, limiting your interaction with the general marketplace features.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(10,1,'Can I still access the main market while my store is active?','No, when your store is active, your access is limited to the stores dashboard. This exclusive environment allows you to focus on managing your products, sales, and other essential tasks without being distracted by unrelated marketplace activities. If you wish to browse or participate in the main market, you can create another account specifically for that purpose.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(11,1,'What tools are available in the stores dashboard for sellers?','The stores dashboard on Whales Market is equipped with powerful tools tailored for sellers. These may include inventory management, order processing, sales analytics, and promotional features, store share access, coupons system and more. Sellers can efficiently handle their store operations and monitor their performance through a centralized and user-friendly interface.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(12,1,'What happens if my store is inactive or suspended?','If your store is inactive or suspended due to violations or other reasons, your access to the stores dashboard will be restricted. You may receive notifications and instructions on how to address the issues causing the inactivity. Resolving these issues will enable you to reactivate your store and regain access to the seller dashboard.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(13,1,'What is Vacation Mode on Whales Market?','Vacation Mode is a feature on Whales Market that allows sellers to temporarily deactivate their store. This is useful for sellers who anticipate being inactive for a specific period, such as vacations or temporary breaks.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(14,1,'How do I activate Vacation Mode for my store?','To activate Vacation Mode, log in to your store\'s dashboard, navigate to settings, and look for the Vacation Mode option, and set it.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(15,1,'Can I still access my store\'s dashboard while it\'s in Vacation Mode?','Yes, sellers can still access their store\'s dashboard while in Vacation Mode. However, the store will not be visible to buyers, and transactions will be temporarily disabled.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(16,1,'What happens to my existing listings and products during Vacation Mode?','While your store is in Vacation Mode, your existing listings and products will remain on the platform but will be temporarily hidden from buyers. This ensures that your store retains its presence, and buyers are aware of your temporary absence.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(17,1,'Are there any restrictions on how often I can use Vacation Mode?','Whales Market does not impose strict restrictions on the frequency of using Vacation Mode. Sellers can use this feature as needed, but it\'s recommended to use it judiciously to ensure a positive experience for both sellers and buyers.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(18,1,' What is the Dispute System on Whales Market?','The Dispute System on Whales Market is a comprehensive feature designed to facilitate quick and fair resolutions in case of conflicts between buyers and sellers. It acts as a mechanism to address issues related to transactions without the immediate involvement of a moderator.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(19,1,'How does the Dispute System work on Whales Market?','In the event of a dispute, either the buyer or the seller can initiate the resolution process through the Dispute System. The platform provides a user-friendly interface where users can submit details about the issue, including evidence such as messages, it also has a messaging system, with sleek functions.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(20,1,'What tools are available in the Dispute System for both buyers and sellers?','The Dispute System comes with a full set of features for both buyers and sellers. Users can present their case, provide evidence, and engage in communication directly through the system. This includes the ability to message, accept refunds, start partial refund, percentage system, decline partial, release funds, request mods, and more.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(21,1,'Can I request the assistance of a moderator in a dispute?','Yes, while the Dispute System is designed to allow users to resolve issues independently, there is an option to request moderator intervention. This button serves as a safety net, ensuring that if the dispute cannot be resolved directly between the parties, a moderator can step in to provide assistance and make a final decision.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(22,1,'What is the Whales Market Auto-Delete System?','The Whales Market Auto-Delete System is a feature designed to automatically remove specific types of messages after a designated period. This helps keep top security, conversations and transactions organized by removing outdated or completed information.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(23,1,'Which are subject to auto-deletion on Whales Market?','The Auto-Delete System targets read messages, completed transactions, closed disputes, and canceled orders. These are automatically removed from the platform after 15 days, streamlining the communication channels, reducing clutter and improving higher security.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(24,1,'What is the Auto-Cancellation System on Whales Market?','The Auto-Cancellation System on Whales Market is designed to automatically cancel orders that have been pending for 72 hours. In the event of non-action within this timeframe, the system initiates the cancellation process and refunds the money to the buyer.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(25,1,'Can users extend the 72-hour auto-cancellation timeframe?','Yes, users have the option to extend the auto-cancellation timeframe by an additional 72 hours if the order has not been canceled. This flexibility allows for adjustments in case there are valid reasons to delay the cancellation process.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(26,1,'How does the Auto-Release System work on Whales Market?','The Auto-Release System on Whales Market automatically releases funds for orders that have been marked by the store as delivered, sent, or dispatched. If there is no further action within 72 hours, the system completes the release, transferring the funds to the store.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(27,1,'What is the Auto-Cancellation System on Whales Market?','The Auto-Cancellation System on Whales Market automatically cancels orders pending for 72 hours. Users can extend the period for an additional 72 hours if necessary. It ensures a smooth cancellation process and refunds the money to the buyer.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(28,1,'Is there an option to extend the 72-hour auto-release timeframe?','Yes, similar to the auto-cancellation feature, users can extend the 72-hour auto-release timeframe if necessary. This gives both buyers and sellers the flexibility to accommodate specific situations that may cause delays in the order completion process.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(29,1,'How many support tickets can I create per day for regular user-related issues?','Regular users are limited to creating a maximum of three support tickets per day for their inquiries or issues.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(30,1,'Is there a support ticket limit for stores on Whales Market?','Yes, stores on Whales Market can create up to five support tickets per day to address their specific concerns or inquiries.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(31,1,'What should I do if I find a bug on Whales Market?','If you encounter a bug on Whales Market, navigate to the settings menu and look for the \"Bug Report\" option. Use this feature to report the bug by providing detailed information, including steps to reproduce the issue. Whales Market encourages users to share comprehensive details for a more effective resolution.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(32,1,'Are there any incentives for reporting bugs on Whales Market?','Yes, Whales Market values the contribution of users in identifying and reporting bugs. Users who report bugs and provide helpful information may be eligible for rewards or prizes. This encourages active participation in enhancing the platform\'s functionality.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(33,1,'Why doesn\'t Whales Market integrate third-party apps for notifications?','Whales Market has a powerful and integrated notifications system that covers almost all changes made within the platform. To ensure security, efficiency, and a seamless user experience, the platform does not incorporate third-party apps for notifications.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(34,1,'How do I deposit funds into my Whales Market account?','To deposit funds, go to the settings menu and look for the \"Deposit\" option on Whales Market. Follow the provided steps, and you can make a deposit without incurring any fees or having a minimum deposit requirement. Ensure you use the provided deposit address only once for security reasons.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(35,1,'Can I use the deposit address multiple times?','For security reasons, Whales Market recommends using the deposit address provided only once. Generating a new deposit address for each transaction enhances the security of your funds.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(36,1,'How do I withdraw funds from my Whales Market account?','To withdraw funds, navigate to the settings menu and look for the \"Withdraw\" option on Whales Market. Follow the provided steps to initiate a withdrawal. Note that Whales Market does not charge any fees for withdrawals, and there is no minimum withdrawal requirement.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(37,1,'How long does it take for a withdrawal to be processed on Whales Market?','The withdrawal time frame on Whales Market can vary depending on network conditions. Once initiated, withdrawals are typically processed promptly. Users are encouraged to check their transaction history for updates on the withdrawal status.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(38,1,'Are there any restrictions on the number of withdrawals I can make per day?','Whales Market typically does not impose restrictions on the number of withdrawals a user can make per day. Users can withdraw funds based on their preferences and needs.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(39,1,'Why is 2FA (Two-Factor Authentication) required for opening a store on Whales Market?','2FA is required to enhance the security of your store on Whales Market. It ensures that only authorized users with the correct authentication method can access and manage the store. Make sure your 2FA is enabled and matches your public name.',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(40,1,'What should I do if I encounter issues while opening my store on Whales Market?','If you encounter issues while opening your store, you can reach out to Whales Market support for assistance. They can provide guidance, address concerns, and ensure a smooth process for setting up your store',0,'2024-02-19 07:44:11','2024-02-19 07:44:11'),(41,1,'What should I know','Stay safe, find Harm Reduction on dread, find DarkNet user bible on dread, stay conneceted on dread and pitch forums!',0,'2024-02-19 07:44:11','2024-02-19 07:44:11');
/*!40000 ALTER TABLE `f_a_q_s` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `favorite_listings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `favorite_listings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `favorite_listings_user_id_foreign` (`user_id`),
  KEY `favorite_listings_product_id_foreign` (`product_id`),
  CONSTRAINT `favorite_listings_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `favorite_listings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `favorite_listings` WRITE;
/*!40000 ALTER TABLE `favorite_listings` DISABLE KEYS */;
/*!40000 ALTER TABLE `favorite_listings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `favorite_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `favorite_stores` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `store_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `favorite_stores_user_id_foreign` (`user_id`),
  KEY `favorite_stores_store_id_foreign` (`store_id`),
  CONSTRAINT `favorite_stores_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `favorite_stores_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `favorite_stores` WRITE;
/*!40000 ALTER TABLE `favorite_stores` DISABLE KEYS */;
INSERT INTO `favorite_stores` VALUES (1,13,1,'2024-02-19 15:34:28','2024-02-19 15:34:28');
/*!40000 ALTER TABLE `favorite_stores` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `featureds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `featureds` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `featureds_product_id_foreign` (`product_id`),
  CONSTRAINT `featureds_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `featureds` WRITE;
/*!40000 ALTER TABLE `featureds` DISABLE KEYS */;
/*!40000 ALTER TABLE `featureds` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `feed_backs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feed_backs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `store_id` bigint unsigned NOT NULL,
  `communications` int NOT NULL DEFAULT '0',
  `review` int NOT NULL DEFAULT '0',
  `rating` int NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `feed_backs_user_id_foreign` (`user_id`),
  KEY `feed_backs_product_id_foreign` (`product_id`),
  KEY `feed_backs_store_id_foreign` (`store_id`),
  CONSTRAINT `feed_backs_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `feed_backs_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `feed_backs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `feed_backs` WRITE;
/*!40000 ALTER TABLE `feed_backs` DISABLE KEYS */;
/*!40000 ALTER TABLE `feed_backs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `links` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descriptions` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `links` WRITE;
/*!40000 ALTER TABLE `links` DISABLE KEYS */;
/*!40000 ALTER TABLE `links` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `market_functions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `market_functions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enable` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `market_functions` WRITE;
/*!40000 ALTER TABLE `market_functions` DISABLE KEYS */;
INSERT INTO `market_functions` VALUES (1,'login',1,'2024-02-19 07:43:05','2024-02-19 07:43:05'),(2,'signup',1,'2024-02-19 07:43:05','2024-02-19 07:43:05'),(3,'waiver',1,'2024-02-19 07:43:05','2024-02-19 07:43:05'),(4,'cashback',1,'2024-02-19 07:43:05','2024-02-19 07:43:05'),(5,'wallet',1,'2024-02-19 07:43:05','2024-02-19 10:46:56'),(6,'withdraw',1,'2024-02-19 07:43:05','2024-02-19 09:45:32'),(7,'deposit',1,'2024-02-19 07:43:05','2024-02-19 09:45:42'),(8,'storekey',1,'2024-02-19 07:43:05','2024-02-19 07:43:05'),(9,'api',1,'2024-02-19 07:43:05','2024-02-19 09:45:07');
/*!40000 ALTER TABLE `market_functions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `market_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `market_keys` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `message_sign` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `public_key` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `market_keys_user_id_foreign` (`user_id`),
  CONSTRAINT `market_keys_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `market_keys` WRITE;
/*!40000 ALTER TABLE `market_keys` DISABLE KEYS */;
INSERT INTO `market_keys` VALUES (1,2,'-----BEGIN PGP SIGNED MESSAGE-----\r\nHash: SHA256\r\n\r\n\r\nI am actively monitoring the administrator of Whales Market through OSINT, \r\nconfirming my continued existence while maintaining control over all Whales Market servers and keys.\r\n\r\nMonero Hash: 2cf55603a8c35cb9638d5c8d2d3389dcac7388d962bad528adaabe8f18524801\r\nDate: 19/02/2024\r\n\r\nThis canary is scheduled for an update on 15/03/2024 to align with our launch date, subsequently refreshed every 30 days thereafter.\r\n-----BEGIN PGP SIGNATURE-----\r\n\r\niQIzBAEBCAAdFiEEQbcN4K+x4JrJvaccYFwOJDOFyC8FAmXTOcEACgkQYFwOJDOF\r\nyC+KOBAAr59MlI7DXRwSX+hK5FUnigBSRM4yVbdQMNjbiSPVITW4d9n4GHBNeH9I\r\n6EpGw0lw6GV6xvf8uBrI6D7wtt5sTFp7dKOYuJZKlGZ0CsItQoW781jMsUaJonJM\r\nS93hdNdPr7QFxLoD1BCbrLEWpambMz+4LoYh/j+WUcF6ZQi4O5vIdukjmekNsXP4\r\n6yHw5vR8scdFyKMvFbhP7QRfObZ2XcLBb4JpTuuJ4dtrWQI+E/bySQzNNpp+cBjS\r\nb8ztAAdz0/72s2nxU0+Zd5RgSbb8fa31oQV1l1xDqSmmcp5bwBQDVEg0KcrimAGw\r\nAwl2JzFQMO+7IFzj4JrXLcaNyUwQJnd1B78BDKLKEgnePXgRqkBpe9EPeSVa+3ex\r\np/tplTHJDEIrc+TAjMeomF7zEbgmn4lT4JDrLfFxrkwJNMAKxeF8Z+kZ5rZl103N\r\nL+KUEL7j7UNHp9DBoZuxESC19mCq2E0ztyAaTMR4oLdf/ada0KGE0kvD0aB+TpPv\r\nb+zY44IIdoQ/F8DxHSUpJ1EpCXVATVdRnphMVdcLCxg8aiBoPJt5ja/H5a4OFoh3\r\nCnUqTIwM6dwbeow4B/mkL5c1p5h/N9FDEW4prFXnnZSnpWxa6KAFvctzGgFOfBjE\r\n4SL8hgmwhnupYmb/g7LdjPPJed3kKRz7P9AfgYFqG2D4uODa4M8=\r\n=1PTn\r\n-----END PGP SIGNATURE-----','','2024-02-19 11:22:15','2024-02-19 11:22:15');
/*!40000 ALTER TABLE `market_keys` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `message_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_statuses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `message_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `is_read` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `message_statuses_message_id_foreign` (`message_id`),
  KEY `message_statuses_user_id_foreign` (`user_id`),
  CONSTRAINT `message_statuses_message_id_foreign` FOREIGN KEY (`message_id`) REFERENCES `messages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `message_statuses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `message_statuses` WRITE;
/*!40000 ALTER TABLE `message_statuses` DISABLE KEYS */;
INSERT INTO `message_statuses` VALUES (1,1,5,1,'2024-02-19 12:32:25','2024-02-19 12:32:25'),(2,2,5,1,'2024-02-19 13:55:56','2024-02-19 16:00:34'),(3,2,2,1,'2024-02-19 13:55:56','2024-02-19 13:55:56'),(4,3,12,1,'2024-02-19 15:18:24','2024-02-19 15:18:24'),(5,4,12,1,'2024-02-19 16:02:37','2024-02-19 16:13:31'),(6,4,2,1,'2024-02-19 16:02:37','2024-02-19 16:02:37'),(7,5,12,1,'2024-02-19 16:19:59','2024-02-19 16:19:59'),(8,5,2,1,'2024-02-19 16:19:59','2024-02-19 16:33:07'),(9,6,12,1,'2024-02-19 16:24:28','2024-02-19 16:24:28'),(10,6,2,1,'2024-02-19 16:24:28','2024-02-19 16:33:07'),(11,7,12,1,'2024-02-19 16:35:10','2024-02-19 16:38:40'),(12,7,2,1,'2024-02-19 16:35:10','2024-02-19 16:35:10'),(13,8,12,1,'2024-02-19 20:27:57','2024-02-19 20:27:57'),(14,9,12,1,'2024-02-19 20:52:09','2024-02-19 20:55:25'),(15,9,2,1,'2024-02-19 20:52:09','2024-02-19 20:52:09'),(16,10,12,1,'2024-02-19 21:04:00','2024-02-19 21:04:00'),(17,10,2,1,'2024-02-19 21:04:00','2024-02-19 21:15:09'),(18,11,12,1,'2024-02-19 21:20:17','2024-02-19 21:23:40'),(19,11,2,1,'2024-02-19 21:20:17','2024-02-19 21:20:17'),(20,12,12,1,'2024-02-19 21:29:40','2024-02-19 21:29:40'),(21,12,2,1,'2024-02-19 21:29:40','2024-02-19 21:45:48'),(22,13,10,1,'2024-02-19 21:34:27','2024-02-19 21:34:27'),(23,14,12,1,'2024-02-19 21:48:51','2024-02-22 14:04:48'),(24,14,2,1,'2024-02-19 21:48:51','2024-02-19 21:48:51'),(25,15,12,1,'2024-02-19 21:49:47','2024-02-22 14:04:50'),(26,15,2,1,'2024-02-19 21:49:47','2024-02-19 21:49:47'),(27,16,20,1,'2024-02-19 21:50:04','2024-02-19 21:50:04'),(28,17,10,1,'2024-02-19 21:57:14','2024-02-19 22:07:38'),(29,17,2,1,'2024-02-19 21:57:14','2024-02-19 21:57:14'),(30,18,20,1,'2024-02-19 22:00:32','2024-02-19 22:10:17'),(31,18,2,1,'2024-02-19 22:00:32','2024-02-19 22:00:32'),(32,19,10,1,'2024-02-19 22:04:55','2024-02-19 22:07:40'),(33,19,2,1,'2024-02-19 22:04:55','2024-02-19 22:04:55'),(34,20,10,1,'2024-02-19 22:11:24','2024-02-19 22:11:24'),(35,20,2,1,'2024-02-19 22:11:24','2024-02-19 22:15:30'),(36,21,10,1,'2024-02-19 22:17:13','2024-02-19 22:19:38'),(37,21,2,1,'2024-02-19 22:17:13','2024-02-19 22:17:13'),(38,22,10,1,'2024-02-19 22:22:08','2024-02-19 22:22:08'),(39,22,2,1,'2024-02-19 22:22:08','2024-02-19 22:28:19'),(40,23,10,1,'2024-02-19 22:29:56','2024-02-19 22:31:28'),(41,23,2,1,'2024-02-19 22:29:56','2024-02-19 22:29:56'),(42,24,10,1,'2024-02-19 22:46:04','2024-02-19 22:46:04'),(43,24,2,1,'2024-02-19 22:46:04','2024-02-19 22:55:24'),(44,25,24,1,'2024-02-19 23:57:18','2024-02-19 23:57:18'),(45,26,24,1,'2024-02-20 00:01:42','2024-02-20 00:29:11'),(46,26,2,1,'2024-02-20 00:01:42','2024-02-20 00:01:42'),(47,27,24,1,'2024-02-20 00:46:03','2024-02-20 00:46:03'),(48,27,2,1,'2024-02-20 00:46:03','2024-02-20 07:12:57'),(49,28,29,1,'2024-02-22 12:01:45','2024-02-22 12:01:45'),(50,29,29,1,'2024-02-22 12:02:39','2024-02-22 12:02:39'),(51,30,29,0,'2024-02-22 12:24:21','2024-02-22 12:24:21'),(52,31,12,1,'2024-02-22 14:10:47','2024-02-22 14:10:47'),(53,31,2,1,'2024-02-22 14:10:47','2024-02-22 15:00:15'),(54,32,12,1,'2024-02-22 14:21:48','2024-02-22 14:21:48'),(55,33,12,1,'2024-02-22 14:47:09','2024-02-22 14:47:09'),(56,34,12,0,'2024-02-22 14:51:16','2024-02-22 14:51:16'),(57,35,12,0,'2024-02-22 15:02:19','2024-02-22 15:02:19'),(58,35,2,1,'2024-02-22 15:02:19','2024-02-22 15:02:19'),(59,36,24,1,'2024-02-22 15:13:47','2024-02-22 19:25:00'),(60,36,2,1,'2024-02-22 15:13:47','2024-02-22 15:13:47'),(61,37,22,0,'2024-02-22 15:18:28','2024-02-22 15:18:28'),(62,37,3,1,'2024-02-22 15:18:28','2024-02-22 15:18:30'),(63,38,22,0,'2024-02-22 15:19:53','2024-02-22 15:19:53'),(64,38,3,1,'2024-02-22 15:19:53','2024-02-22 15:19:53'),(65,39,3,1,'2024-02-22 15:21:43','2024-02-22 15:21:43'),(66,40,3,1,'2024-02-22 15:23:31','2024-02-22 15:23:31'),(67,41,24,1,'2024-02-22 19:31:42','2024-02-22 19:31:42'),(68,41,2,0,'2024-02-22 19:31:42','2024-02-22 19:31:42');
/*!40000 ALTER TABLE `message_statuses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `conversation_id` bigint unsigned NOT NULL,
  `message_type` enum('message','ticket','dispute','mass','staff') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'message',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `messages_user_id_foreign` (`user_id`),
  KEY `messages_conversation_id_foreign` (`conversation_id`),
  CONSTRAINT `messages_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `messages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES (1,'Waiver',5,1,'ticket','2024-02-19 12:32:25','2024-02-19 12:32:25'),(2,'Hello Optopus\r\nthank you so much for making it to our market\r\n\r\nHere is you store key:   ANrHFvW2k9ZgkniiCkC6dWM946dfDEXEVo033NRtF3J3drE1NQnngZTbiQBiDpwZ8ZzYYombYjLJKMgC9V5OWlqaGa9ZqWf9jd5A5PT9LhEgeyG8BEK6k82cQGJSWwMd\r\n\r\nwe have special offers every user who purchase product from you will have 50% of our escrow fees and if you have referrals you will have the other 50% we hope you will brings new users to our market.',2,1,'ticket','2024-02-19 13:55:56','2024-02-19 13:55:56'),(3,'Vendor Bond Waiver',12,2,'ticket','2024-02-19 15:18:24','2024-02-19 15:18:24'),(4,'Hello man sorry am sorry to say this but we cannot offer you a bonds as your dread account is new without any good activities so if you still want a store you can purchase account we will surely grant you.\r\n\r\nor \r\nshare a lists of markets you sale on let me check it after that we can give you bonds.',2,2,'ticket','2024-02-19 16:02:37','2024-02-19 16:02:37'),(5,'Thank you, hopefully you\'ll grant one after you look into my market history. I juist submitted the form for a waiver in the right place.\r\n \r\nI\'m currently vending on Archetyp. I vended on Vice City, Torrez, & Dark Fox under the name CrystalClean21. ALL GREAT REVIEWS.\r\n\r\nMy old dread account is CrystalCleanPharmaKing I believe? I lost the password so I created a new one. My libre account is an older one, maybe a year or so old since it just was released not long ago.\r\n\r\nI think I would be a good asset, if you\'ll give me a chance. I will promote the market if you want me too since it\'s new. I\'ve always been a good marketer.',12,2,'ticket','2024-02-19 16:19:59','2024-02-19 16:19:59'),(6,'-----BEGIN PGP SIGNED MESSAGE-----\r\nHash: SHA512\r\n\r\nApplication To Vend without a Vendor Bond - Established Vendor\r\n\r\nVendor Name - CrystalClean21 & CrystalClean\r\n\r\nProducts Selling - Meth, Weed, Weed Concentrates, LSD, Mushrooms, & occassionally other drug \r\nproducts\r\n\r\nMarkets Vending & Vended on - Torrez, Dark Fox, Vice City, & currently on Archetyp\r\n\r\nVendor Rating Overall (From all markets over 3 years) - 4.5 - 5 stars\r\n\r\nTotal Sales: \r\nCurrent Markets -\r\nArchetyp = 63 \r\n(55 complete, 8 in shipping stage, will finalize Tuesday or Wednesday.)\r\n\r\nPast Markets- \r\n\r\nVice City = 150-175 (Almost perfect rate)\r\nTorrez = 20-30 (Almost perfect rate)\r\nCan\'t remember well enough to give estimate on sales for Dark Fox\r\n\r\n* We will do great intros & promotions to attract customers to this market to help the market grow and also build reputation together.\r\n\r\nCrystalClean provides top quality products at a great rate. We attracted users to Vice City and 100% had/have the best ice on the market. We take pride in the quality of our products and also are honest, polite, and treat everyone that contact us, or that we contact, with the respect deserved. We would be very grateful and would show the same love you give to us, if our application to vend without a vendor bond is accepted. Please check out current Feedback rating on Archetyp and if the database for Vice City is still around, you can also look to see that we had a great, if n ot perfect record, on VC as well.\r\n\r\nEveryone loves our products and we try to maintain great opsec and provide everyone with the same privacy that we would want when handling sensitive personal information. We know how to operate and have been around 3 years. \r\n\r\nWe are asking that you please waive the vendor bond fee and allow us to vend on this market. Is this something that is able to be done? Thank you all for the time to read and review this application. Current and former PGP used on Vice City, Torrez, & Archetyp.\r\n\r\nKind Regards,\r\n\r\nCrystalClean\r\n-----BEGIN PGP SIGNATURE-----\r\n\r\niQGzBAEBCgAdFiEEhHPvNhGRYbvCGk2WQsW/dbG3TjkFAmXSrAAACgkQQsW/dbG3\r\nTjnO0wv/QqaqlquClbLUqKxV1xKFpukSqwL2Xhi5cxsdbQCbhwiNqZvQgUnBzE0b\r\nv6U2RGOcYJZ7j/OumuiRQ8Tfs9QWbpPxCUQtSYKKPF1tmHOSHwettmTce8p9+cy1\r\ngSD960pIkNmTlfkAA/M30FRqp8gj1mpzJWL0XFk3NEEFEXkCqy5xO+uPsNxn02Oa\r\nNBR38HXVO4p8nPNrznmRTNUV+jXANEAq6AOe1hR+W2qYVnvKAj32kZzBL9iOPube\r\naUqBIxbMZd1rLss4CZE3/cr6QtjzurRworRp0rds6v9eR2UjtL13DrOl24wY0hbd\r\nKm5UTtVQmCNbmnogT3DjKLRac+TY5ZamJlBzFC4Vcfes3Ouy9m2ZC3ireW/OMYGN\r\nhx0hdNHzAhE1LHHJVVScClnTEpcNAJ5oJSRcXsgU9ZzY5/7TxnMiCyt46SpdAJ0O\r\nevNoqm8eX+tdhjnJiQYh+rHZk59I/0GD7cSjfC8U2XNI2hZQSsgR3VOrlFuBQMH/\r\nHkj6MCq0\r\n=9LU4\r\n-----END PGP SIGNATURE-----',12,2,'ticket','2024-02-19 16:24:28','2024-02-19 16:24:28'),(7,'Make it good man...\r\nwe will grow together.',2,2,'ticket','2024-02-19 16:35:10','2024-02-19 16:35:10'),(8,'Need help?',12,3,'ticket','2024-02-19 20:27:57','2024-02-19 20:27:57'),(9,'what do you mean?',2,3,'ticket','2024-02-19 20:52:09','2024-02-19 20:52:09'),(10,'wait, is that all you see is the \"Need help?\"\r\n\r\nThat\'s all I see and I just had something long typed out about helping with the small imperfections and little glitches I\'ve ran into but I was just asking if you would want some help with pointing out that type of stuff or would it get on your nerves? \r\n\r\nI\'ve ran into a few things, like only showing the subject line when I first create a ticket.\r\nThat was the subject line \"Need Help?\" It left out the body of the ticket.\r\n\r\nAlso something wrong with going back and editing the shipping methods after you post them for the first time. \r\n\r\nAnd then I get redirected at random after clicking a link and get a 404 error.\r\n\r\nAnd also, I dont see the Market or admins PGP keys anywhere so I was asking for your PGP or the markets PGP so I can encrypt anything thats sensitive. ALthough I like to use PGP all the time.\r\n\r\nIt was more nice and subtle, the last message. Where it cut off, it made me get to the point on this message. Sorry if I sound rude or anything. Working on marketing right now. \r\n\r\nYou going to get it put on Dark.fail or Tor.Taxi link page?',12,3,'ticket','2024-02-19 21:04:00','2024-02-19 21:04:00'),(11,'ok thanks a lot for your feed back I will work on that.\r\nalso yea I want to put on the link Dark.fail or Tor.Taxi I message then on dread but had no reply back yet.\r\nthe market keys and staffs key I will add a sections in few hours where you can click and see all keys ok.\r\n\r\nfor the redirect back and 404 page sorry I gotta look act the logs to know more am the only dev so it pain in the ass to get everything.',2,3,'ticket','2024-02-19 21:20:17','2024-02-19 21:20:17'),(12,'Okay, I\'ll speak more to you when I get the PGP. Don\'t get himmed up advertising or marketing but it\'s something that gotta be done. I\'ll comment and throw ads up whenever I get free time which is almost all I got. Can you send me a PGP to encrypt with so I can say what I need to if I need to plz?\r\n\r\nI got you anytime you need help. I know you can\'t trust anyone but yourself, but if there was someone I could tell you to trust 99.9% it would be me. \r\n\r\nNice ads so far btw, if it\'s not a fake profile and they just wanna be you lol\r\n\r\nHopefully blessings will come in the future.',12,3,'ticket','2024-02-19 21:29:40','2024-02-19 21:29:40'),(13,'store',10,4,'ticket','2024-02-19 21:34:27','2024-02-19 21:34:27'),(14,'-----BEGIN PGP PUBLIC KEY BLOCK-----\r\n\r\nmQINBGVDBT8BEADHIWZjDw5osYUhxqRxO9kC4ZyKMHwcx5wBZDS7A2oUk5LWm0SP\r\noXjI3b0NIxa2QY+1EVxCro5m3PPil7zW7XlGM8S3KoQnH4NV1kQ9PvAdbpq6b87p\r\nbHPTjLEJ1u0Kz5DzNGBo8hNMwJLvocr7Nj87sTmSvHX3xqhoKSsu+Jo+2NwbFVgU\r\nxZluEYLJ+z+0/jo3i7FtGynXJpTReA2RLZO9vzGQ7OlyhS/WqgOmXl47rL25c2Y6\r\nZKbl5cm0SW0LG4KvTHaYZVODpf34D2Oe0QCiD12meNYJbZgelMBP/GMHsKem3sS1\r\nsfKamlV4uRscBO+/pDvA2KpjuZpUDs4ZRUa8dPMEWc2i34QgaLMZtk6jSdmWUxtM\r\neGBfHMR7fCUaLvcwSc8Bzeg3MucKmrPBYtNmYBa8jKIf/Og7LO/nj1Wl5IXPMCBx\r\nwcjn0tf7UXdkMSZKEBigeSlQ3fsGS73lkmQPqjwoPkfzQg5dM5u4b9Sm3rRfHuJA\r\nMxxx0su+PYMXHHHKR1HwhqrTWybRso7e20CTHfrDX1sGFI7/FGbNM0Pf2gC8d4EN\r\nzLe7eFv8j9iakULBl96aJrxrPAXOOVQq+g8OukLM/6Fn7TRCxQqM39EKrLffgFho\r\n50djtpFany90lhSbolqVOrOi2lk6Ozl5s1qwrL0l+P/HWEsKCx1m/5UA/wARAQAB\r\ntAVPc2ludIkCUQQTAQgAOxYhBEG3DeCvseCayb2nHGBcDiQzhcgvBQJlQwU/Ahsj\r\nBQsJCAcCAiICBhUKCQgLAgQWAgMBAh4HAheAAAoJEGBcDiQzhcgvEacP/Rg9uvHk\r\nzGnJJNy/KQRcnPEFh/pv2STn95UhjM6cRDo2yPwo0NZ91L0+wPBUiGDaJcfFW90q\r\nEfBi0fLUYAOoUFyuAtw8xfCIvqTFgEfNpRpSIz6NWcESWulTBYs02uCRHZ7FuBFA\r\nLl8tWrRoApNKpjiYmdDJFjBZcrkJHnLPQAhq6Sbd/4bK6UP5X7QljZPwsuKN9rem\r\n/PuxqER7ru5GEiuxny0MWPRm31XjxwKPuBxFN6N2mQhQnWwF01meUcjEjaLTSZSw\r\nYfzlDxLARY/8iNkaYF+z+YJ8UjF/mSsNZfj6QzvfExt9ZFM9D/HFxXjo77mqnLGu\r\npvIT6tlAoAF2C+klb8Zr0mMow465b2E+au4p7sgInDz1lTuG6eQear0w9TYNbJg/\r\nul5XLGN9fKGqxuDsUhd2JE5hqGx+sTguN3rPQMegg6c+yQVAGYZ0hMAdbaRsFF2T\r\nG1CAGPOYZWR66BTCkjhOV9zDGdD20P0eyT6Xsi9aSiqhIlCUBPRs5TcG9weJybhg\r\n/fraJVreDlbylciHi90+f/QJ/4KmrPc/d9iBtUjXM+mGucd9OogtmgO6MR7iXpuK\r\nGit39CJ6hQ+m6qLj3vJZ2rBkrrwSXfF9vOAVLIFcLCVkPL49IwOLsIptn/4C26l4\r\nJ9s0qpO+JUoTEBV6W3pz4DF297iW8wyUzSEWuQINBGVDBT8BEACnmm58MH4NXfOQ\r\ncePAB9Yg9A/EBOzzIwESb71yQsuCnu4mBVin1e2eNx6n8rEtV2JPtUIMizlpJqxG\r\nepU5XLFdAWmN1We/Yn0+/0FADOuPPtBUekizCsxuoRQaQSFLpA/7K5CyyPkgKBjV\r\nxASgLb0lTKfvPR9rIV3b4i/E8es/PBkDIPEpkkMLTruqDkEW5280akxXez+0CYyH\r\nQ0RmwZ9X3Iw3nP4X9Cgsx6BlulfqZLoi2lgcT3Xw7Zj0ryiekutWW1i1mVwUwEYC\r\nyFyZKKj0CNTNzCik2Ah7LbxZV4IljSMxPdzJQv1vnsfayGSw5zUthZ8JF+YGX/ZI\r\ntQMCyut5k2QV/5umUZPL/+/s2M4CduGt66NDXTEMmU69h0kQTSBjTKft46CYk05H\r\nqjMHfZn8/sGp2rzFCVfZNAOKi370W+m2oTWT99Ok0BZfmVIHmHkwbz4OUoAV2igo\r\nV8tJjIAEdgD4RdlNUr4/8jiSvzudtUbqUGBu09743bJ3PkpYW/9MxBN6cRrO7MR7\r\njCIbBgGL5Ufw/yQ6SYPiu0EapqbVcpollMJE0JuwonsoYbay0b1gy0Z3+3zkMueb\r\neuMOsTc6w16NjjzymYJTix4foQNukQ42QJc6XaUQ8UJjIdB6i5UCVtUKRocbD+84\r\naYaWrOb54KmxSlF+5GUiBeQMeGk37wARAQABiQI2BBgBCAAgFiEEQbcN4K+x4JrJ\r\nvaccYFwOJDOFyC8FAmVDBT8CGwwACgkQYFwOJDOFyC851hAAvw2S+zDoX+Iih+fL\r\nIbDJ8n31UQHj0d1Y3MCvtv20Y82gHJTIM1KtIm7PqXqnQvWIzMoBFB7VE5vMey+8\r\nNraztavSVMYk8kDoA+DzQ9GMP+EjlPUAlVU8ZIzZbNRT5VPzHlb4Ds8TzFmZIktv\r\n9srmv55W6cuj3F5FK05qbmLUL8KOa7meZFhnFCMb5D9ifMrvHc8Sh4N3nLNM3Uq6\r\ntfCayJBYnA7ZLivY9Y6D1tja0iD1xu+NckealehN8TNFhl1ncIt0WlIR+OAoJlEb\r\nKCXKdgADsQMoiiboNloShAQQ9kwQoqnjyxKTxD4wVVSH0iZj2vKT86Be5OqFoegn\r\nAZS2xelV/j71ll82OOe4lomjYHJzmuLkz08GU/6WfHxx99ZFO+ry5RymVF3aeNN4\r\n9tPFMCZWRL3RP4ZnTCDPQ6LBJlFAuXpyV8x50oVFiIIsFrtVF6D8tWr0K8Q5+wAx\r\nw2PnEx/oZ7tYFEOT5IVvBiqL9P0ikyHO/ANfBPkUkyCuckPkJ6N8/xtcb3PSnAXK\r\nJ6fit9BZ0ogYZltZGEXlEJDK2qJELn6/3SUYW3lwkVkhzswO6bN94/IpVbXBmV9t\r\nWs6hfNZXzEbfh1C8BuBQMgwV4T/3RZGsRIAMXXP23oJFNIdOQ5YBpFR1sOF5azHv\r\n+U/UdxiaGjEndwYBvhJy41D5wVg=\r\n=5F+K\r\n-----END PGP PUBLIC KEY BLOCK-----',2,3,'ticket','2024-02-19 21:48:51','2024-02-19 21:48:51'),(15,'yes people try to be others you are correct',2,3,'ticket','2024-02-19 21:49:47','2024-02-19 21:49:47'),(16,'Fyodor',20,5,'ticket','2024-02-19 21:50:04','2024-02-19 21:50:04'),(17,'hii here is your key\r\n\r\nRBmyi2pOJZ26XBtIIf5LORcPWJn0eJH7ks8o56Mwmp6wtPJZMnIp7PjnvuNgraIz580dRtiEqbTZ0WnCuMpmWCmse0x9HjqyiqK3kLOzYLAklsZ6TwJklQzVDQd2tabe',2,4,'ticket','2024-02-19 21:57:14','2024-02-19 21:57:14'),(18,'Here is your key mate! \r\nopen a store now\r\n\r\ntugLe9bY2z1HnRA9qcbnTzVoCTuvrc3RRnzYYAnSgZBuBC5pSgohmBvJOd5VpiNxmbINeFSl0CdafzAcD9UKgIC3pwJfIaUcUtdW8z2AJ0w3rAGirN76GgZIQZYzjuNM',2,5,'ticket','2024-02-19 22:00:32','2024-02-19 22:00:32'),(19,'I have revoke the key cuz cant find you on dread.\r\nwhere do you sale on or any info to support your request',2,4,'ticket','2024-02-19 22:04:55','2024-02-19 22:04:55'),(20,'My previous ID was FocusedFred. I used to sell on Abraxas, Evo, Middle Earth, Nightmare, and a couple of others. I shut those accounts down because someone gave me a fake address and a package got captured, so I went in full wipe down mode. Since then, I have moved to a different area and am ready to setup shop again, but under a different name. Thank you for the reply.',10,4,'ticket','2024-02-19 22:11:24','2024-02-19 22:11:24'),(21,'do you have stocks?\r\nif so got to set key in settings and open a waiver fill the form.\r\ni will approve it',2,4,'ticket','2024-02-19 22:17:13','2024-02-19 22:17:13'),(22,'Thank you very much! Yes, I have plenty of stock right now. When I try to do the waiver it gives me errors when trying to upload my proof pictures. It says failed to upload proof1 and failed to upload proof3. Let me know what I need to do and I\'ll take care of it.',10,4,'ticket','2024-02-19 22:22:08','2024-02-19 22:22:08'),(23,'1. Image size must not be greate than 1MB \r\n2. You should remove all metadad\r\n3. it should only be png.jpg,jpeg image',2,4,'ticket','2024-02-19 22:29:56','2024-02-19 22:29:56'),(24,'That worked. File size was the culprit. Thanks again!',10,4,'ticket','2024-02-19 22:46:04','2024-02-19 22:46:04'),(25,'waiver',24,6,'ticket','2024-02-19 23:57:18','2024-02-19 23:57:18'),(26,'Here is your key add pgp key and enable 2fa\r\n\r\neXp9YZAuiZWcU660yOY25x6Vyfe4g31c7IGg8Bob8YSo0kOJsMF6FlnJJFmqG9UxqVQFluWfB5Qb9rGrrpzmuGNnAeoZj7oDcgec00FCiohAe7XbGCggJdHaDWDEd0sC',2,6,'ticket','2024-02-20 00:01:42','2024-02-20 00:01:42'),(27,'i went to upload pgp as i have done on everyother acount, but it comes back as public name does not match key?',24,6,'ticket','2024-02-20 00:46:03','2024-02-20 00:46:03'),(28,'Dear Admin',29,7,'ticket','2024-02-22 12:01:45','2024-02-22 12:01:45'),(29,'-----BEGIN PGP MESSAGE-----\r\n\r\nhQIMA8FkkDKCjy6+AQ//eLhAd+Uld4ncfNvTixZs7rXOWBH7jl1efiqbOwdgRweq\r\n09ZRDsHKCodlIz2+eHDJI/MqYazVghQPX10o6I0yX8i3Xo3yHPySb0qE4Fw0F021\r\nQZzc6bjTbaFMPm6eDjtencxjAMDz4ztSBRkRBftg4HEgszOkMeBoiMPMuDXyrFcs\r\n3GiIqPVFBYGMQBXyieREsUoJ7Kp54L24umM1/H1lFW0+04Hf0uT+xHtyAPzNTYPd\r\nheLsfX0W/P13nbgZZYZGwgbQC+HIWF0ViutGMGajDSiLlHFCaEzf+oJubEdVcuhO\r\nBTIFslaS95b/cOFNKhUHWYzPJ+9t2YfyvU11L834swH5lokldhX4VRy/HMrIWjhf\r\nkgJlIZlWOGAwlOXtFaz9Ley+iSgKKFqIkMxsDPWHisfz0KlhtOi0p8NfyIVCnVFe\r\nUpbiMLMkteDs1LwpAQ4nP1MUbRGfrUo0CiVCCDjsBLMw20H1AVf7XOAINfo//4Vw\r\nQ1Q/k919YOJG4UZQErHp33Y3EmwOjPmHD/cfF8WUtHljEOqNdF82Ze7F/CN+4KIl\r\ncg6ZZ5NC/kSE5dpjbgyB+Yz+GnGwtia/8Ic9/dB0Tf/35fjcaHz08LR08uTLwP9K\r\nCFKk3yVJEbtkLalLWzQln1EiYJnFmGvvPXODVXBNHw7R9dzo0kG/WqTXEKgTQ07S\r\n6QFj2ERK41U5lHZHt4Mtyxu+f6GQQxs6tS+mHBulQR/AMxMD9T9OvJuLAd2M2oU+\r\nfQetklk6L1woFr9eJLzPzNVD5KgV/FGEE9aNwvjr/Rvj0ZdxqK9Ewg1aVOHLi84V\r\n6oU+SgmZfOBfao7Nb4nDXKNH2OT41KoPhM970qBvxLdBGGaWxig/O2cMTVXB+K+S\r\n7lenx9t4J6RflByl/iL9ovGvR14joJDfRXzJIEscVk7cVBf1WgMR9FVpePBxuKlc\r\nKiGCJEILv4gv42XWMp8nvexOo2cTi991g+MU0lN0njIjjwZzV8RDxlkY2m0W5bKq\r\nS0HX1pu2lDCSTQfhyGjsT7Or3fYhZ2FyOK+VAQn3VAvYKOvlBOVP8x2Yue0J8fvD\r\nUwrm4M9o4OZKHxkY+MNgtyLhL5oWhiy0pHU9gNzcHqGxtT3IESi7LjbPYg4+Mn3o\r\nChT/dyskMy3RUyI6eL/ezBKQCvpMcL/Nw3ZTDDSU/Yo1qe+YGKP/t1iVmOvl7AKi\r\ng7Hwue0yTo5FgJNTwspESafWCh0AoSh5TP+NWYJO5Q0nPTiVmQ9BKWdrG+Bb4xWr\r\nTsXXweUENUsW6eBnVVEQ8cUvEdN/YLSuUNXEHrABzsXrfde8RWblJ3Z+PSOoTG5x\r\n192BAeEmK5wAIfI9wN+8MbPnEzgFVvgSCT7YUju+IrXGhWR1eM17Qt7B4AlV70Gu\r\n9m5CfDWNpxVBr/GCK1w874GZR9mFUsn8gnZ39yQ1RG1RUbRRvl+GdkjvVDOYGtLk\r\nZBw3HywudTCeNPvhpqWVyYz9lvC2ib93Eqkk/Xg+zZoogpEnn/A2FE2Aa+nsPtkK\r\nXBV6Tn8wpwafaH+mZHB0v11E3u5fazo=\r\n=tE/D\r\n-----END PGP MESSAGE-----',29,7,'ticket','2024-02-22 12:02:39','2024-02-22 12:02:39'),(30,'Hi mate,\r\nThanks for your request we are just coming onione again after 5 hours of our market been launched someone ddos us so badly that our site go down for 2 days it just coming up for like 1 hours and you come in but we ain\'t actully looking for any but in the future when am doone coding the juniro mod for support I will hits you up on dread if I didn;t forget your username.\r\n\r\nRegards\r\nOSINT',2,7,'ticket','2024-02-22 12:24:21','2024-02-22 12:24:21'),(31,'-----BEGIN PGP MESSAGE-----\r\n\r\nhQIMA8FkkDKCjy6+ARAApJqFL22rIlRpHGzXH8OBLbKZtrdKnZRIwLst+o9X83cv\r\nPGxz4iQ7gzTTE+pmx/mJHe4w4w56SVMZZ01+d2i8jaDBGmXLaXdLesAtkboQRThw\r\nS/uliwwoa6DyBxZEXIDMZ/lU1l9HbyZ+dYR1VvST/l7dC6IdcEiFrhgZBe9qDq+5\r\n66MBx/fNy0diBTWwVVbFksrbyAHw0/XW2Dyzf3kqQg9Z0SRfnh1tspcQgwk2aMvC\r\nDShTxca2FZfOu0/OmNtMqT5l1EAK4bpepBddIf8Y8EwJk2l838vfvqsjRmlM4/0F\r\nb8DQvzI7UQWNxLpVZIPQ/sjznogryp2foBfummq0mvHX0Kgi5OUGTHYkuGAHNWoj\r\neqWqVMFJtk4zzntWuM+I9YHXFxlL6ciMHOjgJ5n+mXQMpD7PrADcy4ylR9WI6PYW\r\nmH8fNIcJv1tREcp/AU4QDBnoMdt9ghXPTVfd5YMvBGKwmvWPovYKquH19Plv2m4R\r\nvkz5qfwPOz0+wq7XtHGNAAtSgkf5A7vKZHn3CRTF6rsjQTeVcl3WOtmD0/4poZ5v\r\nxLA4cysIavkhiNO6yMvTAb+fPZPVnNaKF3NkBEYaiQAU+vvl4OjoWp0xxtXGiMbH\r\nWg9EX9FgmpVZ1Naf7y5q2AhqVZihfBrmZ5liaJtZcVCrGg7NPmicdkqoXuUynpeF\r\nAYwDXtwQXMQcVboBC/40JCwUbp9CZnLvoU8ZfUwlqXRYWM34NRo+jdgU1regDxTK\r\n07yWvHy5UAgqziDpv1Ilgb7jL2UavfgWNYs3z+x3SscP7h6mg9gJ6js1w2QpdugT\r\nAmJGEowSgwhNQgGrCoP4hAcmm28ZjNB+z1Ev5zo5fNhEdV9e4ohZDeYB4aPRU225\r\nYPlGoDhkJZC6I6+wDJ8Uw8RKGFPPyEadF3QOIxRbIG097s/GKWBSK/6WEaGdDbi/\r\nbfboYsGjlXVaoXucREFADrpA1+4cyrwB9GAG/7L9CEHZnghtQhw+oJrN0btOc1eX\r\nrnPZ35m5/cVCLuyvmZE0bDOkbndpgvvv5PmbDi0JypYId1R5/2UyQ12HuE3orTGy\r\nc7V349zniB4OC4bv5/J/mEzRP/cpF2FkJMQgQ12Z33hUb16TDcsyL5F/Rn/fW1zt\r\ntx5BT/NQ8GJdUBBIo66T5EV9DvbFmPkTJQfQmRICzDSWmEZPqaAfWF8HeyjC3U8n\r\nN1FiGfdljHYXDjlR9DHS6QF1/npPlzcQN2xqurW0qcKG51Ohsl2rBddA9o0HY82v\r\nUTo1J1fZGFvA+bDUHbULDZaCfB+TWaRWYn8OBpR7lN4yqNKJzednRCglZBC/vfhn\r\nxtKyORC7WNof/ytXYKhjTWzJjrjkBzJq/WZqET/4gD4eb9FyQGSIg6ymBuKJgxrC\r\ntw1cyGy0Q2QPvRxi8Zv4M0Z/QouRGWefRcu1pgyVNzarm/eFOb1SapXCPoP32Ams\r\nnpEGGIszetH/Tc2KPnHKc0nJ5m3x9Jmc3375e6ncjwpCA82aU7qoljv4IJ+PlsAc\r\n7j+FptZGrtsqgDPAhaDrcNFMcd8ghkislB4Xuhyo1xq0Or7Eg8H88R8qN47DGan/\r\ntTmGj8py+PuxoaMN0FVCbhHihnKCJ60aRg+wB1k+ACPQ0/IBJSWcNHET00Ztn5q6\r\nAzjzrLlDSiPG26aJEJfI3PsYHar3NCgDCfbpCDmZeeESJf4RTb4QyqBuqHDn5tPW\r\nlhYOjAr58difWdloq3L1JLiSogwKCRD6B3f8hHPq5CPxY+aUFpp4/ijQtTV4JmlG\r\nZRdcfOD4/3/BI0Ksw+/qP3ZqHbxg+QIByX7POvI46cuY7pnpS0wZszQSKkzIj/sK\r\nq0+JNrIEcvtDE/cq8Ro/gv1Iw3zLku8qSuVTYsj9G+uOrXOsypglDqg1NwjaNu0a\r\nwGk7bDO+NKudJAD8g8IqEi1DM6Ek2nEsCnmzbalse0H182FUb3/aeLkNUuHng1vp\r\ngbrywri1m+yU9E24TdBgZMaBHOh9139TkHQBh7wSPtaoaxbtJOvz6oKffXUJJ7kS\r\npv6aogGrttS9u6xCv4tAC/7L3wyGfcmKEavz8TbE2wI+r5DA3dAlLXn/eDGnE7AF\r\njxE3fhmisX7fzkF/sI6xQheycVm4Plxe3BcyHuG7bl1qIIrfImQBN5q03BKVVRDh\r\nV3OWRg0juW2iTa9RRKGKojTCDZymVSvDWw7W5x9mV/wfGvNBDLNMvsLXn5jt4rGT\r\nsgDOliiSU/ZVRisnS5z/qm8fuvdsBDR3rL9YI5sL2BnFu+bNJl3zf7Z5ODAjHGIS\r\nN+i7PEkj6vMg8ZA=\r\n=HilU\r\n-----END PGP MESSAGE-----',12,3,'ticket','2024-02-22 14:10:47','2024-02-22 14:10:47'),(32,'Little fixes',12,8,'ticket','2024-02-22 14:21:48','2024-02-22 14:21:48'),(33,'1. Body of ticket still missing when submitting a support ticket. \"Little Fixes\" was the header and I had a couple things typed in the body field. Only the Subject header \"Little Fixes\" showed up leaving the main question/concern out which will lead to a whole bunch of single headers being sent and not the actual question leaving users frustrated at haviong to type again and also not having the opportunity to have an accurate response when logging back on due to admins not seeing the whole support ticket.\r\n\r\n2. Private URL or Mirror link is the same as the main link.\r\n\r\n3. When clicking \"Logout\" I believe it logs out, but instead of redirecting me to the main Whale link, it will direct me to my dashboard link - \r\n\r\nhttp://whalesmw7rwhw6jymotzewijn5epqrc3lwc6w72epfhauacakowilead.onion/store/CrystalClean/show/dashboard     - Leaving a 404 - Not Found blank screen. To confirm it signed out I went back to the main link - http://whalesmw7rwhw6jymotzewijn5epqrc3lwc6w72epfhauacakowilead.onion and it asks me to log bakc in, I\'m assuming it has correctly signed me out since not directing me back to my stores home page but wanted to verify and notify you of that.\r\n\r\n\r\n\r\nIf you keep this support ticket open I will add to the list anytime I find an error so that you can have someone go down the list and try to fix these things when you or someone you trust has the extra time. I can build clearnet sites, just nothing like an onion site but I\'m sure the links and redirecting, buttons, and injections are the same. MAybe just the hosting and DDOS are different? Praying won\'t found to many things for the sake of time and geting users and stores but just to let you know what I see is wrong so others don\'t question if the sites legit due to errors. It looks awesome though.\r\n\r\nIF interested, keep this ticket open and as I find things, I\'ll add to it.\r\n\r\nBlessings,\r\n\r\nCC',12,8,'ticket','2024-02-22 14:47:09','2024-02-22 14:47:09'),(34,'No problem man I will work on that now.\r\n\r\n\r\nyes the logout was design like that.\r\n\r\nBut I will change it.\r\n\r\nWe haven\'t started sharing privates links yet, but we will in few months.',2,8,'ticket','2024-02-22 14:51:16','2024-02-22 14:51:16'),(35,'Hi, \r\nyou ain\'t doin anything bad yet.\r\njust keep up the good work.\r\nIf I need mods will let you know.',2,3,'ticket','2024-02-22 15:02:19','2024-02-22 15:02:19'),(36,'Pgp key should wotk fix now',2,6,'ticket','2024-02-22 15:13:47','2024-02-22 15:13:47'),(37,'This message was sent by auto mod system please user reply, the store has started a dispute.',NULL,9,'dispute','2024-02-22 15:18:28','2024-02-22 15:18:28'),(38,'Sorry mate I click the dispute button unintended',3,9,'dispute','2024-02-22 15:19:53','2024-02-22 15:19:53'),(39,'Hello whales team',3,10,'ticket','2024-02-22 15:21:43','2024-02-22 15:21:43'),(40,'hello world',3,10,'ticket','2024-02-22 15:23:31','2024-02-22 15:23:31'),(41,'http://dumpliwoard5qsrrsroni7bdiishealhky4snigbzfmzcquwo3kml4id.onion/image/f59ce8782ffee062.png',24,6,'ticket','2024-02-22 19:31:42','2024-02-22 19:31:42');
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_100000_create_password_reset_tokens_table',1),(2,'2019_08_19_000000_create_failed_jobs_table',1),(3,'2019_12_14_000001_create_personal_access_tokens_table',1),(4,'2023_11_07_091552_create_users_table',1),(5,'2023_11_07_091625_create_stores_table',1),(6,'2023_11_07_091719_create_categories_table',1),(7,'2023_11_07_091720_create_products_table',1),(8,'2023_11_07_091802_create_conversations_table',1),(9,'2023_11_07_091804_create_supports_table',1),(10,'2023_11_07_091839_create_new_stores_table',1),(11,'2023_11_07_091908_create_reviews_table',1),(12,'2023_11_07_091917_create_feed_backs_table',1),(13,'2023_11_07_102802_create_replies_table',1),(14,'2023_11_07_103121_create_extra_options_table',1),(15,'2023_11_07_103132_create_orders_table',1),(16,'2023_11_07_103145_create_escrows_table',1),(17,'2023_11_07_103301_create_messages_table',1),(18,'2023_11_07_103323_create_notification_types_table',1),(19,'2023_11_07_103327_create_notifications_table',1),(20,'2023_11_07_103416_create_order_keys_table',1),(21,'2023_11_07_103541_create_referrals_table',1),(22,'2023_11_07_103559_create_reports_table',1),(23,'2023_11_07_103707_create_market_keys_table',1),(24,'2023_11_07_103719_create_f_a_q_s_table',1),(25,'2023_11_07_103735_create_bugs_table',1),(26,'2023_11_07_103847_create_carts_table',1),(27,'2023_11_07_103903_create_block_stores_table',1),(28,'2023_11_07_103911_create_favorite_stores_table',1),(29,'2023_11_07_103921_create_favorite_listings_table',1),(30,'2023_11_07_104003_create_message_statuses_table',1),(31,'2023_11_07_104036_create_promocodes_table',1),(32,'2023_11_07_104126_create_featureds_table',1),(33,'2023_11_07_115341_create_news_table',1),(34,'2023_11_07_120033_create_disputes_table',1),(35,'2023_11_09_121541_create_share_accesses_table',1),(36,'2023_11_09_131542_create_share_permissions_table',1),(37,'2023_11_13_140711_create_user_promos_table',1),(38,'2023_11_20_005006_create_wallets_table',1),(39,'2023_11_21_200527_create_participants_table',1),(40,'2023_11_26_192751_create_servers_table',1),(41,'2023_12_01_124200_create_waivers_table',1),(42,'2023_12_03_210558_create_unauthorizes_table',1),(43,'2023_12_26_101710_create_market_functions_table',1),(44,'2024_01_03_094229_create_news_statuses_table',1),(45,'2024_01_12_191147_create_store_rules_table',1),(46,'2024_01_13_211822_create_addresses_table',1),(47,'2024_01_29_141252_create_links_table',1),(48,'2024_01_30_221808_create_mirrors_table',1),(49,'2024_01_30_221858_create_pays_table',1),(50,'2024_01_31_114511_create_deposits_table',1),(51,'2024_01_31_132227_create_withdraws_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `mirrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mirrors` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `link` text COLLATE utf8mb4_unicode_ci,
  `type` enum('user','store','junior','senior','admin') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `mirrors` WRITE;
/*!40000 ALTER TABLE `mirrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `mirrors` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `new_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `new_stores` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `store_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `selling` text COLLATE utf8mb4_unicode_ci,
  `ship_to` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Worldwide',
  `ship_from` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Unknown',
  `store_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sell_on` text COLLATE utf8mb4_unicode_ci,
  `proof1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `proof2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proof3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `store_type` enum('paid','waiver') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'waiver',
  `avater` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `new_stores_user_id_foreign` (`user_id`),
  CONSTRAINT `new_stores_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `new_stores` WRITE;
/*!40000 ALTER TABLE `new_stores` DISABLE KEYS */;
/*!40000 ALTER TABLE `new_stores` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `news` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `author_id` bigint unsigned NOT NULL,
  `priority` enum('low','medium','high') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'medium',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `news_author_id_foreign` (`author_id`),
  CONSTRAINT `news_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
INSERT INTO `news` VALUES (1,'Whales Market Resilience: Weathering the Storm – Back Online After 2 Days of DDoS Turbulence!','We are delighted to inform you that our services are now back in operation, despite persistent DDoS attacks. Although the attackers continue their efforts, we have implemented various measures to mitigate the impact. This experience has taught us valuable lessons, as we were initially unprepared for such DDoS attacks. The unexpected challenge arose just five hours after the launch of our new market, resulting in a two-day outage. A special thanks to /u/him for providing invaluable assistance during this period.\r\n\r\nWe are pleased to announce that we have successfully restored our services and are actively working on expanding the nodes in our onion balance. We extend our gratitude to the DDoSers for providing quick insights into what actions should and shouldn\'t be taken. You can access the status update on our main URL; if it is not online at the moment, it will be restored shortly, as we are vigorously combating these challenges.\r\n\r\nWe would also like to express our appreciation to /d/newmarkets for providing an adept master to conduct penetration testing on our market. \r\n\r\nRegards, \r\nOSINT.',2,'medium','2024-02-22 12:39:02','2024-02-22 12:44:19');
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `news_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `news_statuses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `news_id` bigint unsigned NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `news_statuses_user_id_foreign` (`user_id`),
  KEY `news_statuses_news_id_foreign` (`news_id`),
  CONSTRAINT `news_statuses_news_id_foreign` FOREIGN KEY (`news_id`) REFERENCES `news` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `news_statuses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `news_statuses` WRITE;
/*!40000 ALTER TABLE `news_statuses` DISABLE KEYS */;
INSERT INTO `news_statuses` VALUES (1,10,1,0,'2024-02-22 13:09:38','2024-02-22 13:09:38'),(2,12,1,0,'2024-02-22 14:13:34','2024-02-22 14:13:34'),(3,32,1,0,'2024-02-22 14:59:55','2024-02-22 14:59:55'),(4,24,1,0,'2024-02-22 19:26:55','2024-02-22 19:26:55');
/*!40000 ALTER TABLE `news_statuses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notification_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification_types` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notification_types` WRITE;
/*!40000 ALTER TABLE `notification_types` DISABLE KEYS */;
INSERT INTO `notification_types` VALUES (1,'New News Article Published','A new news article has been published.','created','news','2024-02-19 07:43:17','2024-02-19 07:43:17'),(2,'News Article Updated','An existing news article has been updated.','updated','news','2024-02-19 07:43:17','2024-02-19 07:43:17'),(3,'New System Announcement','An important announcement from the system administrator.','announcement','news','2024-02-19 07:43:17','2024-02-19 07:43:17'),(4,'New Order Created','A new order has been created.','created','order','2024-02-19 07:43:17','2024-02-19 07:43:17'),(5,'Order Disputed','A dispute has been initiated for your order.','dispute','dispute','2024-02-19 07:43:17','2024-02-19 07:43:17'),(6,'Order Dispatched','Your order has been dispatched.','dispatched','order','2024-02-19 07:43:17','2024-02-19 07:43:17'),(7,'Order Completed','Your order has been successfully completed.','completed','order','2024-02-19 07:43:17','2024-02-19 07:43:17'),(8,'Order Cancelled','Your order has been cancelled.','cancelled','order','2024-02-19 07:43:17','2024-02-19 07:43:17'),(9,'Order Shipped','Your order has been shipped.','shipped','order','2024-02-19 07:43:17','2024-02-19 07:43:17'),(10,'Order Delivered','Your order has been delivered.','delivered','order','2024-02-19 07:43:17','2024-02-19 07:43:17'),(11,'Order Sent','Your order has been sent.','sent','order','2024-02-19 07:43:17','2024-02-19 07:43:17'),(12,'Order Accepted','Your order has been accepted by the store.','accepted','order','2024-02-19 07:43:17','2024-02-19 07:43:17'),(13,'Order Dispute Closed','Order dispute has been closed.','closed','dispute','2024-02-19 07:43:17','2024-02-19 07:43:17'),(14,'Store Encryption Key Generated','A new encryption key has been generated for your store.','key','store','2024-02-19 07:43:17','2024-02-19 07:43:17'),(15,'Store Pending Approval','Your store is pending approval for activation.','pending','store','2024-02-19 07:43:17','2024-02-19 07:43:17'),(16,'Store Approved','Your store has been approved and is now active.','approved','store','2024-02-19 07:43:17','2024-02-19 07:43:17'),(17,'Store Rejected','Your store activation request has been rejected, check your details and try again.','rejected','store','2024-02-19 07:43:17','2024-02-19 07:43:17'),(18,'Store Waiver Rejected','Your store waiver activation request has been rejected, check your details and try again.','waiver_rejected','store','2024-02-19 07:43:17','2024-02-19 07:43:17'),(19,'Store Waiver Approved','Your store waiver activation request has been approved, check your look for your encryption key and open a store.','waiver_approved','store','2024-02-19 07:43:17','2024-02-19 07:43:17'),(20,'PGP Encryption Key Added','A PGP encryption key has been added to your account.','pgp','account','2024-02-19 07:43:17','2024-02-19 07:43:17'),(21,'Store Verified','Your store has been verified, keep up the good work!.','verified','account','2024-02-19 07:43:17','2024-02-19 07:43:17'),(22,'Account on Vacation','Your account is on vacation mode.','vacation','account','2024-02-19 07:43:17','2024-02-19 07:43:17'),(23,'Account Warned','A warning has been issued for your account.','warning','account','2024-02-19 07:43:17','2024-02-19 07:43:17'),(24,'Account Password Changed','Your account password has been changed.','changed','account','2024-02-19 07:43:17','2024-02-19 07:43:17'),(25,'Private Mirror Added to Account','A private mirror has been added to your account.','added','account','2024-02-19 07:43:17','2024-02-19 07:43:17'),(26,'Your Referral Link Used','Your referral link has been used by a new user, thank you!.','used','referral','2024-02-19 07:43:17','2024-02-19 07:43:17'),(27,'Referral Payment Received','You have received payment for a referral.','received','referral','2024-02-19 07:43:17','2024-02-19 07:43:17'),(28,'Favorited Product Updated','One of your favorite product has been updated, check it out.','update','product','2024-02-19 07:43:17','2024-02-19 07:43:17'),(29,'Listing Restocked','Your listing has been restocked.','restocked','listing','2024-02-19 07:43:17','2024-02-19 07:43:17'),(30,'New Listings Added by Store','Your favorite store added new listings. Check them out!','added','listing','2024-02-19 07:43:17','2024-02-19 07:43:17'),(31,'New Incoming Deposit Received','A new deposit has been detected in your account wallet.','received','deposit','2024-02-19 07:43:17','2024-02-19 07:43:17'),(32,'Deposit Confirmed and Added to Balance','A deposit has been confirmed and added to your balance.','confirmed','deposit','2024-02-19 07:43:17','2024-02-19 07:43:17'),(33,'Deposit Request Cancelled','A deposit request has been cancelled.','cancelled','deposit','2024-02-19 07:43:17','2024-02-19 07:43:17'),(34,'Deposit Request Rejected','A deposit request has been rejected.','rejected','deposit','2024-02-19 07:43:17','2024-02-19 07:43:17'),(35,'New Withdrawal Request Submitted','A new withdrawal request has been submitted.','submitted','withdraw','2024-02-19 07:43:17','2024-02-19 07:43:17'),(36,'Withdrawal Request In Progress','A withdrawal request is in progress.','in_progress','withdraw','2024-02-19 07:43:17','2024-02-19 07:43:17'),(37,'Withdrawal Request Completed','A withdrawal request has been completed.','completed','withdraw','2024-02-19 07:43:17','2024-02-19 07:43:17'),(38,'New Shared Access Given','Shared access has been given to your account.','given','shared','2024-02-19 07:43:17','2024-02-19 07:43:17'),(39,'Shared Access Taken Away','Shared access has been removed from your account.','taken','shared','2024-02-19 07:43:17','2024-02-19 07:43:17'),(40,'Escrow Time Increased','The escrow time for your order has been increased.','increased','escrow','2024-02-19 07:43:17','2024-02-19 07:43:17'),(41,'Percentage Refund Processed','A percentage of your order has been refunded.','partial_refund','escrow','2024-02-19 07:43:17','2024-02-19 07:43:17'),(42,'Full Order Refund Processed','Your order has been fully refunded.','full_refund','escrow','2024-02-19 07:43:17','2024-02-19 07:43:17'),(43,'Product Reported','A product has been reported by a user for a violation of market rules.','reported','listing','2024-02-19 07:43:17','2024-02-19 07:43:17'),(44,'Store Reported','Your store has been reported by a user for a violation of market rules.','reported','store','2024-02-19 07:43:17','2024-02-19 07:43:17'),(45,'Bug Report Confirmed','Your bug report has been confirmed and we are working hard to fix it, admin will message you.','confirmed','bug','2024-02-19 07:43:17','2024-02-19 07:43:17'),(46,'Bug Report Rejected','Your bug report has been reviewed and rejected, thank you for your efforts.','rejected','bug','2024-02-19 07:43:17','2024-02-19 07:43:17'),(47,'New Bug Report Submitted','A new bug report has been submitted.','submitted','bug','2024-02-19 07:43:17','2024-02-19 07:43:17'),(48,'💰👈 Cashback For You','Your order has been completed we have return 50% of our escrow profit to your account wallet, Thank you for using Whales Market! Want more money? invite friends.','received','cashback','2024-02-19 07:43:17','2024-02-19 07:43:17');
/*!40000 ALTER TABLE `notification_types` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `actor_id` bigint unsigned DEFAULT NULL,
  `notification_type_id` bigint unsigned NOT NULL,
  `option_id` bigint unsigned DEFAULT NULL,
  `is_read` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_user_id_foreign` (`user_id`),
  KEY `notifications_actor_id_foreign` (`actor_id`),
  KEY `notifications_notification_type_id_foreign` (`notification_type_id`),
  CONSTRAINT `notifications_actor_id_foreign` FOREIGN KEY (`actor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `notifications_notification_type_id_foreign` FOREIGN KEY (`notification_type_id`) REFERENCES `notification_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,3,2,16,NULL,1,'2024-02-19 09:39:08','2024-02-19 23:24:13'),(2,2,NULL,31,NULL,1,'2024-02-19 10:52:39','2024-02-19 16:37:06'),(3,2,NULL,32,NULL,1,'2024-02-19 11:29:31','2024-02-19 16:37:06'),(4,12,NULL,14,NULL,1,'2024-02-19 16:32:05','2024-02-19 16:43:04'),(5,12,2,16,NULL,1,'2024-02-19 16:40:41','2024-02-19 16:41:58'),(6,5,2,16,NULL,1,'2024-02-19 20:50:16','2024-02-20 16:10:35'),(8,10,NULL,14,NULL,1,'2024-02-19 22:51:35','2024-02-19 23:02:47'),(10,22,NULL,4,1,0,'2024-02-19 22:59:28','2024-02-19 22:59:28'),(11,3,NULL,4,1,1,'2024-02-19 22:59:28','2024-02-19 23:24:13'),(12,22,NULL,12,1,0,'2024-02-19 23:22:36','2024-02-19 23:22:36'),(13,3,NULL,12,1,1,'2024-02-19 23:22:36','2024-02-19 23:24:13'),(14,22,NULL,9,1,0,'2024-02-19 23:23:34','2024-02-19 23:23:34'),(15,3,NULL,9,1,1,'2024-02-19 23:23:34','2024-02-19 23:24:13'),(16,22,NULL,10,1,0,'2024-02-19 23:23:43','2024-02-19 23:23:43'),(17,3,NULL,10,1,1,'2024-02-19 23:23:43','2024-02-19 23:24:13'),(18,10,2,16,NULL,1,'2024-02-19 23:26:06','2024-02-19 23:50:13'),(19,22,NULL,5,1,0,'2024-02-22 15:18:28','2024-02-22 15:18:28'),(20,3,NULL,5,1,0,'2024-02-22 15:18:28','2024-02-22 15:18:28');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `order_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_keys` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `private_key` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `public_key` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `message_sign` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_keys_order_id_foreign` (`order_id`),
  CONSTRAINT `order_keys_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `order_keys` WRITE;
/*!40000 ALTER TABLE `order_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_keys` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `store_id` bigint unsigned NOT NULL,
  `extra_option_id` bigint unsigned NOT NULL,
  `quantity` int NOT NULL,
  `shipping_address` text COLLATE utf8mb4_unicode_ci,
  `store_notes` text COLLATE utf8mb4_unicode_ci,
  `extra_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `cost_per_item` decimal(10,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `status` enum('pending','processing','shipped','delivered','dispute','sent','dispatched','cancelled','completed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_store_id_foreign` (`store_id`),
  KEY `orders_extra_option_id_foreign` (`extra_option_id`),
  KEY `orders_user_id_foreign` (`user_id`),
  KEY `orders_product_id_foreign` (`product_id`),
  CONSTRAINT `orders_extra_option_id_foreign` FOREIGN KEY (`extra_option_id`) REFERENCES `extra_options` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `orders_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `orders_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,22,1,1,1,1,NULL,'get the pdf here please leave a review thanks a lot\r\nhttps://filebin.net/kvapcg8y5nec9g78',0.00,1.00,0.00,'dispute','2024-02-19 22:59:28','2024-02-22 15:18:28');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `participants` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `conversation_id` bigint unsigned NOT NULL,
  `is_hidden` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `participants_user_id_foreign` (`user_id`),
  KEY `participants_conversation_id_foreign` (`conversation_id`),
  CONSTRAINT `participants_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `participants_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `participants` WRITE;
/*!40000 ALTER TABLE `participants` DISABLE KEYS */;
INSERT INTO `participants` VALUES (1,5,1,0,'2024-02-19 12:32:25','2024-02-19 12:32:25'),(2,2,1,0,'2024-02-19 13:49:49','2024-02-19 13:49:49'),(3,12,2,0,'2024-02-19 15:18:24','2024-02-19 15:18:24'),(4,2,2,1,'2024-02-19 15:58:35','2024-02-19 21:43:08'),(5,12,3,0,'2024-02-19 20:27:57','2024-02-19 20:27:57'),(6,2,3,0,'2024-02-19 20:51:22','2024-02-19 20:51:22'),(7,10,4,0,'2024-02-19 21:34:27','2024-02-19 21:34:27'),(8,20,5,0,'2024-02-19 21:50:04','2024-02-19 21:50:04'),(9,2,4,0,'2024-02-19 21:54:46','2024-02-19 21:54:46'),(10,2,5,0,'2024-02-19 21:55:07','2024-02-19 21:55:07'),(11,24,6,0,'2024-02-19 23:57:18','2024-02-19 23:57:18'),(12,2,6,0,'2024-02-19 23:59:00','2024-02-19 23:59:00'),(13,29,7,0,'2024-02-22 12:01:45','2024-02-22 12:01:45'),(14,12,8,0,'2024-02-22 14:21:48','2024-02-22 14:21:48'),(15,2,8,0,'2024-02-22 15:15:14','2024-02-22 15:15:14'),(16,2,7,0,'2024-02-22 15:15:22','2024-02-22 15:15:22'),(17,22,9,0,'2024-02-22 15:18:28','2024-02-22 15:18:28'),(18,3,9,0,'2024-02-22 15:18:28','2024-02-22 15:18:28'),(19,3,10,0,'2024-02-22 15:21:43','2024-02-22 15:21:43'),(20,2,10,0,'2024-02-22 18:37:13','2024-02-22 18:37:13');
/*!40000 ALTER TABLE `participants` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pays` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pays_user_id_foreign` (`user_id`),
  CONSTRAINT `pays_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pays` WRITE;
/*!40000 ALTER TABLE `pays` DISABLE KEYS */;
/*!40000 ALTER TABLE `pays` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `store_id` bigint unsigned NOT NULL,
  `quantity` int NOT NULL,
  `sold` int NOT NULL DEFAULT '0',
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_description` text COLLATE utf8mb4_unicode_ci,
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `product_type` enum('digital','physical') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'physical',
  `ship_from` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Unknown',
  `payment_type` enum('Escrow','FE') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Escrow',
  `ship_to` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'World Wide',
  `parent_category_id` bigint unsigned NOT NULL,
  `sub_category_id` bigint unsigned NOT NULL,
  `return_policy` text COLLATE utf8mb4_unicode_ci,
  `auto_delivery_content` text COLLATE utf8mb4_unicode_ci,
  `disputes_lost` int NOT NULL DEFAULT '0',
  `disputes_won` int NOT NULL DEFAULT '0',
  `category_promote` enum('yes','no') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no',
  `search_promote` enum('yes','no') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no',
  `status` enum('Active','Pending','Rejected','Paused') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `image_path1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_path2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_path3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `products_store_id_foreign` (`store_id`),
  KEY `products_parent_category_id_foreign` (`parent_category_id`),
  KEY `products_sub_category_id_foreign` (`sub_category_id`),
  CONSTRAINT `products_parent_category_id_foreign` FOREIGN KEY (`parent_category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `products_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `products_sub_category_id_foreign` FOREIGN KEY (`sub_category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,1,999,1,'Tor and The Dark Net: Remain Anonymous and Evade NSA Spying','Are You Tired of All The Spying and Lack of Privacy on The Internet? Keep Reading to Learn The Secrets to Staying Anonymous\r\n\r\nSo many people take their privacy on the internet for granted. Some may know and choose to ignore the fact, but every single thing you do online is being tracked and guess what? For better or for worse it is there forever. Whether you\'re simply browsing websites or you are accessing confidential information that you would rather no one know about there are ways to remain anonymous. Imagine this scenario, you create an account on a forum with your name and decide to do some political freedom fighting with it. Years down the road a future employer of yours does a simple google search of your name and finds everything you\'ve ever done. They don\'t hire you.\r\n\r\n\r\n\r\n\r\nA Preview of What You Will Learn\r\n\r\nINTRODUCTION TO TOR, HTTPS, AND SSL, PGP, TAILS, VIRTUAL BOX\r\nPGP Continued..\r\n\r\nWHOLE DISK ENCRYPTION AND FILE SHREDDING\r\nJAVASCRIPT VULNERABILITIES AND REMOVING PERSONAL METADATA FROM FILES\r\nGENERAL SECURITY PRECAUTIONS WHEN POSTING ONLINE, METADATA\r\nEXIF DATA\r\nRETAINING A LAWYER, HOW TO HANDLE GETTING CAUGHT OR\r\nINTERROGATED\r\nCOMBINING TOR WITH A VPN\r\nTHE ADVANTAGES AND DISADVANTAGES OF USING TOR OVER A VPN\r\nCONNECTING TOR -> VPN FOR WINDOWS USERS\r\nTRACKING COOKIES\r\nHOW FAR WILL LAW ENFORCEMENT GO?\r\nLEARNING FROM OTHERS’ MISTAKES. HOW THEY BUSTED SABU\r\nLEARNING FROM OTHERS’ MISTAKES. SABU BECAME FBI INFORMANT AND\r\nBETRAYED JEREMY HAMMOND\r\nWHERE YOU MIGHT CONSIDER RUNNING TO, IF YOU HAD NO OTHER\r\nCHOICE\r\nSECURING YOUR ACCOUNTS FROM FBI MONITORING\r\nINVINCIBILITY MINDSET, FEDERAL GOVERNMENT BULLYING TACTICS\r\nHOW TO CONNECT TO TOR OVER TOP OF TOR\r\nHOW TO VERIFY YOUR DOWNLOADED FILES ARE AUTHENTIC\r\nTOR CHAT\r\nOBTAINING, SENDING AND RECEIVING BITCOINS ANONYMOUSLY\r\nTHEY ARE WATCHING YOU – VIRUSES, MALWARE, VULNERABILITIES\r\nMONITORING YOU WITH AN ANTENNA\r\nCOOKIES & JAVASCRIPT REVISITED, PLUS FLASH COOKIES AND OTHER\r\nBROWSER TRACKING\r\nA FEW RECOMMENDATIONS\r\nCOLD BOOT ATTACKS, UNENCRYPTED RAM EXTRACTION\r\nTHE STRENGH OF CRYPTOGRAPHY AND ANONYMITY WHEN USED\r\nPROPERLY\r\nHIDING TOR FROM YOUR ISP – PART 1 – BRIDGES AND PLUGGABLE\r\nTRANSPORTS\r\nCAPABILITIES OF THE NSA\r\nBITCOIN CLIENTS IN TAILS – BLOCKCHAIN AND ELECTRUM',1.00,'physical','Unknown','Escrow','World Wide',2,15,NULL,NULL,0,0,'no','no','Active','1708341152_JcFyxMDx3XH8TnJjhKGN1xtgsjzAdgSLAoxnKuw4','1708341152_3YTD6ofvr3FiDkL6gZiAR8tIvQzERaN9S5ZJelKs','1708341152_OjeTtR8gAce11KAmNO1ZXEyoW0RrCkx8ycskWzHh','2024-02-19 11:12:32','2024-02-19 22:59:28'),(2,2,100,0,'1 Gram Meth - USA to USA','Fire meth\r\n\r\nUSPS First Class = 3-7 days\r\nPriority = 3-5 days T2D\r\nExpress = 1-3 days T2D\r\n\r\nTry to always give chunks\r\n\r\n\r\nRISK:\r\n\r\nMESSAGE US IF YOU WOULD LIKE AN ADDRESS TO SEND ANY PRODUCTS YOU BUY TO GET TESTED. A DONATION OF $5 TO THE ORGANIZATION THAT DOES THE TESTING IS RECOMMENDED SINCE IT IS A FREE SERVICE THAT SAVES THE LIVES OF MANY. ANY DONATION GREATER THAN $5 WOULD PROBABLY MUCH APPRECIATED. WILL INBOX THE LINK THAT PROVIDES ALL THE INFORMATION NEEDED TO MAKE SURE YOUR PRODUCTS ARE WHAT PEOPLE SAY THEY ARE. WE BELIEVE THESE TYPES OF TESTING FACILITIES ARE CRUCIAL TO ENSURE PUBLIC HEALTH. WE WILL ALSO INBOX STRAIGHT TO THE POINT GUIDELINE TO MAKE SURE THIS PROCESS IS DONE RIGHT AND THAT YOU GAIN THE RIGHT RESOURCES TO MAKE SURE YOU STAY SAFE WHILE USING OR SUEING AS SAFE AS POSSIBLE WHEN IT COMES TO YOUR LIFESTYLE, FOR YOURSELF & OTHERS.',20.00,'physical','Unknown','Escrow','United States',5,27,'REFUND POLICY:  All orders shipped with tracking are eligible for refund/reship. All orders without tracking are not subject to any refunds/reships due to not having the ability to check the status of your shipment. NO RETURNS. NZ & AUS have STRICT no return, refund, and/or rehipment policy.',NULL,0,0,'no','no','Active','1708361811_lydHZWMikg4dHNZb6qWTuG5mxhqfb1Mmi1dTC2H9','1708361811_KFeHkDoSdjqtAzrJKy5gjsqhRWAkBZTb0jcLXVCA',NULL,'2024-02-19 16:56:51','2024-02-19 18:09:34'),(3,2,100,0,'3.5 Grams Meth USA to USA','FIRE meth\r\n\r\nFirst Class Shipping Ground = 3-7 days\r\nPriority = 3-5 days T2D\r\nExpress = 1-3 days T2D\r\n\r\nTry to always give chunks\r\n\r\n\r\nRISK:\r\n\r\nMESSAGE US IF YOU WOULD LIKE AN ADDRESS TO SEND ANY PRODUCTS YOU BUY TO GET TESTED. A DONATION OF $5 TO THE ORGANIZATION THAT DOES THE TESTING IS RECOMMENDED SINCE IT IS A FREE SERVICE THAT SAVES THE LIVES OF MANY. ANY DONATION GREATER THAN $5 WOULD PROBABLY MUCH APPRECIATED. WILL INBOX THE LINK THAT PROVIDES ALL THE INFORMATION NEEDED TO MAKE SURE YOUR PRODUCTS ARE WHAT PEOPLE SAY THEY ARE. WE BELIEVE THESE TYPES OF TESTING FACILITIES ARE CRUCIAL TO ENSURE PUBLIC HEALTH. WE WILL ALSO INBOX STRAIGHT TO THE POINT GUIDELINE TO MAKE SURE THIS PROCESS IS DONE RIGHT AND THAT YOU GAIN THE RIGHT RESOURCES TO MAKE SURE YOU STAY SAFE WHILE USING OR SUEING AS SAFE AS POSSIBLE WHEN IT COMES TO YOUR LIFESTYLE, FOR YOURSELF & OTHERS.',50.00,'physical','Unknown','Escrow','United States',5,27,'REFUND POLICY:  All orders shipped with tracking are eligible for refund/reship. All orders without tracking are not subject to any refunds/reships due to not having the ability to check the status of your shipment. NO RETURNS. NZ & AUS have STRICT no return, refund, and/or rehipment policy.  All orders shipped with tracking are eligible for refund/reship. All orders without tracking are not subject to any refunds/reships due to not having the ability to check the status of your shipment.',NULL,0,0,'no','no','Active','1708362467_wUyOhT8qkdFgzhsSHGiX2oXeQf2wbGLTsA2dF3rj',NULL,'1708362467_kwfM15oqDYTpZJWvDHJ4e07fSy7wfOGo4RCCzwab','2024-02-19 17:07:47','2024-02-19 18:29:40'),(4,2,100,0,'7 Grams Meth USA to USA','Fire meth\r\n\r\nFirst Class Shipping Ground = 3-7 days\r\nPriority = 3-5 days T2D\r\nExpress = 1-3 days T2D\r\n\r\nTry to always give chunks\r\n\r\n\r\nRISK:\r\n\r\nMESSAGE US IF YOU WOULD LIKE AN ADDRESS TO SEND ANY PRODUCTS YOU BUY TO GET TESTED. A DONATION OF $5 TO THE ORGANIZATION THAT DOES THE TESTING IS RECOMMENDED SINCE IT IS A FREE SERVICE THAT SAVES THE LIVES OF MANY. ANY DONATION GREATER THAN $5 WOULD PROBABLY MUCH APPRECIATED. WILL INBOX THE LINK THAT PROVIDES ALL THE INFORMATION NEEDED TO MAKE SURE YOUR PRODUCTS ARE WHAT PEOPLE SAY THEY ARE. WE BELIEVE THESE TYPES OF TESTING FACILITIES ARE CRUCIAL TO ENSURE PUBLIC HEALTH.',90.00,'physical','Unknown','Escrow','United States',5,27,'REFUND POLICY:  All orders shipped with tracking are eligible for refund/reship. All orders without tracking are not subject to any refunds/reships due to not having the ability to check the status of your shipment. NO RETURNS. NZ & AUS have STRICT no return, refund, and/or rehipment policy.      All orders shipped with tracking are eligible for refund/reship. All orders without tracking are not subject to any refunds/reships due to not having the ability to check the status of your shipment.',NULL,0,0,'no','no','Active','1708362993_RpDCJki1dmlM7XNT4vsYImzGrGGkPr5ZPNjLEqWD','1708362993_nzaH6nWVzQBzUBU3S3b7nXVYXUP1cE7ZX3Bvv10a',NULL,'2024-02-19 17:16:33','2024-02-19 18:36:28'),(5,2,100,0,'14 Grams Meth USA to USA','Fire meth\r\n\r\nFirst Class Shipping Ground = 3-7 days\r\nPriority = 3-5 days T2D\r\nExpress = 1-3 days T2D\r\n\r\nTry to always give chunks\r\n\r\n\r\nRISK:\r\n\r\nMESSAGE US IF YOU WOULD LIKE AN ADDRESS TO SEND ANY PRODUCTS YOU BUY TO GET TESTED. A DONATION OF $5 TO THE ORGANIZATION THAT DOES THE TESTING IS RECOMMENDED SINCE IT IS A FREE SERVICE THAT SAVES THE LIVES OF MANY. ANY DONATION GREATER THAN $5 WOULD PROBABLY MUCH APPRECIATED. WILL INBOX THE LINK THAT PROVIDES ALL THE INFORMATION NEEDED TO MAKE SURE YOUR PRODUCTS ARE WHAT PEOPLE SAY THEY ARE. WE BELIEVE THESE TYPES OF TESTING FACILITIES ARE CRUCIAL TO ENSURE PUBLIC HEALTH.',140.00,'physical','Unknown','Escrow','United States',5,27,'REFUND POLICY:  All orders shipped with tracking are eligible for refund/reship. All orders without tracking are not subject to any refunds/reships due to not having the ability to check the status of your shipment. NO RETURNS. NZ & AUS have STRICT no return, refund, and/or rehipment policy.      All orders shipped with tracking are eligible for refund/reship. All orders without tracking are not subject to any refunds/reships due to not having the ability to check the status of your shipment.',NULL,0,0,'no','no','Active','1708363437_BrMRDlr4HUy5CzDbSeTTVQNFMwZcWiP4c50XajAd','1708363437_D4mxNTF09k3K2xlDt18raCkNSFazdNGIr0Mi2Azb',NULL,'2024-02-19 17:23:57','2024-02-19 18:41:41'),(6,2,100,0,'1 oz Meth USA to USA (28 Grams)','Fire meth\r\n\r\nFirst Class Shipping Ground = 3-7 days\r\nPriority = 3-5 days T2D\r\nExpress = 1-3 days T2D\r\n\r\nTry to always give chunks\r\n\r\n\r\nRISK:\r\n\r\nMESSAGE US IF YOU WOULD LIKE AN ADDRESS TO SEND ANY PRODUCTS YOU BUY TO GET TESTED. A DONATION OF $5 TO THE ORGANIZATION THAT DOES THE TESTING IS RECOMMENDED SINCE IT IS A FREE SERVICE THAT SAVES THE LIVES OF MANY. ANY DONATION GREATER THAN $5 WOULD PROBABLY MUCH APPRECIATED. WILL INBOX THE LINK THAT PROVIDES ALL THE INFORMATION NEEDED TO MAKE SURE YOUR PRODUCTS ARE WHAT PEOPLE SAY THEY ARE. WE BELIEVE THESE TYPES OF TESTING FACILITIES ARE CRUCIAL TO ENSURE PUBLIC HEALTH.',250.00,'physical','Unknown','Escrow','United States',5,27,'REFUND POLICY:  All orders shipped with tracking are eligible for refund/reship. All orders without tracking are not subject to any refunds/reships due to not having the ability to check the status of your shipment. NO RETURNS. NZ & AUS have STRICT no return, refund, and/or rehipment policy.      All orders shipped with tracking are eligible for refund/reship. All orders without tracking are not subject to any refunds/reships due to not having the ability to check the status of your shipment.',NULL,0,0,'no','no','Active','1708363875_iSKshjqVDDscC7TdUTZQLVZ1DcipY46nuaDOMgOy','1708363875_myFbuLAYPLcvsjq0my6pbhomVMYDpFfsLjeuOi91',NULL,'2024-02-19 17:31:15','2024-02-19 18:40:12'),(7,2,100,0,'1 Gram Meth USA to Worldwide','READ FULL DISCRIPTION, INCLUDING REFUND POLICY, BEFORE ORDERING. AUSTRAILIA AND NZ HAVE A MORE STRICT POLICY.\r\n\r\nCrystal Clean Meth',35.00,'physical','Unknown','Escrow','World Wide',5,27,'INTERNATIONAL WORLDWIDE SHIPPING  -       NO REFUNDS ON *ANY* INTERNATIONAL ORDERS. ONLY RESHIPMENTS AVAILABLE WITH ACCOUNTS WITH PRIOR MARKET HISTORY AND A GOOD STANDING. MORE CONSIDERATION WILL GO TO THOSE WITH PREVIOUS SUCCESSFUL PURCHASES WITH US.   IMPORTANT: TO ALL CUSTOMERS FOR ANY DISPUTES. ABSOLUTELY NO REFUNDS OR RESHIPMENTS TO AUSTRALIA OR NZ USING ANY SHIPPING METHOD.',NULL,0,0,'no','no','Active','1708364999_97Me1viJlU0sD2iTmSZWK53tEAllXJHJWbRmukuj','1708364999_7S4jr7ikdl3hjSfr0GA2gJ4Yx1nCKXA5G6gMrf8x',NULL,'2024-02-19 17:49:59','2024-02-19 18:39:03'),(8,2,100,0,'3.5 Grams Meth USA to Worldwide','READ FULL DISCRIPTION, INCLUDING REFUND POLICY, BEFORE ORDERING. AUSTRAILIA AND NZ HAVE A MORE STRICT POLICY.\r\n\r\nCrystal Clean Meth',85.00,'physical','Unknown','Escrow','World Wide',5,27,'REFUND POLICY:  All orders shipped with tracking are eligible for refund/reship. All orders without tracking are not subject to any refunds/reships due to not having the ability to check the status of your shipment. NO RETURNS. NZ & AUS have STRICT no return, refund, and/or rehipment policy.',NULL,0,0,'no','no','Active','1708365183_2uRGDWHtCi2ZtDhCHze9fyEUVaqjRQPXuJ0xH5hi','1708365183_wx5JpLY7hv1aMcZ0Wn6mhwDMmaqpvbu4doUBNjBV',NULL,'2024-02-19 17:53:03','2024-02-19 18:37:37'),(9,2,100,0,'7 Grams Meth USA to Worldwide','READ FULL DISCRIPTION, INCLUDING REFUND POLICY, BEFORE ORDERING. AUSTRAILIA AND NZ HAVE A MORE STRICT POLICY.\r\n\r\nCrystal Clean Meth',150.00,'physical','Unknown','Escrow','World Wide',5,27,'NO REFUNDS ON *ANY* INTERNATIONAL ORDERS. ONLY RESHIPMENTS AVAILABLE WITH ACCOUNTS WITH PRIOR MARKET HISTORY AND A GOOD STANDING. MORE CONSIDERATION WILL GO TO THOSE WITH PREVIOUS SUCCESSFUL PURCHASES WITH US.   IMPORTANT: TO ALL CUSTOMERS FOR ANY DISPUTES. ABSOLUTELY NO REFUNDS OR RESHIPMENTS TO AUSTRALIA OR NZ USING ANY SHIPPING METHOD.',NULL,0,0,'no','no','Active','1708365556_QwxBfT9MdZcoBm0JsELvIGJlFDXjepsFg2zng736','1708365556_YOBKD3ovwuGr1BCCz5lEbYS6uoBfTOx1wlvnXhvS',NULL,'2024-02-19 17:59:16','2024-02-19 18:35:04'),(10,2,100,0,'14 Grams Meth USA to Worldwide','READ FULL DISCRIPTION, INCLUDING REFUND POLICY, BEFORE ORDERING. AUSTRAILIA AND NZ HAVE A MORE STRICT POLICY.\r\n\r\nCrystal Clean Meth',250.00,'physical','Unknown','Escrow','World Wide',5,27,'NO REFUNDS ON *ANY* INTERNATIONAL ORDERS. ONLY RESHIPMENTS AVAILABLE WITH ACCOUNTS WITH PRIOR MARKET HISTORY AND A GOOD STANDING. MORE CONSIDERATION WILL GO TO THOSE WITH PREVIOUS SUCCESSFUL PURCHASES WITH US.   IMPORTANT: TO ALL CUSTOMERS FOR ANY DISPUTES. ABSOLUTELY NO REFUNDS OR RESHIPMENTS TO AUSTRALIA OR NZ USING ANY SHIPPING METHOD.',NULL,0,0,'no','no','Active','1708365771_juwnCfJRF4DfbLYBiyIHNQpLaeSd9nvMNCLZB6YF','1708365771_MNcku2ra2kKNCChZaaJmuelzv3ErDg5Fqs4PkLrX',NULL,'2024-02-19 18:02:51','2024-02-19 18:32:35'),(11,2,100,0,'1 oz Meth USA to worldwide','READ FULL DISCRIPTION, INCLUDING REFUND POLICY, BEFORE ORDERING. AUSTRAILIA AND NZ HAVE A MORE STRICT POLICY.\r\n\r\nCrystal Clean Meth',450.00,'physical','Unknown','Escrow','World Wide',5,27,'NO REFUNDS ON *ANY* INTERNATIONAL ORDERS. ONLY RESHIPMENTS AVAILABLE WITH ACCOUNTS WITH PRIOR MARKET HISTORY AND A GOOD STANDING. MORE CONSIDERATION WILL GO TO THOSE WITH PREVIOUS SUCCESSFUL PURCHASES WITH US.   IMPORTANT: TO ALL CUSTOMERS FOR ANY DISPUTES. ABSOLUTELY NO REFUNDS OR RESHIPMENTS TO AUSTRALIA OR NZ USING ANY SHIPPING METHOD.',NULL,0,0,'no','no','Active','1708365956_T3fq1YqRceY0zdaaKsf9VvDMTdGvPNmQM4S5ER7g','1708365956_inUcaEtpvOxASPvS7ag3rzQ9XOTpNKaBde7qpV0F',NULL,'2024-02-19 18:05:56','2024-02-19 18:12:32');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `promocodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `promocodes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `store_id` bigint unsigned NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount` int NOT NULL,
  `type` enum('fixed','percentage') COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration_date` timestamp NULL DEFAULT NULL,
  `usage_limit` int NOT NULL,
  `times_used` int NOT NULL DEFAULT '0',
  `status` enum('active','paused','expired') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `promocodes_product_id_foreign` (`product_id`),
  KEY `promocodes_store_id_foreign` (`store_id`),
  CONSTRAINT `promocodes_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `promocodes_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `promocodes` WRITE;
/*!40000 ALTER TABLE `promocodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `promocodes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `referrals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `referrals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `referred_user_id` bigint unsigned NOT NULL,
  `balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `status` enum('pending','confirmed','paid') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `referrals_user_id_foreign` (`user_id`),
  KEY `referrals_referred_user_id_foreign` (`referred_user_id`),
  CONSTRAINT `referrals_referred_user_id_foreign` FOREIGN KEY (`referred_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `referrals_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `referrals` WRITE;
/*!40000 ALTER TABLE `referrals` DISABLE KEYS */;
/*!40000 ALTER TABLE `referrals` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `replies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `review_id` bigint unsigned NOT NULL,
  `reply` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `replies_review_id_foreign` (`review_id`),
  CONSTRAINT `replies_review_id_foreign` FOREIGN KEY (`review_id`) REFERENCES `reviews` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `replies` WRITE;
/*!40000 ALTER TABLE `replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `replies` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reports` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `reported_id` int NOT NULL,
  `subject` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','verified','fake') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `report` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_store` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reports_user_id_foreign` (`user_id`),
  CONSTRAINT `reports_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `store_id` bigint unsigned NOT NULL,
  `communication_rating` int NOT NULL,
  `product_rating` int NOT NULL,
  `shipping_speed_rating` int NOT NULL,
  `price_rating` int NOT NULL,
  `feedback` enum('positive','neutral','negative') COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_id` int DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reviews_user_id_foreign` (`user_id`),
  KEY `reviews_product_id_foreign` (`product_id`),
  KEY `reviews_store_id_foreign` (`store_id`),
  CONSTRAINT `reviews_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reviews_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `servers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ip` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `port` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_tor` tinyint(1) NOT NULL DEFAULT '0',
  `type` enum('wallet','daemon','api') COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_user` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extra_pass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `servers` WRITE;
/*!40000 ALTER TABLE `servers` DISABLE KEYS */;
INSERT INTO `servers` VALUES (1,'198.58.115.118','18090','monero','3fi8koYOuwU1KumYwpCSJg==',0,'wallet','wale','whales@362002W','2024-02-19 09:42:49','2024-02-19 10:37:22'),(2,'https://min-api.cryptocompare.com/data/price?fsym=BTC&tsyms=USD','51142.4','BTC',NULL,0,'api',NULL,NULL,'2024-02-19 09:44:04','2024-02-23 10:54:25'),(3,'https://min-api.cryptocompare.com/data/price?fsym=XMR&tsyms=USD','123.77','XMR',NULL,0,'api',NULL,NULL,'2024-02-19 09:44:43','2024-02-23 10:54:25');
/*!40000 ALTER TABLE `servers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `share_accesses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `share_accesses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `store_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `status` enum('active','revoked') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `share_accesses_store_id_foreign` (`store_id`),
  KEY `share_accesses_user_id_foreign` (`user_id`),
  CONSTRAINT `share_accesses_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `share_accesses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `share_accesses` WRITE;
/*!40000 ALTER TABLE `share_accesses` DISABLE KEYS */;
/*!40000 ALTER TABLE `share_accesses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `share_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `share_permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `share_access_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `share_permissions_share_access_id_foreign` (`share_access_id`),
  CONSTRAINT `share_permissions_share_access_id_foreign` FOREIGN KEY (`share_access_id`) REFERENCES `share_accesses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `share_permissions` WRITE;
/*!40000 ALTER TABLE `share_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `share_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `store_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store_rules` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_xmr` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `store_rules` WRITE;
/*!40000 ALTER TABLE `store_rules` DISABLE KEYS */;
INSERT INTO `store_rules` VALUES (1,'1',1,'2024-02-19 07:43:30','2024-02-19 07:43:30'),(2,'Wales Market imposes a 5% commission fee on successful sales.',0,'2024-02-19 07:43:30','2024-02-19 07:43:30'),(3,'Store fees are non-refundable to uphold market integrity.',0,'2024-02-19 07:43:30','2024-02-19 07:43:30'),(4,'Prohibited listings include guns, CP (Child pornography), Covid-19 vaccines, assassination services, explosives, fentanyl, poisons, acids, and any items intended for harm.',0,'2024-02-19 07:43:30','2024-02-19 07:43:30'),(5,'Stores focused on selling harmful products will be penalized.',0,'2024-02-19 07:43:30','2024-02-19 07:43:30'),(6,'Prohibited services include hitmans, murders, and snuffs.',0,'2024-02-19 07:43:30','2024-02-19 07:43:30'),(7,'Selling products that lead to harm or death is strictly forbidden.',0,'2024-02-19 07:43:30','2024-02-19 07:43:30'),(8,'Attempting to purchase your own product will result in automatic banning.',0,'2024-02-19 07:43:30','2024-02-19 07:43:30'),(9,'Store products must have clear descriptions and unique characteristics.',0,'2024-02-19 07:43:30','2024-02-19 07:43:30'),(10,'Displaying contact information in listings is not allowed.',0,'2024-02-19 07:43:30','2024-02-19 07:43:30'),(11,'Off-market transactions are prohibited, and violators will face store bans.',0,'2024-02-19 07:43:30','2024-02-19 07:43:30'),(12,'Excessive bad reviews can lead to store escalation, returning escrow funds to various owners.',0,'2024-02-19 07:43:30','2024-02-19 07:43:30'),(13,'Escalated stores will have their products hidden, rendering the store inaccessible.',0,'2024-02-19 07:43:30','2024-02-19 07:43:30'),(14,'Orders auto conclude after 72 hours for \"sent\", \"dispatched\" or \"delivered\" statuses.',0,'2024-02-19 07:43:30','2024-02-19 07:43:30'),(15,'Verified stores with over 4.5 ratings and thousands of sales enjoy early finalization privileges.',0,'2024-02-19 07:43:30','2024-02-19 07:43:30'),(16,'The verification badge is granted to the top 10% of stores with over 6 months of operation and ratings above 4.0, symbolizing excellence.',0,'2024-02-19 07:43:30','2024-02-19 07:43:30'),(17,'Engaging in scams or manipulation may result in store banning based on valid user reports.',0,'2024-02-19 07:43:30','2024-02-19 07:43:30'),(18,'Market spam prevention: Limit your listings to 10 per day.',0,'2024-02-19 07:43:30','2024-02-19 07:43:30'),(19,'Stores with a rating below 2.5 face potential banning.',0,'2024-02-19 07:43:30','2024-02-19 07:43:30'),(20,'New vendors without established reputations must provide a picture of their product with their store name and \"Whales Market\" written on paper.',0,'2024-02-19 07:43:30','2024-02-19 07:43:30'),(21,'Promote love and respect; inactive stores for 2 week will be placed on vacation mode.',0,'2024-02-19 07:43:30','2024-02-19 07:43:30'),(22,'Rules are subject to change; any modifications will be communicated to all stores and users.',0,'2024-02-19 07:43:30','2024-02-19 07:43:30'),(23,'Thank you for reading, and stay safe.',0,'2024-02-19 07:43:30','2024-02-19 07:43:30');
/*!40000 ALTER TABLE `store_rules` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stores` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `store_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `store_description` longtext COLLATE utf8mb4_unicode_ci,
  `store_pgp` text COLLATE utf8mb4_unicode_ci,
  `store_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `width_sales` int NOT NULL DEFAULT '0',
  `disputes_lost` int NOT NULL DEFAULT '0',
  `disputes_won` int NOT NULL DEFAULT '0',
  `products_count` int NOT NULL DEFAULT '0',
  `status` enum('active','vacation','banned','escalated') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `selling` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ship_from` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ship_to` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referral_link` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_updated` date NOT NULL,
  `is_verified` tinyint NOT NULL DEFAULT '0',
  `is_fe_enable` tinyint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stores_user_id_foreign` (`user_id`),
  CONSTRAINT `stores_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `stores` WRITE;
/*!40000 ALTER TABLE `stores` DISABLE KEYS */;
INSERT INTO `stores` VALUES (1,3,'SingleProduct','Welcome to our exclusive SingleProduct Store, where we specialize in offering one exceptional product at a time. Why do we choose this unique approach? Because we firmly believe in the power of singularity. By focusing our efforts on one outstanding item at a time, we ensure that each product receives our undivided attention and dedication. This commitment allows us to deliver the absolute best, ensuring unparalleled quality and satisfaction for our valued customers. Join us in celebrating the essence of uniqueness and discover the excellence that comes with our focused dedication to each individual product.',NULL,'1jbnh1ueDyWmHOpQrr8SUaM7sfR47tjHLNrdL5d5d4SNJOTfMVMqgfw4LUVgmiFnYcrrsCFdTYoRxne9UwKsrtwcgZ5CpwGJxZTtGvSalQajxOhkIwDhA0GG5ZcQXIdy',1,0,0,0,'active','guides,credit cards, accounts','Switzerland','World Wide','1708335355_0cLQwibvnySXt9gfQ50u7zOMtKXJiWEDluYRWene',NULL,'2024-02-19',0,0,'2024-02-19 09:39:08','2024-02-19 22:59:28'),(2,12,'CrystalClean','February 19, 2024:  Welcome to the vendor shop of Crystal Clean.  We specialize in clean products that, with care, pose no fatal threats to your health. Our products are tested to ensure the safety of all products that go out to our customers. \r\n\r\n\r\nATTN TO ALL: PLEASE PROVIDE PGP KEY FOR ANY KIND OF RESPONSE. THIS IS CRITICAL.\r\n\r\nOnline markets, such as Arch, offers adults a chance to get the proper items in order to self-medicate without having to go to the streets and risk their life in order to get the medications they need to maintain their way of life. It also offers a place to shop for pure products, without all of the harmful cuts that continuously contribute to deaths, in the complete safety of their home. \r\n\r\nCrystal Clean offers a friendly experience, great customer service, and top notch confidentiality when it comes to your orders. We vow to never disclose your orders, address, or anything else that may put your security or identity at risk. \r\n\r\nWith all of the experience in internet research and other topics, we have yet to run into anyone that has been disrespectful,  threatening, or violent by any means. We pride ourselves on being a reliable, straight-up, and fair source for users to get their needs.\r\n\r\n\r\n\r\n\r\nREFUND POLICY:\r\n\r\nNO REFUNDS OR RESHIPS ON NON-TRACKED ITEMS AND NO REFUNDS OR RESHIPS TO NEW ZELAND OR AUSTRALIA. WE MAY REIMBURSE AT OUR DISCRETION IF YOU HAVE A GOOD REPUTATION OR ACCOUNT.\r\n\r\nAll orders shipped with tracking are eligible for refund/reship. All orders without tracking are not subject to any refunds/reships due to not having the ability to check the status of your shipment.\r\n\r\n**Please read full listing/ad to understand the correct refund/reship procedure that applies to your order. Orders without tracking are at our discretion depending on the situation, and/or customer history.**\r\n\r\nPLEASE MESSAGE US IF YOU HAVE A PROBLEM WITH YOUR ORDER. IF WE DO NOT REPLY, MAKE SURE TO REACH OUT TO MARKET SUPPORT. IF OUR ACCOUNT GOES ON VACATION, PLEASE BE PATIENT AND KNOW YOUR INFORMATION IS SAFE WITH US. WE WILL ALWAYS COME BACK AND MAKE THINGS RIGHT.',NULL,'U8A1rpD7AUJi4VrTBdiPLpUyp8M73FFbFfC4N5P3306V6f1V4HqhUha2nvLIENNZVHSb4MpDtmEB9G9hlfYeMq1IftIeZfzmiYf5uMfNEnnnKiVEu1NEzI7MHFQsgO46',0,0,0,0,'active','Meth, Weed, LSD, Ecstacy, Xanax, Mushrooms','United States','World Wide','1708360684_QnyaxDsM3ZsYyGHRkNLJEfvuL2rxnqR6kIzAjgKA',NULL,'2024-02-19',0,0,'2024-02-19 16:40:41','2024-02-19 16:40:41'),(3,5,'Octopus','Welcome aboard and greetings from OCtopus :-)\r\nOur tentacles are all over the DN and we\'re sure you\'ll enjoy our services.\r\n\r\nPurchase calmly and in peace: all orders are ESCROW for your own serenity.\r\nWe have 100% success rate. with Octopus - you can be sure it will be delivered!\r\n\r\nWe provide the cheapest prices on the DN for OC\'s, 100% GUARANTEED.\r\nWe\'re the ONLY vendors on DN to have access to rare and lucrative 120mg.\r\nWe appreciate all your business and use top stealth methods and security.\r\n\r\nMAX deadlines for delivery (normally comes before specified) -\r\nEU-7d\r\nWW-14d\r\nWe don\'t give tracker. we check and provide statuses if you ask.\r\n\r\nShipments go out monday to friday. before 09:00 CET and it ships SAME DAY.\r\nOrdering anything AFTER the time 09:00 CET will be shipped the following day!\r\n(NOTE: incoming orders after the cutoff on fridays will be shipped out MONDAY).\r\n\r\nPlease allow reaching deadlines before contacting us asking questions.\r\nALWAYS USE PGP. we want you to stay safe and secure at all times!\r\nWe will NOT deal outside of market. don\'t even try asking that.\r\nWe will destroy your credentials and address right after printing the label.\r\n\r\nFeel free to ask us any question. we are here for you to accomodate your needs.\r\nPlease be fair and leave 5* feedbacks. if you have a complain - talk to us before.\r\nWe believe client is number 1 and we will fix anything to reach your expectations.\r\n\r\nWhen placing an order, please use this address format:\r\n\r\nFirst name Last name\r\nHouse number and Street name\r\nZip code City/Town\r\nCountry\r\n\r\n(Don\'t worry: if the format isn\'t the right one for destination, we will correct it).\r\n\r\nPlease note: BULK orders are welcome. we have unlimited quantities of 80\'s and 120\'s.\r\nContact us for special pricing/details. bulk is considered beyond 20 boxes (560+ pills).\r\n\r\n-----BEGIN PGP SIGNED MESSAGE-----\r\nHash: SHA512\r\n\r\nOctopus is rolling out the loyalty program and gives gifts to our subscribers! :-)\r\nSubscribe now to our Dread channel for incredible promos and up-to-date info...\r\ng66ol3eb5ujdckzqqfmjsbpdjufmjd5nsgdipvxmsh7rckzlhywlzlqd.onion/d/Octopus\r\n\r\n-----BEGIN PGP SIGNATURE-----\r\nVersion: GnuPG v1\r\n\r\niQIcBAEBCgAGBQJlRqGFAAoJEKSPXZz6UDmTbgIP/2MILoeTZ2yn1xCFqUxZWPCB\r\n5rgonD/kax2n7PCi6ZZaTFwmRIanJ/OyGeCeWtQ95OMUXWeJt+4asUodO59Lkpag\r\nJ9lWbZtbfzhDUEX4+FZ0tOgSCxHOE4k5immQ/dHrTuGZldpQcXYBT0ezAmOGPjKo\r\nfKGT9BjdbgIWaOTb/NLPJesYKp9Bu/Jj0ttXcnpu4ht/Mja0ciLHSRg/hlyFn5p1\r\nEJNqT3dJUuO8/R+PkacuBn3sskFld00qpAMb4USuk85B9BxBFcbyeLI089H4VVTW\r\nqHZn8TBYxCUfgU7CwKnGtnWpVg/crxIhlo6BHk4jcp0ldWWmjIGUTOXGu/4K2eP4\r\nb2iOVZhGxBJff4nLGuzaGcmJsZe5xpcm0q3ZkruOTJMTvLNnz5tmoTuNgHvSroOb\r\nBLU1DSUllK0O/xmFTbMPYImugarsonqIO62HOkcDgrYqGa9rNQ8Zh+ZzNo4CL2al\r\nHpGOvtTCk1Dp2ulqn1CNo/L6pPwVnhKp5PpYKsKhB5+PRb5b+9I8Zp4gRM4loSDl\r\nDRueT9BpuGnMTp+m8YouV7gqKsTrhA3UGBhAYne5z12/iiYaXv5TOMmZHCPNfWXd\r\nXOp5X/dmhQwDIgJUieCTReoRZ/3TVEJ8FZlem5hFxiQh23gYLL7rpbovYAxc1Dg3\r\nQbBASLN8Hh8KPp1CwpGn\r\n=NdxG\r\n-----END PGP SIGNATURE-----',NULL,'ANrHFvW2k9ZgkniiCkC6dWM946dfDEXEVo033NRtF3J3drE1NQnngZTbiQBiDpwZ8ZzYYombYjLJKMgC9V5OWlqaGa9ZqWf9jd5A5PT9LhEgeyG8BEK6k82cQGJSWwMd',0,0,0,0,'active','Oxy, Ritalin','France','World Wide','1708372926_z3ZAuerSrCdOMvbC4gpU23VdNWKs7kE0xFjnBdU6',NULL,'2024-02-19',0,0,'2024-02-19 20:50:16','2024-02-19 20:50:16'),(4,10,'CharacterZero','Hi and thanks for visiting my store! I have lots of cannabis products for sale for a reasonable price. All edibles are made fresh to order and I do my best to be accurate in their strength. If you are looking for a different potency, feel free to ask if I can make it. All addresses must be sent in PGP format, otherwise your order will be cancelled.',NULL,'Fhjo29GHC6Fx0wiLA8EA40nb92LohhUX0mgKMHMMNTg92Iks7W1gm1MixWQCO8tgI4oi4xabiDDmimKLwuGYo9K1AOCEorsx7JSJIc8K6DKbfWzjtHV6OL7sskJDJzqk',0,0,0,0,'active','Cannabis,Edibles,Tincture,Concentrates','United States','United States','1708383721_fstjBiod6w3RZez9WQG7CxTwZN02YangwuzIYPu6',NULL,'2024-02-19',0,0,'2024-02-19 23:26:06','2024-02-19 23:26:06');
/*!40000 ALTER TABLE `stores` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `supports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supports` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `conversation_id` bigint unsigned NOT NULL,
  `status` enum('pending','open','closed','escalated','de-escalated') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `staff_id` bigint unsigned DEFAULT NULL,
  `priority` enum('low','medium','high') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'medium',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `supports_user_id_foreign` (`user_id`),
  KEY `supports_conversation_id_foreign` (`conversation_id`),
  KEY `supports_staff_id_foreign` (`staff_id`),
  CONSTRAINT `supports_conversation_id_foreign` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `supports_staff_id_foreign` FOREIGN KEY (`staff_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `supports_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `supports` WRITE;
/*!40000 ALTER TABLE `supports` DISABLE KEYS */;
INSERT INTO `supports` VALUES (1,5,1,'closed',2,'medium','2024-02-19 12:32:25','2024-02-19 16:41:46'),(2,12,2,'closed',2,'medium','2024-02-19 15:18:24','2024-02-19 16:38:56'),(3,12,3,'open',2,'medium','2024-02-19 20:27:57','2024-02-19 20:51:22'),(4,10,4,'closed',2,'medium','2024-02-19 21:34:27','2024-02-19 22:56:28'),(5,20,5,'open',2,'medium','2024-02-19 21:50:04','2024-02-19 21:55:07'),(6,24,6,'open',2,'medium','2024-02-19 23:57:18','2024-02-19 23:59:00'),(7,29,7,'open',2,'medium','2024-02-22 12:01:45','2024-02-22 15:15:22'),(8,12,8,'open',2,'medium','2024-02-22 14:21:48','2024-02-22 15:15:14'),(9,3,10,'open',2,'medium','2024-02-22 15:21:43','2024-02-22 18:37:13');
/*!40000 ALTER TABLE `supports` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `unauthorizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unauthorizes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `unauthorizes_user_id_foreign` (`user_id`),
  CONSTRAINT `unauthorizes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `unauthorizes` WRITE;
/*!40000 ALTER TABLE `unauthorizes` DISABLE KEYS */;
/*!40000 ALTER TABLE `unauthorizes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_promos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_promos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `promocode_id` bigint unsigned NOT NULL,
  `cart_id` int unsigned NOT NULL,
  `discount` int unsigned NOT NULL,
  `cart_state` enum('not_checked_out','checked_out') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'not_checked_out',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_promos_user_id_foreign` (`user_id`),
  KEY `user_promos_promocode_id_foreign` (`promocode_id`),
  CONSTRAINT `user_promos_promocode_id_foreign` FOREIGN KEY (`promocode_id`) REFERENCES `promocodes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_promos_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_promos` WRITE;
/*!40000 ALTER TABLE `user_promos` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_promos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `public_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `private_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pin_code` int NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `store_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `spent` double(16,2) NOT NULL DEFAULT '0.00',
  `login_passphrase` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `disputes_lost` int NOT NULL DEFAULT '0',
  `disputes_won` int NOT NULL DEFAULT '0',
  `twofa_enable` enum('yes','no') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no',
  `role` enum('user','store','junior','senior','admin') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `status` enum('active','banned','vacation') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `store_status` enum('active','in_active','pending','suspended','banned') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'in_active',
  `pgp_key` longtext COLLATE utf8mb4_unicode_ci,
  `show_key` tinyint(1) NOT NULL DEFAULT '0',
  `private_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_orders` int NOT NULL DEFAULT '0',
  `theme` enum('white','dark') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'white',
  `referral_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_seen` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `avater` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'onlygodknows','escrow',566858,'$2y$12$B1ftAh25Oyja//kAsNkizueMjufN1uI4huuW.7cjlTxv2cW0GbP16','xWDjnK6Kt9i8wOtYyt0uXhQplCW4lPzebLOp6CtMdagJCdMZVb6bSaxOfwDBx4tx',0.00,'VWPQa',0,0,'yes','senior','active','in_active',NULL,0,NULL,0,'dark',NULL,'2024-02-19 07:43:41',NULL,'2024-02-19 07:43:41','2024-02-19 07:43:41'),(2,'OSINT','iamtheadmin',362018,'$2y$12$dBmf2ekNqxKdf4pW77LDF.dORpdKLGay41uG2SvvmIrpn.c1Xtkcy','eVJWdaQ3cXQR2yDN6FIDxVUmW6s6cAz1iRctbrMI1HCzZsANRhoOoS0vHzquS9OXTQFi11oVgSKIDGAFBVLCbrEUjlwbGQRmZCqq7rLYWuB6JQ9tFbKKtp30VWfr95y6',0.00,'halal',0,0,'yes','admin','active','in_active','-----BEGIN PGP PUBLIC KEY BLOCK-----\r\n\r\n\r\nmQINBGVDBT8BEADHIWZjDw5osYUhxqRxO9kC4ZyKMHwcx5wBZDS7A2oUk5LWm0SP\r\noXjI3b0NIxa2QY+1EVxCro5m3PPil7zW7XlGM8S3KoQnH4NV1kQ9PvAdbpq6b87p\r\nbHPTjLEJ1u0Kz5DzNGBo8hNMwJLvocr7Nj87sTmSvHX3xqhoKSsu+Jo+2NwbFVgU\r\nxZluEYLJ+z+0/jo3i7FtGynXJpTReA2RLZO9vzGQ7OlyhS/WqgOmXl47rL25c2Y6\r\nZKbl5cm0SW0LG4KvTHaYZVODpf34D2Oe0QCiD12meNYJbZgelMBP/GMHsKem3sS1\r\nsfKamlV4uRscBO+/pDvA2KpjuZpUDs4ZRUa8dPMEWc2i34QgaLMZtk6jSdmWUxtM\r\neGBfHMR7fCUaLvcwSc8Bzeg3MucKmrPBYtNmYBa8jKIf/Og7LO/nj1Wl5IXPMCBx\r\nwcjn0tf7UXdkMSZKEBigeSlQ3fsGS73lkmQPqjwoPkfzQg5dM5u4b9Sm3rRfHuJA\r\nMxxx0su+PYMXHHHKR1HwhqrTWybRso7e20CTHfrDX1sGFI7/FGbNM0Pf2gC8d4EN\r\nzLe7eFv8j9iakULBl96aJrxrPAXOOVQq+g8OukLM/6Fn7TRCxQqM39EKrLffgFho\r\n50djtpFany90lhSbolqVOrOi2lk6Ozl5s1qwrL0l+P/HWEsKCx1m/5UA/wARAQAB\r\ntAVPc2ludIkCUQQTAQgAOxYhBEG3DeCvseCayb2nHGBcDiQzhcgvBQJlQwU/Ahsj\r\nBQsJCAcCAiICBhUKCQgLAgQWAgMBAh4HAheAAAoJEGBcDiQzhcgvEacP/Rg9uvHk\r\nzGnJJNy/KQRcnPEFh/pv2STn95UhjM6cRDo2yPwo0NZ91L0+wPBUiGDaJcfFW90q\r\nEfBi0fLUYAOoUFyuAtw8xfCIvqTFgEfNpRpSIz6NWcESWulTBYs02uCRHZ7FuBFA\r\nLl8tWrRoApNKpjiYmdDJFjBZcrkJHnLPQAhq6Sbd/4bK6UP5X7QljZPwsuKN9rem\r\n/PuxqER7ru5GEiuxny0MWPRm31XjxwKPuBxFN6N2mQhQnWwF01meUcjEjaLTSZSw\r\nYfzlDxLARY/8iNkaYF+z+YJ8UjF/mSsNZfj6QzvfExt9ZFM9D/HFxXjo77mqnLGu\r\npvIT6tlAoAF2C+klb8Zr0mMow465b2E+au4p7sgInDz1lTuG6eQear0w9TYNbJg/\r\nul5XLGN9fKGqxuDsUhd2JE5hqGx+sTguN3rPQMegg6c+yQVAGYZ0hMAdbaRsFF2T\r\nG1CAGPOYZWR66BTCkjhOV9zDGdD20P0eyT6Xsi9aSiqhIlCUBPRs5TcG9weJybhg\r\n/fraJVreDlbylciHi90+f/QJ/4KmrPc/d9iBtUjXM+mGucd9OogtmgO6MR7iXpuK\r\nGit39CJ6hQ+m6qLj3vJZ2rBkrrwSXfF9vOAVLIFcLCVkPL49IwOLsIptn/4C26l4\r\nJ9s0qpO+JUoTEBV6W3pz4DF297iW8wyUzSEWuQINBGVDBT8BEACnmm58MH4NXfOQ\r\ncePAB9Yg9A/EBOzzIwESb71yQsuCnu4mBVin1e2eNx6n8rEtV2JPtUIMizlpJqxG\r\nepU5XLFdAWmN1We/Yn0+/0FADOuPPtBUekizCsxuoRQaQSFLpA/7K5CyyPkgKBjV\r\nxASgLb0lTKfvPR9rIV3b4i/E8es/PBkDIPEpkkMLTruqDkEW5280akxXez+0CYyH\r\nQ0RmwZ9X3Iw3nP4X9Cgsx6BlulfqZLoi2lgcT3Xw7Zj0ryiekutWW1i1mVwUwEYC\r\nyFyZKKj0CNTNzCik2Ah7LbxZV4IljSMxPdzJQv1vnsfayGSw5zUthZ8JF+YGX/ZI\r\ntQMCyut5k2QV/5umUZPL/+/s2M4CduGt66NDXTEMmU69h0kQTSBjTKft46CYk05H\r\nqjMHfZn8/sGp2rzFCVfZNAOKi370W+m2oTWT99Ok0BZfmVIHmHkwbz4OUoAV2igo\r\nV8tJjIAEdgD4RdlNUr4/8jiSvzudtUbqUGBu09743bJ3PkpYW/9MxBN6cRrO7MR7\r\njCIbBgGL5Ufw/yQ6SYPiu0EapqbVcpollMJE0JuwonsoYbay0b1gy0Z3+3zkMueb\r\neuMOsTc6w16NjjzymYJTix4foQNukQ42QJc6XaUQ8UJjIdB6i5UCVtUKRocbD+84\r\naYaWrOb54KmxSlF+5GUiBeQMeGk37wARAQABiQI2BBgBCAAgFiEEQbcN4K+x4JrJ\r\nvaccYFwOJDOFyC8FAmVDBT8CGwwACgkQYFwOJDOFyC851hAAvw2S+zDoX+Iih+fL\r\nIbDJ8n31UQHj0d1Y3MCvtv20Y82gHJTIM1KtIm7PqXqnQvWIzMoBFB7VE5vMey+8\r\nNraztavSVMYk8kDoA+DzQ9GMP+EjlPUAlVU8ZIzZbNRT5VPzHlb4Ds8TzFmZIktv\r\n9srmv55W6cuj3F5FK05qbmLUL8KOa7meZFhnFCMb5D9ifMrvHc8Sh4N3nLNM3Uq6\r\ntfCayJBYnA7ZLivY9Y6D1tja0iD1xu+NckealehN8TNFhl1ncIt0WlIR+OAoJlEb\r\nKCXKdgADsQMoiiboNloShAQQ9kwQoqnjyxKTxD4wVVSH0iZj2vKT86Be5OqFoegn\r\nAZS2xelV/j71ll82OOe4lomjYHJzmuLkz08GU/6WfHxx99ZFO+ry5RymVF3aeNN4\r\n9tPFMCZWRL3RP4ZnTCDPQ6LBJlFAuXpyV8x50oVFiIIsFrtVF6D8tWr0K8Q5+wAx\r\nw2PnEx/oZ7tYFEOT5IVvBiqL9P0ikyHO/ANfBPkUkyCuckPkJ6N8/xtcb3PSnAXK\r\nJ6fit9BZ0ogYZltZGEXlEJDK2qJELn6/3SUYW3lwkVkhzswO6bN94/IpVbXBmV9t\r\nWs6hfNZXzEbfh1C8BuBQMgwV4T/3RZGsRIAMXXP23oJFNIdOQ5YBpFR1sOF5azHv\r\n+U/UdxiaGjEndwYBvhJy41D5wVg=\r\n=5F+K\r\n-----END PGP PUBLIC KEY BLOCK-----',0,NULL,0,'dark','OSINT','2024-02-22 19:00:29','1708335622_mRvylc9KKlAxKH2TddFYODAH263W5VV0ptViIiOK','2024-02-19 08:14:16','2024-02-22 19:00:29'),(3,'SingleProduct','singleproduct',123456,'$2y$12$uG64Z4vXVbCh51WY4P7gwe.1LiMjTluUC05s5N7HU39bhBJrWcxZO','1jbnh1ueDyWmHOpQrr8SUaM7sfR47tjHLNrdL5d5d4SNJOTfMVMqgfw4LUVgmiFnYcrrsCFdTYoRxne9UwKsrtwcgZ5CpwGJxZTtGvSalQajxOhkIwDhA0GG5ZcQXIdy',0.00,'single',0,0,'yes','store','active','active','-----BEGIN PGP PUBLIC KEY BLOCK-----\r\n\r\n\r\nmQGNBGXQWpABDACzE/HTPs86CKbe3aq8VOCPaNH090zWkxBIV1cRB7Nq07FcRrto\r\n/NkZ6ADHbtmSxEpdXWDZjbXk3usSX61DrttdXojzYDRmtFGEJkvRegm67SWaZnn9\r\nMv+1TdEd5TwotWA9xBxvxcvdWw3xcwD3lgT1Tp3kFD9YpRhg7IHLtZRSK3OxnzE8\r\nciJ/89GVwXvdgq/zszVN9rUC83NDSdNw1hZwuT9pKF0Ckih1ijWzLm8XSTOG7z+7\r\nCaxHIY/Kyhka0h44BL7fL0iUwxaVkwgcfORNjZW58qhyLfrPEehPPU2AZmeZLlMY\r\nu35fSojJ5vhumk6FaRNod18/5qKHqb73Tlzkw5btk30rwuiJ65HGNowqrCsHdnCI\r\nk9nSppl1+SKrERVF5WHj4BHFsUf27j93UIYXsv3phqSsCOsEA/uE25chuOSOGzym\r\n6hW0TQzDcQE1kNarG/1Vr+emGfdzYs8qu1oqV6pfx3pQexRuRHNweOU5BiIrnv/S\r\nq03z/VcqVP66nlkAEQEAAbQNU2luZ2xlUHJvZHVjdIkB0QQTAQgAOxYhBMEbagV2\r\nyY2DcnklhhOS1Yi+TA67BQJl0FqQAhsDBQsJCAcCAiICBhUKCQgLAgQWAgMBAh4H\r\nAheAAAoJEBOS1Yi+TA67mzEL/2ZmLveGsIIajP6kRo+82x88BTQz9lTPWHtQqfuX\r\nmqgqCqSRCl/dfgcDVFiID9pBdqO7UY4kE7EMDLPIV4Zokc+hNv3Lfewb5nv8WCkS\r\n2sOuRx0W6HCgk4HaXjukIoTRJNsZSdw/hjRHkFjAMlqxXs0tedY8rzqPhPHs5ImE\r\n6xzLVCSwVzboatflQg0b3SksfvWtr2rPKZzwDL0+ZbIswjkEa6+D4kLNuBNwqcNY\r\nWEtIiMeEwAIIIzXyVZerZdmnfIQasnvGx60yFaMsmyPZEQVSQjUM6qKLweBy4oVB\r\nHNTOOTO+EDetHd1xAj5hr5tV21iLRx3lJYwPq5nZv407FOsTDYMfgIi6PZtaUqyX\r\ny2AWdaIA9Q07FNPa8oVTI+JyU746RmMztchxbNWdgl+ZXBFfnkZOZQA02XuOW4Tr\r\nGNjjClWz4yhRKhu4Oq17JTVXKXyyENfiVj8mB7vZ5sJ/NWK09jZFtX45AL9raZsn\r\nWjMWFWOMx6nY0Pqmz/e2ya85vbkBjQRl0FqQAQwAllfOea3Ig8AFYDmEu1oRFkBl\r\nbafEdGU8A9R74aWEMciG4woF35EXLTbqixb1jytkm95iywzHj9SBMLzT8lsIf13T\r\nh6eEiahGmIEX75UvBTTnVhr0cIVSaFuLJhqtsccWiSBjt/1ONG0rCuR3Sj1Fcugi\r\nYX0mI9o5l9g9WXYrhJTVgaeU+cupFvApMxRqnfXaJWGsDGwq9p6d0Ra50bdXzzqf\r\n84zR2jIEOWeCnBnpIOXHxYf1/8UNFmbuEa1EwwblBp7PPYGIZiy95rT9QQyrdY+E\r\nZC6MiXQ/taXXaqLXgtFp1K2ix+QxRTHgDpHsozPlrj51uCGHITTZMgtjGmRqD7oi\r\nOs+rb35lVQCXhyIAEMrjcqXIXKXCycPziBf7FJavgucigXUguDT7Jor/mijLHi63\r\nHpLDuBrIdGUG+YRpwJRqadpm1V2OJnW/RQY1WPo0LnfuVByMI3yWSliFFrs9zhrf\r\nOyAomRhuIX9TUjlBV4gHsjmKLXG+4Ip/cjctsSyhABEBAAGJAbYEGAEIACAWIQTB\r\nG2oFdsmNg3J5JYYTktWIvkwOuwUCZdBakAIbDAAKCRATktWIvkwOu7BSC/97xjyb\r\nylDHzJZdLX16Nt+iAKBPdTCg/pNoOnu1Cmid5f5WVWX27z4tqNMWSbK/HAVp7ZLD\r\nntf16UY0IJNmlBIzPLyDnytiRgVkWb3W8rxckHhVL5fYHhbmmBiq9rUHmJh/cOpp\r\nXRuTRVybqOM1RfZb/rGA3wbu88kAq6tEQDA9HzB8weIyQDmjIHvihXErRuQ7/I2X\r\na+K0dBkOQdJc0vYFwuW+wosXUSNsgjouW37ttIfboJhwZzG6kJNq3mI7SmSUcJRW\r\nlkKjA+WVvLv0zhZOQumS5qQWVqN9JHC6NCG1fcZnAiWi+r+e02WY2efRi3VJSElh\r\noccRMQxOR10YgKn9dWzxsaL57QEaY0G5kCO4QE7AH1CCrcFpdJhVAeaIJj1GcKk8\r\nL64hghfRGyZncV1Elk1GATGzAjYO+PqFiPpf2MR6pJ4VA1RyIAyVZcNADqJuzg6Y\r\nYlhvzCWcVbbxqVW/buhKuHIqrOBfA7tEssJcS1fU7iVtrP/m3eMhbXxgar0=\r\n=WHY5\r\n-----END PGP PUBLIC KEY BLOCK-----',0,NULL,0,'white','SingleProduct','2024-02-22 15:39:19',NULL,'2024-02-19 09:19:09','2024-02-22 15:39:19'),(4,'marketest','markettest',123456,'$2y$12$X5MQP4ybiZ2QPVLxZ6v5z../wpoelD6cBBwY/WKr59EaHWF2.OuVG','0Em8Cb1Y1bFqgrYhx67nWoKR9zIA8T6C7fcDHnp7ksf9KdwTsNhKgWRWW4mab7JzgaIWX2OBU0fIUfkhFLDdjyAv8noF8zUYEpvMTWOCSXhD03sD0E7ecrwCEzLCgMpA',0.00,'market',0,0,'no','user','active','in_active',NULL,0,NULL,0,'white','marketest','2024-02-19 11:23:53',NULL,'2024-02-19 11:23:53','2024-02-19 11:23:53'),(5,'Octopus','Octopus',666666,'$2y$12$xzrl9U.7QEPn7UR8VTMZgOAaNJWU7QzphyXP77Rkn2XJ0TVlU3wZ2','ANrHFvW2k9ZgkniiCkC6dWM946dfDEXEVo033NRtF3J3drE1NQnngZTbiQBiDpwZ8ZzYYombYjLJKMgC9V5OWlqaGa9ZqWf9jd5A5PT9LhEgeyG8BEK6k82cQGJSWwMd',0.00,'Octopus',0,0,'yes','store','active','active','-----BEGIN PGP PUBLIC KEY BLOCK-----\r\nVersion: GnuPG v1\r\n\r\nmQINBGUTAbsBEAC+gfSzJrS2ztsigPyFbwEAEWrhFoEZOtYenYBPQV56V3Hixyz/\r\nZJNpI9EgOJj1mPZj+ktU59W1m54IebSqUHrOWT/HNm3sCk6wVdwsttSvc6hU8CIn\r\nkLVPmKj9tKKSWVjNOMnwE82HCHt3ybkg5Mr8FYKrHr7qQkWx+hK10iAvbha9rrvt\r\nxy4czkTsd54Z2BPylo7sGSdoFpedEIgy6/iIRCrKrx64dLUg1sI0Cf3OPDOk44uf\r\nKkKTrVU6+5ybq3PTIZAgU9pQ/1RgsIloH+IloQ7mUUUJXCX5mMSIhIDtxJVcu7p/\r\n4K6NLCEjvtEEEjOg2vSJESengifhFOEe2K3CjblxWTt+n6H4gjdgZv0Y43F4bIy5\r\n7RuaU01GWZk/as9knoco5/DDYoMRwQZaG2QuDzB6SoQKaIB84bEXpf5vyrz5MxCA\r\nmj+6yGye0fVCJTW6wgCiVsXVr970I2i4xFNPfKdzTZHP8Ouw/3RdpzrjJo3tVT0O\r\nmy6h8QsVmcGkNdgFGOyfj+HoENqo3cJh0vWZSadmTNjSSl6VLgtdVset+x6IjRpp\r\nCFZeNLOWpkUgNpDBLp1E+g6+b/txw3eIFB/zuSxFvLinzegRhtuutZPTrUf+Xx9N\r\nx5KVszQgRzlY7GYTLHm9mceQ14v1qjhmxgwX6LlJr8boOAdlYOnpPsngvwARAQAB\r\ntAdPY3RvcHVziQI2BBMBCgAgBQJlEwG7AhsDBQsJCAcDBRUKCQgLBBYCAQACHgEC\r\nF4AACgkQpI9dnPpQOZM1Lw//fsvWAbOF+PCDOnYPV4iNtxN+yntxfipssfljKABH\r\n4YdRMBKaa6+2eLqu67b/ukZyZyX5TY6S5JyW+w2ONqInlXFow0rqhr/2X86k1X0H\r\n7ZaQjyn9oCqeDEb8iwNqyxFXu444C/uR8xHcCcloxBvQqYcSmI7G8Do1gdn+MoG8\r\nHIAuIKGs7iZCtQ2TzDSgRWaN83i8cinGcmuHMiz9Ha7aBwl8RB6r/F3eNAkRes+E\r\nfBRwpBFnVf8jh/ECapz5sTUESRmUtQkbHO1Nm5+A62Y8i1l8BhrEFwPYcf9DqOnl\r\nOMBtb1MDVcZOJhDOSmT2bWdwlto8mCDYYflQEUgW9cgTF7rRynozLe/UHad676VX\r\nAzbcfWX/DAOjRlt2Rh4VEagEkAD8ha1OAQ0xI6oyNN7pyBY7TTQKpQdZ5MMNL7BY\r\nlTHIRiUPRvVTNvqRKYns5GswfCmBgMF5e9KBXBslad3OnJ77TGGBAkjkf/eSpg75\r\nsNWW8fquzbmH7aDjGrkcusauvpzosMSgUd5safk2ZDLe2h0DmKeti215vcdfHPPG\r\nSoUxEK2DUULmK/rpCttPHkf9eOptoOxgXuQ9/Sz57ZLOxnO6HVLaGQFIu+uKPliW\r\nZ1rL0iYFjE85MPGb1IR/cgVGbc3jv+WbRRPp9dv2w+mX936fCzEYeqDbcyJT/EzV\r\n9HO5Ag0EZRMBuwEQALwE+d5eRAtpcPP51+u1w28AuBHiRiOMoDSRzr45E8M631tu\r\nFLGRBMW8VM3Y87O9217YqKu08YS4RzX7A3mtgXvmZ7onk0KLFTH5CZjAxxDqoa75\r\n3+vBnmMml7WdJUbjGiejVHXTbqx3DgXtcJEyyYLX/wN/i8VheNzofLu4c4xqxKWB\r\n8wwwAPpZxZk6eueN97HOYVSP17wE0WGvxr9evzQIMAowTQdh+JDwhoEDHsF8oI80\r\neM4mC3hK3SuVz1bHWqPBd64UaZD3L6AeEGeEtESv8gaqcyXnCXuJOFecgwES5h3J\r\nxCfoUe8frw3LUz/QE3SNy6r0UdrNjBxNEP9h/Nj2Y2SnGQJp0nmvU5tqaITZyxT0\r\nw5rGEZjdSIikHDH7tpl2t1Gsm4dYXCojOjDbyMzB4HtAwFx/yVksq2DabaXxLc2R\r\nvg78dKw7nPq9/agJUyaO2qH5QZkRHJ/8OvDHGBUBUraTYpxFEt8UiUaPJj7QOp4w\r\ncro12dpYOcbQHtF0BcoNApYyreFaltMfZmA2bTlLWP6mw1vUBuGnWpQqI4kFrnV1\r\nr/BjkKpCUyK3xkfcQ+xLBGR/pIjw3I5OFkgWkmb5wDgU6wMxy8z8RL8Tyw7oMbrY\r\np2gEEksJI6DnwJmWeGo/wKkESs5IxK6BWRT8Lvwh52JEsxvevAu4pQ0UuKw3ABEB\r\nAAGJAh8EGAEKAAkFAmUTAbsCGwwACgkQpI9dnPpQOZM9gQ/+OmqYmlf8TXO1UNIa\r\nVNdrF7+GE43mLwGYvudj60J633S2Cgj9m/OlMKsnsb4CNkVFJDvXCTWywLVN72nw\r\nZC98km0njeKLTsczKc37giX00+vHNrk4r5FOa/8P3N+0wVx7Ll1MBAOD/p5ttNpB\r\n+YYzxurnlSO5HzWAHNX0060VhBLzXyss5/SNENkoQFcOOEyxMn0VmQdoA080KP1m\r\nBwM5CPf7RR6OE1ujeXA/kqbVRxwJro6JBD81J0gN4RS3oBaq/8+ZhCrHYYxKcGfz\r\nKKvhUT8kd6gryrVBdKg9fny+e+/epInpBbKl3paTMOHBQx9RgaKMu5e7PRu40SHb\r\nrSP0s2n5EvOHsSkFujDhDImwNj4mr+/Y1UfI82GDIBx0nI1eTMY3DNxRbRj4EI5L\r\nrp6c7rXGLzuUameBYDF3Ho2Ehn643OJMk+/Mr5Ft2Y1Dcjp3/L84eSgRaEfwjkrp\r\nTnNGjZYoS46+ks1t3Eyz954McdKWXhzxrkeJNuiBB1xEQQJynHGOTnShomO/qRW1\r\nB9rUSQLs98uVyL8t6Fh/u2w1OaNyfW5+mY2v919ckFk0YbbUEY+zxGZPhfP8i/SW\r\nZxgc9V9o9MCiA8qqBRTDMPVWDAiyaNzXVVXhg95rNZ8ReRe83VnkbakvKgnm/oVx\r\nIJhq5a1c3DNhblokEkKpVyhd/YQ=\r\n=PqM8\r\n-----END PGP PUBLIC KEY BLOCK-----',0,NULL,0,'dark','Octopus','2024-02-20 16:19:56',NULL,'2024-02-19 12:25:25','2024-02-20 16:19:56'),(6,'Cannabisdoctor','Cannabisdoctor',542325,'$2y$12$QB1E6Z3B5BUe5yWLkBXe4OHF2uXxlbpzWZya30/.6qCfXGuehURtK','azQRpvwfH2snTwpylOmkoL7FaEO2k39xqVqxircRdFki3WzyhY8ySWrEKz9cowtwpjxS0pu8PJIwVsjjY8UxtNeTucq5Biw8GHY9sM4uXXxrjgz8EJ9T3rGp9q9c1KuD',0.00,'Cannabisdoctor',0,0,'no','user','active','in_active',NULL,0,NULL,0,'white','Cannabisdoctor','2024-02-19 13:34:32',NULL,'2024-02-19 13:28:07','2024-02-19 13:34:32'),(7,'banger','Bangerton',137913,'$2y$12$lfoRFPQzCuy1tpudPx.sZ.TwXopF7nkR6D8HmmbMJHztLboqnJiIq','Zm3GnrufpY8TXMndOaxLZnYuHdFMGL6nnNiV2fW74rCM8FiZZGBvxbjp7iiYU61NmV2m32GECSfxsQ2pg0EnQGAgraG4ug2tm27zHgCiNkErYLt3krjNzl83TUF7219r',0.00,'fuck off',0,0,'no','user','active','in_active',NULL,0,NULL,0,'white','banger','2024-02-19 13:45:23',NULL,'2024-02-19 13:40:22','2024-02-19 13:45:23'),(8,'qsd','qsd211',145365,'$2y$12$o05ixJLwvoAI6RuFQtltNuSLXn/gHZP58nMEIURQd3vGzgi45lTYS','w7ElrWpXxY0y4aLOgQhEovOa61DgzNwwzKN7lGCIbft007Ex2NxqBi5PHdl8mQbQva0Ooa7uGZaG6iPaTZYo73o9YpJVuaxJ6fxP3eJLAw6vpWjv880pQ6jpmIEWZ5Wt',0.00,'mnbvcxz',0,0,'no','user','active','in_active',NULL,0,NULL,0,'white','qsd','2024-02-19 13:49:01',NULL,'2024-02-19 13:46:49','2024-02-19 13:49:01'),(9,'petepsyche','petepsyche',420720,'$2y$12$dzJMcm5AgkRLQljI4T3vfuYkQZTCB4efqCOx6w13HfOb4KUG.tqcm','ThYd0XYRKH84r6u9lwFnDJWOPzF5DwX4ZaSDLWbL7rd8zhAJPhzCkf3VkFJtCl1T8aZh5IxkKjqvaXrT5jUJAeFLu31FaPP2osiQJOdG8IAKTVCqLQVdzjKO7PbyAGKL',0.00,'petepsyche',0,0,'no','user','active','in_active',NULL,0,NULL,0,'white','petepsyche','2024-02-19 14:04:25',NULL,'2024-02-19 13:48:29','2024-02-19 14:04:25'),(10,'CharacterZero','ZeroCharacter',758219,'$2y$12$FR0Hlc7wKuZA228wml7r3OfAZe9vAvH11.SgjL6AlpfDWU9C6DIDa','Fhjo29GHC6Fx0wiLA8EA40nb92LohhUX0mgKMHMMNTg92Iks7W1gm1MixWQCO8tgI4oi4xabiDDmimKLwuGYo9K1AOCEorsx7JSJIc8K6DKbfWzjtHV6OL7sskJDJzqk',0.00,'You made it',0,0,'yes','store','active','active','-----BEGIN PGP PUBLIC KEY BLOCK-----\r\nVersion: BCPG v1.63\r\n\r\nmQSuBGXTXnoRDACLLekpf+Q5SQBwzduvNDX4CIzrf/LML7tKKrnmVxh+ojSjqhKu\r\n+y4ZU4TJsKpBMtQtiwcJzlF6TgqfF8HUOqNEy8zyWsqVKP8L9Cf9aDVKpzI+gQUT\r\nyDzGfsVaw3Bcu6HHcgD70fA//Wum8cC9o+DXQTlIUpabC3GhHTYiA43XD8AdJCv0\r\nxnOd5ZnNkCRVwsdsgOeftGJxnDGfDsf3VIHZLK8j6iZh3Q9wSqsmdiVMB9EuXLlZ\r\nfInkXoTcZH0XYaQ321jmJNZjlRRL5PJqPNxObCQ0ufiNqiFUMSmPZA4FH5uH4+jh\r\nSclnddjWCwMv6wLShHe7PkM627CnRaFdCxMGbijzZBl5ClJ6e969pzDQgof6cMUQ\r\nURzgTxReNZfnDV2DZ+KWDm+Bb9oJuAz/H/BfbyVu+klznITAWfG1V8MuDqbpXdWw\r\nro6zxsmTa4VYza0KaaqquC6PphdLQSD2yYeFsqzDY+p0d7FG1gKV5UXm8tCFv4Xj\r\nc9eRHyVXHzCiKSMBANvGgIiqTguRWNxda0MHbSEZpkLGl6uNw1h0aLU8YkzpC/wI\r\nVW0ScDzUoo7CPQG59iDlbYw4hFqspEmar7gVcuhrTTNfzijIyXWwUdpULjzmxv2L\r\nSBTOb8wajUFdPpk//Jrau/s4QA4OrdfBr8NXnSgtr7LnsxJGlHLXixQZy/Bi+s4i\r\nf69oXqqiEmIpygDenFGVSV9mi0mg6RM9cm+5/gmw6DL7u9iImbIAz7lndJzBWJf5\r\nyPsKfhU57x8A/0UB5rIwkDGUGnQR6d0a4SL6wg37xN1jt891PxFKz4A2cskU3jRn\r\nyJOpmleyNtwxJpTXS6noN5sHnksY6GWUgjfdukvi5m4fmO0Y0eLRPj/cY3myn0OE\r\nVSHBG8re6fU6uGlta7tyta9jEyLnM3Wn7xK4W7rmP32X5M/+nw5272nDoK8ImlXS\r\ndq+ZTinLyD1eyCphQIYJnQIQNmxqnOJb7Op+BQeyLObIbCAZebFfaQW50Zg0z4/C\r\no+3KL9XnDvV/8mBknsKagE9aW3LSyhYuJ96mtEzSjfuQS/YQppDs1YLjGypX/msL\r\n+gOzPvBws8fKaNDGiBrCypeLvqYaf9ylX/xtGrtdZOUT/A34Kxj4qQKULQsAZRLr\r\naE9INay2yvlVd4bkvtIe2GEuCPnzBJGBDjJcIoiRtG06mCd/IezSxxJaFQwJPv1W\r\nVT12e41rJNmaJ7a9hyrJWATkVR1sbt6YPIXTMNkSbdaIPh1c427etiX4HW7JH85g\r\n1ZPlpbEjEO5bscXvLiCxkm5yCXhuxUOySoJBeGbOSs6Uf6SgV9+h3DgkiWHPlhv0\r\ny9xrMFoVpmJ6GWFcgpAKmmJLjg4+nTS58rkcLrVh1TIpD/AAsyi7ognB+zDlHqSu\r\nC5l0YSg/z1xHsibZJOdpdSaMx/2BA/Zta1RdhJmpKs8OPXP5Ca+05gvFlN7rm1vZ\r\n9VpPZnyhB78ukUuCyf3LWF8VWWi1UMaZXJAr8Cg7ERXsN3TlEPzySapy9wqU+HTl\r\nattMj1Nwk/QE3rAF1XUXF1hrY/ONr9mAAwOYojnvLd4TC/EwnH5J9uAN91g2I6g7\r\nNLQeQ2hhcmFjdGVyWmVybyA8bm9uZUBlbWFpbC5jb20+iF4EExEKAAYFAmXTXnoA\r\nCgkQWa63ZbABFJtarAD6A7im5QeJ4kf+ffzTSlyfWhz+n62RD7mQsk5vZqFyawcA\r\n/2tpg+CDUMJDj1fBF9uGqA7P0J1GKMO9/kxg8mL0YEcnuQENBGXTXnoQBAD/////\r\n/////8kP2qIhaMI0xMZii4DcHNEpAk4IimfMdAILvqY7E5siUUoIeY40BN3vlRmz\r\nzTpDGzArCm3yXxQ3T+E1bW1RwkXkhbV2Yl5+xvRMQummN+1rC/9ctvQGt+3uOGv7\r\nWomfpa6fJBF8Sx/mSShmUezmU4H//////////wACAgP/Y0gorydbrccUFciFqGO2\r\nz5Y1LGHVxo2Gt1LW4qCrnSiy+JRPakhKxzJGG85cxRbb8nLWOp+jvvjE9MMae0PC\r\nrsSNGmJj82usyJTpC88bxh+C+DgjCjAQV8CeCdYbmTfCdv0+A+dJcnbzWe9RFHbD\r\nVK+wGemGwbJ8cW2BxHeNQDaIXgQYEQoABgUCZdNeegAKCRBZrrdlsAEUm4ffAQC4\r\nDoF4OWWYx3OTzZcxGXp1BKKRjn/4s3Aw6bskIy0/9AD+Kwg4SdACW/0hEQkaruSx\r\nSk4RfQcYmFQAoS7qxqVd4Q0=\r\n=gX4G\r\n-----END PGP PUBLIC KEY BLOCK-----',1,NULL,0,'dark','CharacterZero','2024-02-22 13:09:39',NULL,'2024-02-19 13:54:02','2024-02-22 13:09:39'),(11,'fsdsbd','ewqwt',123456,'$2y$12$4IDYiPncBW156fG5Z/gJNu0BVrM8MWRSxLI8JjZYBz1a0ILArfIEW','aRkj2Fe2r7RFmv3lRJaE103BCNlCkBrYyPMiZH887OOLAlpzW2QwEzLQSj4AUbpYyZCJ4jpbdTMw6TRi1h0B1Cwv1jhP2UwunFdGkKRSHOu5ilaNtAxM5Dd7ehfXxHXD',0.00,'fsdfsd',0,0,'no','user','active','in_active',NULL,0,NULL,0,'dark','fsdsbd','2024-02-19 14:30:32',NULL,'2024-02-19 14:24:44','2024-02-19 14:30:32'),(12,'CrystalClean','CrystalClean21',420777,'$2y$12$4F28wW2squASiD4.yaVNQOBLk1o5E9XNV0Ps1E/n9Jx8kjGRM6gN2','U8A1rpD7AUJi4VrTBdiPLpUyp8M73FFbFfC4N5P3306V6f1V4HqhUha2nvLIENNZVHSb4MpDtmEB9G9hlfYeMq1IftIeZfzmiYf5uMfNEnnnKiVEu1NEzI7MHFQsgO46',0.00,'Society',0,0,'yes','store','active','active','-----BEGIN PGP PUBLIC KEY BLOCK-----\r\n\r\n\r\nmQGNBGF15rABDACm7WBchBzjwx5Io2GvIU0bDNTbtVBXBcZvnXmc5K774zBWtRJc\r\nAW+zYwPWeHyrNkMn3KsLGVmXxjY7fIGbiIXWYaIE2Npt9XYLFdAIbmdv+23ahVQW\r\nvVUxJWG+R63E1p5WV+zfmI2ztCyg/fIku3sqrfZRv2O2nBvTRWwEqsUqnEcWqCRi\r\nSBsjcI380SWyPevLtiFpnOpolrc01RvOqFE7H66k4wow7s2/HU6yoKEQGdDyMd9s\r\nEnUSkg5NZ4Ee7wmfdgW25PDDT80E54JBo5p5t6DNpj2m+VqsVmTSc88HU+CDJg+p\r\nWeRhSyWdH+pE+vdkMcnbo5PbCf2IqFSq608g7ZZ/j5PP/972HaTNC+mMVtIY9zR2\r\nNy/QA7jaPznUFARwrRKRYkpG35HDkpyMnG3/6o2ZrVmQJ7bqji+bfxLFf5ve80dZ\r\nD+JomDnAMsnYdxnhyEuR+HRjp93s4fbyJzzXLRWBB3rKFPOo8cUZ7UaoT1NgS956\r\n6CMB+eeDdt9g7H0AEQEAAbQtQ3J5c3RhbENsZWFuIDx2dnNjcnlzdGFsY2xlYW5A\r\ncHJvdG9ubWFpbC5jb20+iQHPBBMBCAA5FiEEhHPvNhGRYbvCGk2WQsW/dbG3TjkF\r\nAmF15rEFCQlmAYACGwMFCwkIBwIGFQgJCgsCBRYCAwEAAAoJEELFv3Wxt045ll0L\r\n/jlqVk89Skq8rpYgkCctTSowbKvGIG5Fb3jc3jJjVL/dSXpjOMtFsDAAdkib3loV\r\ntjk/gJujOVkBome9/C6bk+slzuhBzKGpUfO40vDkuRy7Z9KJ+THulX8DjbzjizLQ\r\noyZl1+HSf7SSe30G6h53kG63C0uP5tnrTLdq5uke9MoMnsQUribvpiZIGCEN1S+g\r\nyxFo+K961cIqzn7XqZlb0k1l3SOfhki/lmXwU+q8QkkZoXvt/mEfNWGODkF1cRpQ\r\n0BDHFmMvtYn5gxGGmRKTJT7rcwA8QI3J1C9NaVuOSBKwYGSea7cYhDhzRnzwD5Zj\r\nqlBUkHSS7rsa6RI3whvvD4/YxXa2Gec6nDqQdhBvZRCZcDSM9IljF5IJlGc7oFWf\r\n7LaXsvRv8EuR5gQCSWVDhZg/kdAxAXDzWVSAgjfLIYX6nChyYsMUedyGJdkhKO0m\r\n/eh+c60XsmeR5dmd+QsdEMz1R2dys0hfpfIYNnujyJ2g5BuIu6JUFLE9VJ9K2RMm\r\nurkBjQRhdeayAQwA4I9IxqRIj1b6xFLhs56t3ekqxp2ceZT5OpbkUGfFg4UqpMQl\r\nld8nH1U6jTOiDZVg6hJy+S5z4sij9CX6EY1ZTSPGLTLbsxRlKhlBzcZyPQA9rr9v\r\n8MF0ZPTRMahmEOkmvD65y9IRxQ+rt9MdPTq9narSPzlpf1dmHSmspx9DTVUVR1V8\r\nH35/uc3FlpFdQXb72ztdOg5qgJYVmseLPSlItaDKApCBJoDR6J8kXRnUqJhyCLMp\r\naOmZUp/67/adehkJXiZXJBxRll7PcxqJgXoCPzzcdhU5nY3Z9YEaql2gtyGEZyvb\r\nZmlCBxkNVtNqImtuFjghnVHjNvfzkx7KdNZwKVPfJJUexbg/HkKR1JUQNoVmyq6e\r\ntYyrUr2S6Ohz6ppRDRWPD6kwXpe/FtiIn2a8QqA+u3hmdZvwDSOYSndczp2N4UHG\r\nqzx/n7c4oTaD+I5dWxS2ketkTnB3dMzafvhSHt5G9bfsBOFXNc8qRYbdu+Rg6uu8\r\nb1CyYywYRUJ6Ds4rABEBAAGJAbwEGAEIACYWIQSEc+82EZFhu8IaTZZCxb91sbdO\r\nOQUCYXXmswUJCWYBgAIbDAAKCRBCxb91sbdOOU9xDACblpZDJKFP03DKasw+lJx1\r\noQiBjjm74j7b9Boo/P85fYSxq0LzpCeVHg8TFnNmw7abagIPRSbexfIlXY7VKkxM\r\nK4ebRtXiv2BJoB0SFE+4G21QxOsWegf96W1YfGJI3P15sEzbE0XpF9oLrvlPUxGc\r\n73dV0fC6+Ykz3rXuQYwo1J0+/PaDCkgPSo5iEKkDKRNx5Njmj3UbOCUPf4to7+wr\r\nmQ7OwePK+vLRME8weMlR34D2e0E+Ws+fEe7AhPIqJcS8IIIwYgodVhGvY6pJPkA+\r\nfAGG/05+XviBiU/49ef2IiVuJfVt1kmL8Bg4CHhJc1A82ikaNbRDhV0AKAdR5iru\r\nY63tBZeDNaIMkg5roFRHCmIya0883VVdCyoIhCRuCTeHBBvSzGwYo70MIbDYeiJW\r\nJOyyLXrWb3SpOuKQzs/ux60hVjHD7EQEBPu/YpjxDEZmqTNmfQKaIsfSFcYoVoOQ\r\nslkOGfHyXG1foDK5YqMvF194/VK2ezQy9R3EEXK2l64=\r\n=J1BP\r\n-----END PGP PUBLIC KEY BLOCK-----',1,NULL,0,'white','CrystalClean','2024-02-22 14:48:12',NULL,'2024-02-19 15:02:51','2024-02-22 14:48:12'),(13,'asdsgg43432532','asdsgg43432532',123456,'$2y$12$Fdup5vnukqYQ94L9yVTJrufE/TkECLLxpPMvMTT2y7AONr1Cu1BSW','XmOH6STdpTyXzMwmeeP05SrCm0aBzPhL2WwW4UmVRHZCcIZH5eC8NfUNTgIAToPo6eXA2owvrytlWpQweBJ7ozmo0LER0Yaqc0pKQVhySjD6XcNwqMU6yw5Ynnkuw2NF',0.00,'123456',0,0,'no','user','active','in_active',NULL,0,NULL,0,'white','asdsgg43432532','2024-02-19 15:46:36',NULL,'2024-02-19 15:26:31','2024-02-19 15:46:36'),(14,'RakeyBakey','ihjefMKFoemk3',349011,'$2y$12$LzDMu.dyaNQerGu.7YCaeuOiElUUkG6Tz1i1P6uo9VuR24YYPOTPO','7c0ieCfoL17Nvt23TtRwZWt3aT2yIOKZA76j8GlS7OWLNygO8RBEXlVtsBYaN0DKNLSuPMReVJm2C002iLYsuUvTUCt9iInZFo4ycYGttpRQecsZf5MuEIcPDdL4IYjJ',0.00,'RancidMilkers',0,0,'no','user','active','in_active',NULL,0,NULL,0,'white','RakeyBakey','2024-02-19 17:07:16',NULL,'2024-02-19 16:44:46','2024-02-19 17:07:16'),(16,'testonly','testonly',123456,'$2y$12$f.8ycrCxoNzpORfff6/cCeLjnbs12j.0yYQTlVC2lyit78GeoNeyS','1YnsQc9Y5RucHwoTumq0JbihhIYoW5GTY9N9LdTFDF237kRqsBriohKOfXIB5E6iRLopjRlSYMkN40YIrb74DRHtt74JqYZvqTFMJJuD0GLv3zypyA9kAuW3OgG4XAd3',0.00,'testonly',0,0,'no','user','active','in_active',NULL,0,NULL,0,'white','testonly','2024-02-19 18:57:45',NULL,'2024-02-19 18:53:25','2024-02-19 18:57:45'),(17,'ANON258','PRAN258',122526,'$2y$12$py71qURvKLJnxAJHfFgXfuNty8SHwM4zghLlNCaufIwQr.4qxmG56','2J4VcWwftu4oyyvhtKETfFVD6PILHMxo6LagandsHdyv6ygr8F4r23bBOBk0qpJZhHgp9M4irryir1s63DH6QU7yGT2CqbLV4qgxUPBAu4sjlBqpqotxi1sdT8o2frlG',0.00,'IMTHEANON',0,0,'no','user','active','in_active',NULL,0,NULL,0,'white','ANON258','2024-02-19 20:27:10',NULL,'2024-02-19 20:23:00','2024-02-19 20:27:10'),(18,'AlphaTrip','AlphaTrip666',121989,'$2y$12$JKY/OW.YB8NLcoohEUoDwOG2ZSUjl5y7xDt.FDJuZrz3eLWu7P11W','BR5PrPWDscurpR4H5nzEyKTRyjtRDSsCeujjr2TnfB2tbpPdxKQhvH6uZfqgq8x4YkZayfXgolhOgBt2PYcmbyaOzTHOWZSiZuo3Kou7pxzUsSBNjOfyPKGK9be6Mn5U',0.00,'Penis',0,0,'yes','user','active','in_active','-----BEGIN PGP PUBLIC KEY BLOCK-----\r\nComment: User-ID:	AlphaTrip\r\nComment: Created:	2/19/24 8:39 PM\r\nComment: Expires:	4/20/00 12:00 PM\r\nComment: Type:	4,096-bit RSA (secret key available)\r\nComment: Usage:	Signing, Encryption, Certifying User-IDs\r\nComment: Fingerprint:	A800FD1E3562FF92F7BEFBC31BD18909A7F35FE1\r\n\r\nmQINBGXTvJoBEACshKQFcOP0bI3YgfttkVNHPnB8A/rrmx+NxiHIJIPS2vU+p00r\r\njeJJpMznzICdSRORlyRInvMgZxq9VDr3ktCjZow0WhOrDZ+m+/k/QyKggttPkpVO\r\nfnsezdApD1HakmHtfDkubG1RC3DeEN8fmH9w8BiEyBtjRgefPS/4BDgfGsdOfUa0\r\nBRj3HQJo+eK8eh64g+j+ZQ4bAl2+NdqFvc6oD5poE7WX1IftvZmZMSNp+yk+eP25\r\nqdaZJmOPQnooFlwEIfPCmjH29L4hAEqbXwCPZGEdESoINlUV3UeXyiW61MNmHDRw\r\n92+GoZMdPmFjq+3ZCt3HVjCRJyYNqfgAcAm51IuKYNAaho+oGq2YFd6/jhqOO7do\r\nDeOyp2Pl350+inrfuw6rjpOTDZuW0yrJw6L/p49bph3DDE1FG6xXF4X0D5Sl3UKF\r\nXw8uDr78xoqmaa5k6uoE0tPwDFp+vOvMFsgG0qJDaO9olLCvYIHgro3Z4Ou+voH6\r\n2Ci6P52r+lXK4/7ZnT5c5PaLy1UgOTIWkQGEaosqne41juUUE9KiJbAiKdn7a4FK\r\nq/Mp0peReLkyj30Pu+3ArkSpEZtqya7klXNfkRfwJ6Hl/n8OTdUrPL6L1fEJVJ6A\r\nR6QHvynED7D2gxiT77EBysg2w5hvLIYiU/T1t7vfw0wF8CJJmqFKYF1e5wARAQAB\r\ntAlBbHBoYVRyaXCJAlQEEwEKAD4WIQSoAP0eNWL/kve++8Mb0YkJp/Nf4QUCZdO8\r\nmgIbAwUJj0L2pgULCQgHAwUVCgkICwUWAgMBAAIeAQIXgAAKCRAb0YkJp/Nf4W/o\r\nD/4gJ26k8QstPOznvSovi4lVj1TqsG3C+BClyTcZbLbFeuecZs0whNzAzO6gkU3h\r\n6YyFBp8X77lOzm8jV2bfNaiH56otglzhsKf/hmRqGXMgKN0XKuAQpRSTVrzlEB0P\r\nWg78UiqIKb7EbsqsXr/FIF1xp22gQK629UnQQGewZQ2lry3BMA+RC/flkz/FcFhi\r\nKgSdHwPoVVoWLaeh1ybK+QaC8vKoVEnbgY42eoiIgCYup1ECgEZv5964ArNlQkH3\r\nr6oSp0eCXDrDgYNkgWxSHven/doy92uTWmgkJxwkWHcTK83pLlRzY20oXW6+KayD\r\nkH36pg0j8UNCjVRjcOXlDaAaeXz4bjWjTrzY0tLFqoLEk5qHTyQgmrX0kH8UAD3S\r\nhSg4ir7jNL2NDIyka00eY+LrRFUJMBXSKkaKtKoo5lBUEKMMoB3lDf5x7HLQ1ZQw\r\n29r1mBJGJT6/u2cvanrTnMTRrT7Tb6rdTNYIr8hiEsPeiAo1pfh/wNgyIW77srBj\r\n1FZ/Y4JkyJDwAfY2RfPp4uRcYVJaR+y0jtIHU3wQ4I6vweKCY8ruegPCSRimgKRV\r\nZgexJmbyuJxscHrYa9KLbBJ+YEydeah/VuAxrCyw+0MjexFloBJy2lEWwiy1Q6U2\r\nWbHoAJNclM/JzuMTQVvuzqdcO6krqTidKOMEFd24vHDQ4bkCDQRl07yaARAA78Cs\r\nK/b3Se74tahxL2mFXDy0QOOWE0SsdUWkbuo23FiboBXsjmlRoao89a/i2Jcyq4QO\r\nbuNj//qXe8ZN7ETSpoIwSi7PharyVgWvtNlH2DkfM29Ref1d6wXORrzR7Ead37kG\r\nid1PbIyIlldcWpB49jolqPjHvGEqsboY0dHIA+OQHLGmjO8YAzJ/2R1fL/9Hb8i8\r\nz/zJgqL+qIoD4ImZwe6S9bJtoC6epJWpNX82GmBI6UgkP1SI4FxQaYiaNWuOFfNI\r\n7yxpVZ/QKj2CSS0jz7bWJbWw2FJslZCaY0sAW6Vi2yptr63vI9Y2yfpIg0m54ZEI\r\n9CTAYK7uzS7XO2BRPcwIPx2E9LRdPM5khm2vxbT6v+04I/vqlZdMWE8vUrZMrE0l\r\nlPtmiEG0eY6MhnDjd009jfsPuGPHarPIu4g3de+nGoT8auzUjNQZy8PCc5KjeKIM\r\n4cQACltx1DiQCN06ht1t5rst7Pcr/1B5Sg3vrpdLI2m0G2p6rmc1yJN7tIPImFaS\r\nR9KNMM73jv2EmRBM60F0BK2IkLRNadj55/zOiJ7j7KRe9m2P/7ax+ulEzEZs7tfH\r\n2yPQUBqL1y5iUKjwYDkXXJYDjAAZi17DYHnw8SN01K2hbS16XKEzP3ezv6Tzf/fm\r\ncu7JXh5C7H64B0LzZ4HDXOiXaWdU6y8wyI+HKtUAEQEAAYkCPAQYAQoAJhYhBKgA\r\n/R41Yv+S9777wxvRiQmn81/hBQJl07yaAhsMBQmPQvamAAoJEBvRiQmn81/h3mcP\r\n/RJAzKKVnHfQcNbwCNcebPDiv5MG5EXmw5rwghfXQoqT1Quq4J1s5vSMJP6TS8pG\r\nocvrsfuEJLhAodO18x5HhcxwaH6TfjJi4LcsoH7jXRwgutV/yocGw7yjEidlFCec\r\nr4+d8LfoXBBExjJKlWSXhGY+60HaVnZAGK0Ep526dCOpXTfUYdjgZr3UQqZcqW0p\r\nmDRjrukeu9HA5dFfeFLwZ4iY2X6oJV8hOY3fveMgDInIb9DQXmyYYQ0psh1GkjWF\r\n4rhqqQ1pZiPRW2HZrRLwvi2+g9bQNrFrPICndCb4R4+u6lghr+5sgRNcskZClU39\r\nat2q1k9wJlWcaTeEIGOIWp1OusIMAfmJpedc0XV+Z/qTSXweDrTvOKTvU4UkKisc\r\ntj1x82UWsDIZUjlr/VyWP8uocrxXdapQCkZKuqSEcIgsnVg+ueIO+fJ1TqvPQid3\r\nYAtqBZFZEw7+J/JoDajUYLsf6hlqnjcP6/O3HjbEEi2v7BRYmz1u5Ju12nNugDlo\r\nSJmGCzDJoguRqW+QpINJKHZEgoyIlVl+b340r26rl0wafhvRHrT5tCrEaud2lYkh\r\nBGquWHCpzgmZyqoJU/c6/yz0sX5ZEH24iWc4BdF/2Ys0U0kq6Ff9VgFSqqbi4eJH\r\nFTRRoLMND5oM0p0NOsJ7KQ/VeA6CoAck3RAkMeCiBP3V\r\n=ApjJ\r\n-----END PGP PUBLIC KEY BLOCK-----',0,NULL,0,'white','AlphaTrip','2024-02-19 20:46:00',NULL,'2024-02-19 20:32:05','2024-02-19 20:46:00'),(19,'MedIndia','MedIndiaWhaleAcc',789032,'$2y$12$ED7z1FUjTgL4R5wq2xv9S.hjNqQQaxQuyr8nPJJFohILg26E7JGg6','avuDH1jAtstyMoUAN8GPTbVWk8Z0cHe0TsywjFPjZAnPXv0y9nPK5Scd0AIA0IouZJn3cfbDtvgn4dA9EZf3ICWM3WGrVJ7lgeoLHMR7BTxik3sO3Mdj4Sxb0cOI4XXh',0.00,'RealWhaleAccount',0,0,'yes','user','active','in_active','-----BEGIN PGP PUBLIC KEY BLOCK-----\r\nVersion: GnuPG v1.4.12 (MingW32)\r\n\r\nmQINBF/CxloBEADSs/z4Wq5nWKcbcEhnNXsT17fbuRqZ2K4X0pjnnemjNXmqJ2gj\r\nDLBmLCtx5nSb6N9fv/grWJG54AiyVhXhBZm0bLGd2Z9QKUIVvF4XDINgWs4OaIXa\r\nYVmZsNt2GAzfV/wZUFG4ESNicTk9n/FVc7Nkhr6hYa4asNJwhZAxSTvc2JuWHvP5\r\nuWw/OuBKFvtHQyWmopvwuc0rDykzUdjGeT66g0xB+SwkONnNb6dZuutngjpRk/+k\r\nas3pkzPwUs5dXsXIaX6WVW0HYolOBaG7gHlTdGgUPGZnjqYAm0zmbLwQ58KdvU/p\r\nCRRLoQ7GoCiDiFgxmQwfljqq0MgTSMv+nfkbJMVt6mromzCQIhEQZ6JnpkZfcmUx\r\nSQsAFFMW1dvI4m807Vl6LdwZ0GlRzFIvMut8dXWjcpWjItjKR3Qb8akJoKfOPe2U\r\nZ7F6QhS6SfzpkJELLnElDHWmhsONXthb4b7ilim+jEEJIq3DR6BQjvd8TLoy6Tcv\r\nJmlZYB74AmGcpuM2Qc7JHezlugWM3Ww5anNLT1XQcV8SaHR4M3JjDAXCQ8VMh1fy\r\nqxBz//qE4xrFHpXv4jWTIIrF9OUwX4tG9QO8W6bTSG5jBhqQrE2UWSFmQwYEN445\r\njdnPP9uCF7e/HSWBQteLQ35ofjJ5gyrV2ylUCCYYMYz7daOS6IwTCt+eawARAQAB\r\ntAhtZWRpbmRpYYkCTgQTAQgAOAIbAwULCQgHAgYVCgkICwIEFgIDAQIeAQIXgBYh\r\nBDEyGqxqOEZyEtBEZtD6o1F39N9uBQJjdCRxAAoJEND6o1F39N9uXLAP/37m0s7L\r\nVYKdSenwcfS9y8vFbs8SUjsriLOvFBPRblIXoLgcIGS+q3tS2RjGkXKiZuNfRVIN\r\n9ujB3S70Ps9ffok9HF6x5RMsropx4PkIvoF8RIKA8f2SCmBWdZ7NIbydvshtZA4C\r\nJ5Dmcz3Ide4FWA9sWTogOz2m0xOJ6GAXGSIMKelP2IACfFOW8o9zo0ljlwwBmmzW\r\nkBcTeO7ayckxS8PRldXN7wrDKQRJGWFaqxJftBjofiDGmVlWHa7S/PwgrGXN1Ae8\r\nAkEWbi4vlgZW8fFyabJ4LY8nLLCHb977zxmjCI+hICsugdLjSkG8j3/Gjv054fXF\r\nuuC0oeQbtpjeAOKSbziDwcGjo/Waee/Q1MKUBouQ04N677ntijiPP9f2lNduvuGt\r\nWyzdSTtC9m/J7wjO6of+ndxOP2OW9iHhyGP3G11dnnMt3aYAqvCQD1Q/bnRq8yov\r\nLDjsI1jOFQUcmjHW01lmqHSmOXeY4h/l2w4hEjJ66PiO8fCLFaDGz4eGOJ5pTa2d\r\nmJvqbMxee6xWDWrCxKguJlDbwR9ivuJQ1ixII7PFD3M5sw/yo1bj9/44zal0bBOl\r\nK6CkdLOhYuuhjt1s9Fp8IfjFQ3b3sJcRp6dHYfVISxSsa1aAobjMkOOyTz0Krhn5\r\nA4EgGUSQsVn5cd2e+4h38ozFAZA7qCoKHmWtiQJUBBMBCAA+FiEEMTIarGo4RnIS\r\n0ERm0PqjUXf0324FAl/CxloCGwMFCQPB3GYFCwkIBwIGFQoJCAsCBBYCAwECHgEC\r\nF4AACgkQ0PqjUXf03245dhAApbmh8SeL+FwQLTzOf2Fl2BYgpTeDTR/WI5dvF5tT\r\nngzBJ5iMABSkq58m+/U1vOgiFKlR5FjMfQSG8QxLgKxqQor6K3Ti2vf7jg+SxNCx\r\nX59wbQFm/7Fde/7+s952t1HZVg+CS8wu6GJaNcTbDquZEpSOBTYsjOL+2NaROj3C\r\nT8Ghoc1J0dYDfD75zZIiEeNxdV/l95PZ2aCX49b8BzyVZCefqrtDUKNakL7u06M6\r\nvqpgt9QiRrxPe17GD5elKxa12USJbOEXdizyOdCEcf7eNwGfUdHX79maI53BiE2Y\r\ndSTY534+iFGBfyPpoNDRzYXb9ylms2VO111Q0T/QSMCc8UQph135Cuqv+GCgEiWk\r\nEVuEYU5FzFFq86LeI3q3o6dDw6mVJM5ZRHEtCwuyDmirMPhBbmB2maTqMpPov8Df\r\nnTss5FkDaptPIqmFChxtKuPULnjKnQs69VnwTAdAqT3FqB5UK+UcD39bveVDVn22\r\nbXD706qtlB5pKgNED2ce+lGIZ5g2za23KqQVb+8TnZoPMHxxXa8gGEqL8l4pArCN\r\nvZBLl6RhcQYRauQ8gw7txL81cDVW0aoQv3MHZBWSNVxs5MEx2z5KtT80542tlGkU\r\niWpL9pH93bC76RM0pbpGEVgvNf93iIOq7Uw2CAm/13KsUfAqD1RMlzMFtQsBw2M+\r\n0ZK5Ag0EX8LGWgEQAN4kX4CtMQv+qUZHq64iIuVsY+z6/FQmxdcDGNyv99nav87V\r\nOjtIf8T5B5u/VTybbe+oa928oe0YFHTgaHoFbSZimAAPYYEAGzMyVKPav4siT2mc\r\nuLYAOaM4nCh2zqwj1dExVzL3O8+sLxs3nJMy/N38v4As1iTD1iqlRJXAzQeOMIxd\r\nTs5wz694WleyfqnynCWKQm9LYXa8WF6pG0wG9LrpwegMhBU4c2leoz6sG1zxbNuO\r\nL4ErKfA63Jha1kJtWVVcV5a8cCg65FWNvTfduN/rTAGV/ABkEga1w+cz0+vtBa62\r\ni03VnWF0FXmvO9eLAirHTpVrW2Fm3iHK3OmHy6KjN0RU3WAABZ0VEfGh7d77tmsJ\r\n/GzMvpTBvDty5WOUeShaDnMC7NGEFv1LEIrTOrD08KZiHM5faTzTA6mRv7+oHy9L\r\n9RY+fmFsAz4OQcZo3qTTqbKRilL3WamWIP7Cd7QAcn1vwQY+5HUqRRgwxM2/8Wsi\r\nz6Nz2WErWa2LbuwpbvIEZwKheSr3kffZxXg/9niK4heRz55uG0e8CBAOq3WhThK0\r\nek3f0Ad+59CT5E/JHf1bsSkTrgdWHN1KEYiOrFwtAp1qU2Oz9mxQiZgnpkoggG1L\r\nB5UZX4sOgVG4SNleWk5vFryvYuvAUgSqLvuH7MfAUFnLNw17zEZQfiqqRaxBABEB\r\nAAGJAjYEGAEIACACGwwWIQQxMhqsajhGchLQRGbQ+qNRd/TfbgUCY3QkfgAKCRDQ\r\n+qNRd/TfbsqrD/49yDM678Sx/sD32cfkhn6HIK/Fs79rG/dy5F+iFWjXSWCHx5Xp\r\nv/lr/WPqS2f4Wh5GVRcqpj434c57SX3tV5evzuOKqWMYqHL5Kr5LMFtExZKQQr04\r\nnSFx0ULILLfmZTEC4yrIRmVP2NCrmASEi9SUG2BRRgjXtu0PLRW1c/t1twJBXzbk\r\nOPvO0xeNWk8LvlYXCIUtMiJAOuiUIb57HLoBgrqIXBRCgci3iP/W6R8vf00tF4I+\r\nUuf1ZE0FFUyxUDwxOAzi/l9yesJgLqGxuDXEzTefY/pJLQ90XtZRBEEJzoh2wZ+f\r\nMXMLNEUIxEzCaiw3o8Gvxx3vsMxui0XmERlin60PfgOAzf9bOPR7ObEAEDVxSPW3\r\nE24v12Y1CL2jClo5A/pHzm3zNicORkr+GIr7Jt7srFGPfPkclk5EKDSjEsCqXzN9\r\nwlwRj3PLvEhCBt9mJABxYmHQqXqOipQPJJK8AfxajH09Ak5XI+dhhptyLhL4ahjY\r\nU9A1mpbf0vigStmS5S13vNhs3urPwePPeZNDWgcr94uJDfc0zf5j4E0Skc8DMhv0\r\najz4HFXT0V2SIZlUJD8IhoIsNSeOAq6K+t5nIZkfz4SGW4pDu5MDVUazRJkXj+pY\r\nM7wLcmICg+xNJoSX0tAoveZOOHSVXN4DKISUh4/pm/waSHbMoqGTuJhfVA==\r\n=w47M\r\n-----END PGP PUBLIC KEY BLOCK-----',0,NULL,0,'white','MedIndia','2024-02-19 21:04:13',NULL,'2024-02-19 21:00:04','2024-02-19 21:04:13'),(20,'Fyodor','Fyodor',111236,'$2y$12$B/teV5JcP000Q67UvUkBaesN5s3D88UUOqRYuNodPA9.AYuLvIzDi','tugLe9bY2z1HnRA9qcbnTzVoCTuvrc3RRnzYYAnSgZBuBC5pSgohmBvJOd5VpiNxmbINeFSl0CdafzAcD9UKgIC3pwJfIaUcUtdW8z2AJ0w3rAGirN76GgZIQZYzjuNM',0.00,'fyodorissohot111',0,0,'yes','user','active','in_active','-----BEGIN PGP PUBLIC KEY BLOCK-----\r\n\r\nmQINBGXT6hwBEADHQAPKRIhmy2RDqIAINwijAHBFllb7OJMk5qKqNonyzosdiImH\r\nrExPQ0svQcDOi6q1LE9oP9TGHNDNMUAG4+AH4GimvMZHCzAkEbhSG3gobv43DZLB\r\n4Tg/mMbj9Xy3n/ujVA9m9hBLCs/GRVDzPbkPyS03qNDKITD0YnrN0maUxg62n3yH\r\nUvbh0JCtyHlu6YvmqvGaPCxlnqL33PwcHEPAm/axuiu3HUvbftWyHk2pfXvfVNbj\r\nUKVkwE/xiuJRf/Kn+Bn+HJUY7RPnxrXAOIYR4RXbHEhsQ3uaMjnuP2PdOUYIoTV3\r\nS4zqw3SgUCrysxiVpoIyrQGuAyqQ/Xvug2NsUlOBqMjcWv9/mFHBQ2N0zSGOMhmW\r\ntMo+D5yrS9oMQ1oGD4g45kLv8DZyBymjjC5e+OjaHq9jUXhV5hYAxjPOC0kIVbeS\r\nAdglKvD/ozHwqx5SAL0A5NALKZHhhjaqtFnSVGTYKTlcrXwDD1SBIDGlnPsDZDqi\r\nIO8hlgKuMAh9LSrLySrTc5t7sGAQ706t+qGYkRzLhr3EdbOnVfc6UqpxvJH2HT4m\r\nFxZWXHSVYWIs20ohGv0wRfPxDQMpKKSqmMLGrxgfPZVIMGZ+Y6IN+TMCPGwVUTKU\r\npqYVdYdB5Ohun7wpms9nbxuUjK3dVrsRISUofSnhCqWG4OyHVepqkPxE7wARAQAB\r\ntAZmeW9kb3KJAlQEEwEIAD4WIQTrkoYp7P2JsUMMV7aj2cTWZqypTwUCZdPqHAIb\r\nAwUJB4YfVAULCQgHAgYVCgkICwIEFgIDAQIeAQIXgAAKCRCj2cTWZqypT9PtEACx\r\nsqDZ+0DKMt5EWY2iHczz5jvgDQOXQE2suC6RK5+sWo5CA6ZHmj8SjzjplOTh0EqQ\r\nSgmzFJIMBhAr+sCK7UfV+xBy/6Uv+1YK8mg889UMMNw1RnJhIR+ketB6V0wnoEtN\r\nVwlmuUdhd1egHff9TlLhhUImShy2k2r2FkTPI4xsRQioOzYW+SyTsnsc0p4e2QYK\r\nbuarrqzkEoIxTeTeQ/TaI1o6vQLh9KoH0yNDM+JMZlsrklxWiXGbLZAxUv8H0st4\r\nGG20z7mKOFAJavNyvU/xJoamHV20jfze4mIiH7jpAb1NQ3YwMnMFZiiCisu2S3XP\r\nJT1TqqcB4GbabEeHd2ohoeOGxWtewfvn205rmn3RjeP0a85Vd40HdjOxtDo7I3Eb\r\nM5rgZrYSqRP6X8PxzftgBHSwX6l3gmr575wwJvYIbSulQrWCXHKgshg8Pa+wkpTU\r\ntkipCQJATrbqeA27Jc/PqhVwinugbq9R4R6OBhv4zQ3rXnuRu2YBV74rwpfV2YP9\r\nqWLGUguH90NDzHX4yrmyL4fvljjJPSBDQwnZXHCMheBnWMlAZeU1AInAlUi0zmZd\r\ndVD8rbfoZHJvTc1bNf96D64Sjy5HYCYyM9ZtH90YQGUGCawXgdVSFgkzBwfgGbdf\r\n77fB498R4z7bFfpkZ1z1xFKToLVcBYdJn1MzWhv4wLkCDQRl0+ocARAAq0BAjugw\r\n2+bef2wRHEd6fwZg6qeaw7at9XmwFbFHiKB/v/faaS9lRdpvLayVZPvnIc1cSyVG\r\nC8N3HcaDF9NazFno+tVpABRSDmYvgI8zIIJOp1dn88DYLwiijL71r5IfPRwwcXVL\r\nJu4mbGoL8txa53chJxZ+u/5IM0NMLTTWlW3K8KOvgSvDJbfItZyha4kLcUC4cvNP\r\nU3Brq7lhEJCpU2p2qWrMsmiG17bjssrtMja9i7CuVtTq7AaWXjvJO+Myf2XV7EOD\r\nO5hpfYo9/L0h+fO79URZ9mI7dzzgH1Zw3hYz2FDLgDgijnu0936r9pSVSbvgQcAd\r\nQ/TZdrR2YBBeEbrnYv1ECl4Sbz2YDpg5gHto56mGRwv5AT4jT3uHoClAQk8zFVo7\r\noKrr8bpUPpO5SYp9ZO2o0gPfqU4q879qSIaq9oasGM4LyZk/q/Yy/7PMuPMcCiRt\r\nXSdLWdfOh5hMuQh6usGgUV5H9dcLfClr4gpnj7QKLWXd5SDIyrg5NnvnzmnBAEe/\r\n4A+O3V3Gr9NJBlga0Y4YyhhnuoeVgjftTwIVRV4s/Whyu4t7hMaIO9jkRX5WaiiB\r\nba2MX+0gI2tU2+wlXCIQcOIh0jM2bCvhgsZNMNGci4Sh3vdisSMYb1R4u3nxD43M\r\n7Iwyec7zzFaUsRoDwbltm6IVlIgcBdayeSsAEQEAAYkCPAQYAQgAJhYhBOuShins\r\n/YmxQwxXtqPZxNZmrKlPBQJl0+ocAhsMBQkHhh9UAAoJEKPZxNZmrKlPV1wP/RmG\r\novXuZ4SH2THfwVxP1S3KgoOez8T/UApKuXydjJymx+bH3ko3X9X3DegdvT6JQllO\r\n4mwIYDF7/H8+3J0NC1CH3lAln8pvBPeCsxytLHGU6IxG9Xaci3dfnlkHLhJ07DVi\r\nJPa0xsMhqpoSndihPfGFQTJOVYiDyWAhpMD3l427ivJ7AH78LMe7uCDPSBF2YNeW\r\nFULq755LIBBaBUyi9yqdX6eu++4D3KGKtc7lP92CP6t0Gn72Hycv4RWDJHEq7GaN\r\nKai7wxn8NRwwibY/UWJyFgfqKeRXJGQtHiROOKJ3bHPB/Vf/3EaS/UKJBMSgxjgZ\r\ntdo75xbp8TZqEyPuxU+JbRQ01haurwSYjtaq2HRx+rPVeipzWbIF7VAuZqAXNdiW\r\nRTg0w4wfqWeST7Izr7AX5SIY+37o+lCY36anIVanWLHiqA7MCwwRQpSPJruIGNtB\r\n8jb8zZUD8KwfWMItgCB4cg142HC3Ash9in9bnICHv8B9y6kHZVOZ0g6P35Ux22fM\r\nSUA9E9Bfbm2maoPnIaNS1xBLJdcQiz7C0LCEBxJpu+vvbjsj2XHJz9Jb8WQu2r2e\r\nlX4KXh/ndRYxejB6CBUKz/stpUALDjVL2ZwgjKuYaldoW28/RKMgJNtQOozxmENa\r\nXEMxKe1iK+CZq3J38eBwcIzF4gvyxqq4kt00dHYA\r\n=vaQl\r\n-----END PGP PUBLIC KEY BLOCK-----',0,NULL,0,'white','Fyodor','2024-02-20 01:17:50',NULL,'2024-02-19 21:44:56','2024-02-20 01:17:50'),(22,'blubber','whaler',123456,'$2y$12$ZctYIwdYqNIN2zLguFyjWuqtA08sPhucYwv1pH8xqgnk3uyXhdFOq','6G8e0rQ0iU1S8h2x4R6QwxlZi7FbJ1KIDUDuxaZs8NCdrM49XF2kHo6VArlVgEyFPwRFMA2zjXG86h7IjwAySPruWxUTSRbBto8RPQLjf1jA2Kpq22jkw2Im1gRIpI5L',0.00,'fishingboat',0,0,'no','user','active','in_active',NULL,0,NULL,1,'white','blubber','2024-02-19 23:03:30',NULL,'2024-02-19 22:16:54','2024-02-19 23:03:30'),(23,'PacoLoco','Pablo',573331,'$2y$12$1nY09aGqdMjXtNN3Um262eBVdqsqcXTUPEv7yFQKXyhe8bzjs0nCy','3gc0WOW9sCdFJ4Qnn9SEND4BrW2ZDNcFsYoSbNN602xgP7xbDMAtiuPrqrHvMyHkpT9pMtHMnZ4KjxbivFGLEqcP4GuKZULYMimqDh4fxuwJUNYzOkAMx05fPHFnweFg',0.00,'excited',0,0,'no','user','active','in_active',NULL,0,NULL,0,'white','PacoLoco','2024-02-19 22:22:32',NULL,'2024-02-19 22:22:32','2024-02-19 22:22:32'),(24,'NorthenCorridor','buymydrugscunts',646433,'$2y$12$n3MfcBtbgEY1d4tnNOh.5e3IBG3izTh76wWtJXdJdoTBmRrqaE0QS','eXp9YZAuiZWcU660yOY25x6Vyfe4g31c7IGg8Bob8YSo0kOJsMF6FlnJJFmqG9UxqVQFluWfB5Qb9rGrrpzmuGNnAeoZj7oDcgec00FCiohAe7XbGCggJdHaDWDEd0sC',0.00,'suckmynutsLE',0,0,'no','user','active','in_active',NULL,0,NULL,0,'dark','NorthenCorridor','2024-02-22 19:42:27',NULL,'2024-02-19 23:47:18','2024-02-22 19:42:27'),(25,'jmito1982','jmito1982',123456,'$2y$12$2T.OWSkTrGyVEia4mAr9Ueo4RABZ9Lfw0FFh9QuUhErU61qNHMbWe','pYjetW1C8OlYWTwKY60HwIbg4o3l6nqlkC25JX7eVhBPotgBsajUqSjdl7mwb8zHggCKT1yMRmcc5m5dcZc5xb8jsvlqmuJEEUZIM3B8vbkU8px1z8tIZUhhv9lQhcKk',0.00,'ladesiempre',0,0,'no','user','active','in_active',NULL,0,NULL,0,'white','jmito1982','2024-02-20 00:03:37',NULL,'2024-02-20 00:02:33','2024-02-20 00:03:37'),(26,'snowspace','snowspace1',369369,'$2y$12$wU8JHWeMCKOX7pXMz7p65emYPbp84uIheSOYFf1vzq02eBxAZRFdu','8ssaf1ioiUolwbCgbRLSUQtEixplV2LA2YstN3rMUnqrc6ks2lEQDh7yBI98ryU2BW9nnK4z2uVa4we4AeFzIPBVbhMHHM3NOLjVQvXToFyY0uMp24ubv3GCvWoMEFUM',0.00,'needforspeed',0,0,'yes','user','active','in_active','-----BEGIN PGP PUBLIC KEY BLOCK-----\r\n\r\nmQENBGXT+pwBCADeGgZcwcuk1XrQlez9FtXVp2nGUkXz2ropcqx0Zi21Pc95wIGg\r\n8Qp+u0LcSHG5jQhmZE3xRSM5n9YWoa1eQ+PBRHMVmo74PPYQajVRMwd29cJcypxe\r\nT+zwGBEgfJdZte/a3e8wYufapFKS/RVPECcmrc5xaViqfTxU1EU8L1SPfJo2z8kA\r\n0p0WNRU1WrgDNLFbSc6uqqSMeKFRHUsaNSh6qj8nCRELeNRzGQbh82ORrOU7zn3S\r\nPvuGlhlUCetz+bw3BvRdoOyRgoVFQ7Kx4UY636HCTmdCEZWAhTeGT48G6b9SV1h+\r\n4Fa5P3cAK6+PP2lGIVVmDpB2//u+PFTErt3rABEBAAG0HnNub3dzcGFjZSA8c25v\r\nd3NwYWNlQG5vbmUuY29tPokBTgQTAQgAOBYhBNkaJvPIiS+QSji2fR/fjz4fWCB7\r\nBQJl0/qcAhsDBQsJCAcCBhUKCQgLAgQWAgMBAh4BAheAAAoJEB/fjz4fWCB7lxsH\r\n/0eUw6o2tRK+tvbcM7V67/RCz4YXruVV9HyrhdbHX0+slhCbRQ99K4l7HTcjc3dX\r\nrwHgMS6pG+XK9V5mAzGVxPqFfnOUgt4OUuzXYlN+9UiwQ04V1UN2iBkGEN1j5rUx\r\nrRBA07dl4B3krArrGfkvTjX3k/akyBHOcDsjkWvw92S5WQ8FdoDMtPkHCJRHWVAv\r\nnSoID1x5y94rPG3Gptrgk0K4rMNYxgB4iIHLcplGS17JvxKTWTtG1xH9vGOtdIPQ\r\nu1X3QX0UohIbrFy5SHEgY1O01HH74XOQ6vPU6RqBbws+ENMxssln9/7UwR/AkGfr\r\nMe9ihFGfn/c+PpF6+XUBr5S5AQ0EZdP6nAEIAPHADlPi2UJNgDC5m0K3muwCRZmB\r\naZ7r6rpjK+wSzfTFGd8Ks/TIKbKGfKlvq1VRNpGePJczwS2wRfqfnyxaIcnmdwOP\r\nyBdLtzdkp2P5bflm0YgZvizJ59vsE/iHS2/ACTItKOCvWYNW6lNQObFEYIiMZ0W+\r\nM6V6kEI2c7S91b7YboowjapueStdtBRYu3+u2p+phKb5KsGbAX2oWYht3+lu9+1J\r\nUtZJtrzKwwO+qBz6uZcBI2hHG2AnU06oPyf6u/jj1JB0qolXGQyfpmmVokI0Errs\r\nbCD6sTcLImrBFdeiRZ6nUMt61838M9lhWxQ1g8uLeqERjR8a/8d1dP1z7H8AEQEA\r\nAYkBNgQYAQgAIBYhBNkaJvPIiS+QSji2fR/fjz4fWCB7BQJl0/qcAhsMAAoJEB/f\r\njz4fWCB7il0H+wUs/Gel/+4Rjl95dJ2w2xJa6hrxHhnAiTdAw8MtJPeIanvYI5a1\r\nx7RJ4cSH4hpoQ4W3SPwsVq6TQfSzEIxG5zUOUbOxeQqi1ynKoVRhnCCbCjxFRwYD\r\n+wzyW/hHBFiFtvNYuLInayw0P4j44EoXczFQarkSPLHV/0Paq2LbngRpEoOodQZB\r\n9R2Pjlim+veILj8Yp52AYadvG5m6B+AMehHS2oNj8LRbZnhxOdjCZ4CZ7EHO0ly4\r\nvJgt35yMzb6l0ZABrCN9b1JSWfA8HCHNMRaW/DmP646bo8eEsM97jIy3jJ220633\r\ngV2VBJhKxHLXNIkA4nH/YvBcK2cjOVlSQTA=\r\n=gmmp\r\n-----END PGP PUBLIC KEY BLOCK-----',0,NULL,0,'white','snowspace','2024-02-20 01:11:47',NULL,'2024-02-20 01:01:13','2024-02-20 01:11:47'),(27,'m00nkey','m00nkey1',835475,'$2y$12$aUWsu6ENHFCWD/7GcvQzve8Yt37Ms1Av1JSpckNHpsewXJvb.Z6iS','E0lqwOBUADbphoCLZO4tXyWsA6Jlx9aNo2gk7nYHoEEgrxvzk1nz2Ha8SAQpk4J89D5OZC5Xo6WMuBQZ6brEqb0jttyuiCMWPM9C1gvbBxUMQ3FXxibqTs1MU364gudo',0.00,'fhcm',0,0,'no','user','active','in_active',NULL,0,NULL,0,'white','m00nkey','2024-02-20 01:27:00',NULL,'2024-02-20 01:27:00','2024-02-20 01:27:00'),(28,'04985603yty','saladpatch',300300,'$2y$12$8lV.h8gxNzOIQNvy4IcgKebVQivdnYG12/9.VJoIo1.E66wyiGJGa','INU6tBKQ09jmafJmdO9kT5HX1BEAgqmVnH2FjlRLc8nHx4mYA5vJRlOGHnBFvW2Kp4UItihXa8hW5U0eQuOppl2cmFShuPRqG4RBElGY09bHHKIOZF2p0EnYBoAip70a',0.00,'niggers',0,0,'no','user','active','in_active',NULL,0,NULL,0,'dark','04985603yty','2024-02-20 02:03:17',NULL,'2024-02-20 01:33:56','2024-02-20 02:03:17'),(29,'bytes','byte',500900,'$2y$12$tVsJQUCMJp.83c.cH9auRu58CTxB92/d67xnjq3.9O/BG949MAXTa','L3Ll4P1xTASuUHlEtfOEX2kuW5QddP56aIPnYIe89TMajbe07v9DkH3umWdZKJkin8w0iOP5EEnCqTIXtbWqFMt78zSQKhaHO7OrjCNzN4DXuvg9vMcP0ypv1tDQv22v',0.00,'bitsland',0,0,'no','user','active','in_active',NULL,0,NULL,0,'dark','bytes','2024-02-22 12:19:47',NULL,'2024-02-22 11:42:06','2024-02-22 12:19:47'),(30,'testtesttest','kjsdflhkdfs',123456,'$2y$12$Mxf7aGXXVGL2P35AWGlxi.//sDXFMMda3y5/owpMK8pNJ4B76qCUG','pYGxf59jmpcrkxmqNoKJUu8CZ9Rkonpf5a64zUdtOtrTObC64DCika7WpmFCqX7yJ0PzHfhTx9WQYa2Gj1l7M3EVb9srWw9RSSUY9PRLRi8bu1M7WdAqdaZnQXlvEvND',0.00,'askjldhdasf',0,0,'no','user','active','in_active',NULL,0,NULL,0,'white','testtesttest','2024-02-22 12:49:57',NULL,'2024-02-22 12:47:54','2024-02-22 12:49:57'),(31,'fix','fix0550',101769,'$2y$12$OOmLt/xwcQ6qcfDH500mC.4EB7saHN87vNA1eu6Xiz9VpcKD/vDrq','lagYlxBEXuG95RokrtByTCPTkgIjR5VIhMu7UsL0dcJRmZSRDVW2Z8dGPfbN07YFGa8R2o77ARqFbp9Z4pRJJqdLgC30hzSVmKXXiaWVQzymsRVST2N28YcLu38iL91f',0.00,'required',0,0,'no','user','active','in_active',NULL,0,NULL,0,'white','fix','2024-02-22 13:28:12',NULL,'2024-02-22 13:27:19','2024-02-22 13:28:12'),(32,'Ganjica','Donna',481593,'$2y$12$z5476853kWo2YK2eJaqjE.00vTxUo/KJFzJdYmEyQ3i8.Uk0abwNW','0JXj4El8JZYc3RATT8bwG8sgW1KEr4EEJ2AXBRAGsHutAn5JBEzgWjYLCx3yPNQMh5y2pcS0X89KdxE8BHAbdaXsxtZW6LnJFHz8ZK9m0upvMJA1ToRgKuZCRBtzyxnw',0.00,'Maria',0,0,'no','user','active','in_active',NULL,0,NULL,0,'dark','Ganjica','2024-02-22 15:02:17',NULL,'2024-02-22 14:47:39','2024-02-22 15:02:17'),(33,'redboot72','rb72',666999,'$2y$12$vbar65ah956wvPIEzlnjAe6l6cdUcnglS5hI7/If1qENK3yT9PrOC','XRmVcIqlJSud1tiy5AOli2xe9NEexoPDSkUaiswrOwRNElXcPdMkpPmnjP1h8YTuNLPSz4N0M6GlUgZVFB7l6aHOSEogp2maTRL9xruFqiSqn1Haf2Gqf3mCgqydFWbr',0.00,'interior',0,0,'no','user','active','in_active',NULL,0,NULL,0,'white','redboot72','2024-02-22 19:57:03',NULL,'2024-02-22 19:57:03','2024-02-22 19:57:03'),(34,'Japer','KiNGofLostSouls',89938,'$2y$12$89HMb2Um/2LAH9Vkg4UlturRn3ZyEf0crbPKzcMgLNayoCFEHgMWu','3PNW1k4YbC5gMqRePrm0sRDxUIauHrCnBq3SgIcmasRr0IC50hOpqPHgd9Y7k1QXA5W6xtsn2i3N6UjVSTT0IOoXdwKnFRDiONumZgKPPo5qAzfAGRQtqkyxE62JNsOw',0.00,'anobodythatwaschosen',0,0,'no','user','active','in_active',NULL,0,NULL,0,'white','Japer','2024-02-22 20:03:52',NULL,'2024-02-22 20:00:08','2024-02-22 20:03:52'),(35,'foolishfish','foolishfish',727370,'$2y$12$SrQNJoqi08GsoJejtzLq4ucBIXDDtIaYGPhTl2NyunxcBK66Flnli','aBOT7xu73e46uRvN68EpACwtt2ztp11ojQpChxM2zbORHGDdZh7y48FBs1BOQRKVw2ryhwFQidnjcrFjJOA7kPpRquVw8qZsB6hPFZ70OAPdB3On4LrfuV2i7J2cBcGc',0.00,'in the basement rn',0,0,'no','user','active','in_active',NULL,0,NULL,0,'white','foolishfish','2024-02-22 20:03:58',NULL,'2024-02-22 20:01:29','2024-02-22 20:03:58'),(36,'testtest56','testtest55',123456,'$2y$12$Hgxa3ToHYmFTcE.Izf3lbON7F4ofCXEGPbY6U8O8Opf818HMmFjla','BIOcld77hWpTNc7xA2Gu94XK8V2IKbebaPlF1emHOBpLT5Qx5OUcFQJoAyMMbtBBLLVA1eZJRPOafWSmVrnFpJh8ItbKVZ5bpWgmeGZiwN6lCzerfb1GsYIm5CSPnJgi',0.00,'testtest55',0,0,'no','user','active','in_active',NULL,0,NULL,0,'white','testtest56','2024-02-22 22:30:03',NULL,'2024-02-22 22:26:40','2024-02-22 22:30:03');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `waivers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `waivers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `reason` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `proof1` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proof2` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proof3` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `waivers_user_id_foreign` (`user_id`),
  CONSTRAINT `waivers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `waivers` WRITE;
/*!40000 ALTER TABLE `waivers` DISABLE KEYS */;
/*!40000 ALTER TABLE `waivers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `wallets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wallets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `balance` decimal(32,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wallets_user_id_index` (`user_id`),
  CONSTRAINT `wallets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `wallets` WRITE;
/*!40000 ALTER TABLE `wallets` DISABLE KEYS */;
INSERT INTO `wallets` VALUES (1,1,0.00,'2024-02-19 07:43:55','2024-02-19 07:43:55'),(2,2,0.47,'2024-02-19 08:14:16','2024-02-19 11:29:31'),(3,3,0.00,'2024-02-19 09:19:09','2024-02-19 09:19:09'),(4,4,0.00,'2024-02-19 11:23:53','2024-02-19 11:23:53'),(5,5,0.00,'2024-02-19 12:25:25','2024-02-19 12:25:25'),(6,6,0.00,'2024-02-19 13:28:07','2024-02-19 13:28:07'),(7,7,0.00,'2024-02-19 13:40:22','2024-02-19 13:40:22'),(8,8,0.00,'2024-02-19 13:46:49','2024-02-19 13:46:49'),(9,9,0.00,'2024-02-19 13:48:29','2024-02-19 13:48:29'),(10,10,0.00,'2024-02-19 13:54:02','2024-02-19 13:54:02'),(11,11,0.00,'2024-02-19 14:24:44','2024-02-19 14:24:44'),(12,12,0.00,'2024-02-19 15:02:51','2024-02-19 15:02:51'),(13,13,0.00,'2024-02-19 15:26:31','2024-02-19 15:26:31'),(14,14,0.00,'2024-02-19 16:44:46','2024-02-19 16:44:46'),(16,16,0.00,'2024-02-19 18:53:25','2024-02-19 18:53:25'),(17,17,0.00,'2024-02-19 20:23:00','2024-02-19 20:23:00'),(18,18,0.00,'2024-02-19 20:32:05','2024-02-19 20:32:05'),(19,19,0.00,'2024-02-19 21:00:04','2024-02-19 21:00:04'),(20,20,0.00,'2024-02-19 21:44:56','2024-02-19 21:44:56'),(22,22,0.00,'2024-02-19 22:16:54','2024-02-19 22:59:28'),(23,23,0.00,'2024-02-19 22:22:32','2024-02-19 22:22:32'),(24,24,0.00,'2024-02-19 23:47:18','2024-02-19 23:47:18'),(25,25,0.00,'2024-02-20 00:02:33','2024-02-20 00:02:33'),(26,26,0.00,'2024-02-20 01:01:13','2024-02-20 01:01:13'),(27,27,0.00,'2024-02-20 01:27:00','2024-02-20 01:27:00'),(28,28,0.00,'2024-02-20 01:33:56','2024-02-20 01:33:56'),(29,29,0.00,'2024-02-22 11:42:06','2024-02-22 11:42:06'),(30,30,0.00,'2024-02-22 12:47:54','2024-02-22 12:47:54'),(31,31,0.00,'2024-02-22 13:27:19','2024-02-22 13:27:19'),(32,32,0.00,'2024-02-22 14:47:39','2024-02-22 14:47:39'),(33,33,0.00,'2024-02-22 19:57:03','2024-02-22 19:57:03'),(34,34,0.00,'2024-02-22 20:00:08','2024-02-22 20:00:08'),(35,35,0.00,'2024-02-22 20:01:29','2024-02-22 20:01:29'),(36,36,0.00,'2024-02-22 22:26:40','2024-02-22 22:26:40');
/*!40000 ALTER TABLE `wallets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `withdraws`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `withdraws` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `wallet_id` bigint unsigned NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(12,4) NOT NULL,
  `txid` text COLLATE utf8mb4_unicode_ci,
  `is_confirm` tinyint(1) NOT NULL DEFAULT '0',
  `is_detected` tinyint(1) NOT NULL DEFAULT '0',
  `is_failed` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `withdraws_wallet_id_foreign` (`wallet_id`),
  CONSTRAINT `withdraws_wallet_id_foreign` FOREIGN KEY (`wallet_id`) REFERENCES `wallets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `withdraws` WRITE;
/*!40000 ALTER TABLE `withdraws` DISABLE KEYS */;
/*!40000 ALTER TABLE `withdraws` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

